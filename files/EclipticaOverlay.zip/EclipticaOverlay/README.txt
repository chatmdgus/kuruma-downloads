﻿Ecliptica Overlay 2.3.0
VRChat 월드 ECLIPTICA 전용 DPS / 어그로 표시  |  DPS & aggro overlay for the VRChat world ECLIPTICA  |  VRChat ワールド ECLIPTICA 専用 DPS・アグロ表示

!! 재배포 금지. 다른 사람에게는 다운로드 페이지(https://chatmdgus.github.io/kuruma-downloads/)를 알려 주세요.
!! Do not redistribute. Please share the download page (https://chatmdgus.github.io/kuruma-downloads/) instead of the file.
!! 再配布禁止。ほかの方にはダウンロードページ(https://chatmdgus.github.io/kuruma-downloads/)をお伝えください。

!! 보스 타겟 정보는 본인 화면에서만 참고해 주세요. 게임 안에서 다른 플레이어에게 퍼뜨리면 밴될 수 있고,
   음성이나 채팅으로 알려주는 것도 Ecliptica 제작진이 권장하지 않는 회색 지대입니다.
!! Use the boss target information only for yourself. Broadcasting it to other players in the game can get you banned,
   and telling others by voice or chat is a grey area the Ecliptica team recommends you avoid.
!! ボスのターゲット情報は自分だけが参考にしてください。ゲーム内で他のプレイヤーに広めると BAN される可能性があり、
   ボイスやチャットで伝えることも Ecliptica 制作チームが推奨しないグレーゾーンです。


====================================================================
한국어
====================================================================
■ 실행
  EclipticaOverlay-Setup.exe 로 설치하면 바탕화면과 시작 메뉴에 아이콘이 생깁니다. (압축본은 EclipticaOverlay.exe 를 더블클릭)
  Python 설치는 필요 없고, 새 버전은 ⚙ 설정 창 맨 위의 업데이트 버튼으로 바로 받을 수 있습니다.
  EclipticaOverlay-Demo.exe 는 게임 없이 가짜 전투로 화면을 미리 보는 용도입니다.

■ 조작
  드래그            창 이동 (글자나 위쪽 막대를 잡고)
  ⚙ / 우클릭       설정 창 (마우스를 올리면 오른쪽 아래 ⚙. 잠금, 배경, 알림음, 테마, 언어, 이름, 사전, 업데이트, 종료)
  Ctrl + Alt + E    잠금 전환. 잠그면 클릭이 게임으로 통과되고 안내 문구와 테두리가 사라집니다.
  언어는 처음에 Windows 언어에 맞춰 자동 선택되며, 메뉴의 Language / 언어 / 言語 에서 바꿀 수 있습니다.
  설정은 app 폴더에 저장되어 다음 실행 때 그대로 적용됩니다.

■ 업그레이드 사전 (한국어)
  상점(인터미션)에 들어가면 업그레이드 사전 창이 자동으로 열리고, 다음 스테이지가 시작되면 닫힙니다.
  직업 탭(보라)에서는 로그로 인식한 내 직업의 전용 업그레이드를 보여주고, 다른 직업도 골라 볼 수 있습니다.
  전체 탭에서는 내 직업 업그레이드가 맨 위에 나옵니다.
  내 직업은 로그에서 읽은 직업과 직업 탭에서 마지막으로 누른 직업 중 더 최근 것으로 정해집니다.
  (상점에서 직업을 바꿨다면 직업 탭에서 새 직업을 한 번 눌러 주세요. 다음 스테이지부터는 자동으로 인식합니다.)
  직업 탭의 "이 직업을 내 직업으로 고정" 또는 ⚙ 설정 창의 "내 직업"으로 직접 고정할 수도 있습니다.
  상점별 탭(인내 초록 / 기동성 파랑 / 크로노 빨강), 희귀도 필터, 검색을 쓸 수 있고, 빨간 줄은 단점입니다.
  검색 왼쪽의 효과 버튼을 누르면 버프 / 디버프 효과 17종의 설명과 얻는 곳을 볼 수 있습니다.
  업그레이드 설명 속 효과 이름에는 아이콘이 붙고, 누르면 그 효과 설명으로 이동합니다.
  검색 왼쪽의 룬 버튼을 누르면 룬 18종과 룬 저주 14종을 볼 수 있습니다. 게임 로그에는 룬과 저주가 기록되지 않아서,
  룬 이름을 눌러 장착한 룬을, 저주 이름을 눌러 저주 중첩을 직접 표시합니다. 고른 것은 오버레이 아래쪽에 나오고, 저주는 런이 끝나면 자동으로 지워집니다.
  사전 창은 제목 줄을 잡고 옮기고, 오른쪽 아래 모서리(◢)로 크기를 바꿉니다. Esc 로도 닫을 수 있습니다.
  목록은 마우스로 잡고 위아래로 끌어서 스크롤합니다. (마우스 휠도 사용할 수 있습니다)
  업그레이드 이미지는 사전을 처음 열 때 위키에서 한 번만 받아 app\data\icons 에 저장합니다.
  (이때만 인터넷을 사용하며, 메뉴의 "사전 이미지 받기"로 끌 수 있습니다.)
  ⚙ 설정 창의 "상점 업그레이드 사전"이나 Ctrl+Alt+D 로 언제든 열고 닫을 수 있으며, 자동 열기/닫기는 메뉴에서 끌 수 있습니다.
  내용은 Ecliptica 위키(영어, 작성 ruralist, WhereFernsGrow, CC BY-SA 4.0)를 기준으로 합니다.
  사전은 언어 설정(한국어 / English / 日本語)에 따라 내용이 바뀝니다. 한국어·일본어 설명은 영어 위키 원문을 이 도구에서 번역했습니다.

■ 테마와 효과
  ⚙ 설정 → 테마: 일식(기본) / 네온 / 사쿠라 / 오션 / 모노 / 무지개 / 스노우 / 포이즌 / 오텀 / 조무래기 / 쿠루마
  ⚙ 설정 → 알림음 크기: 25 / 50 / 75 / 100% (고르면 미리 들려줍니다)
  ⚙ 설정 → 테마 → 색상 직접 지정: 항목별로 색을 바꿀 수 있습니다. 테마마다 따로 저장됩니다.
  ⚙ 설정 → 효과: 네온 글로우, 그라데이션, 숫자 애니메이션, 어그로 반짝임을 켜고 끌 수 있습니다.
  (PC가 무겁게 느껴지면 효과를 끄면 더 가벼워집니다.)

■ VRChat 전체화면에서 쓰려면
  VRChat이 '독점 전체화면'이면 오버레이가 게임에 가려집니다.
  이 상태가 감지되면 게임 밖으로 나왔을 때 한 번 물어보며, [예]를 누르면
  VRChat의 화면 방식만 겉보기가 똑같은 '테두리 없는 전체화면'으로 바꿉니다.
  VRChat이 실행 중이면 종료될 때 자동으로 적용됩니다.
  ⚙ 설정 창의 "전체화면에서도 보이게 하기"로 직접 적용하거나, "되돌리기"로 원래대로 돌릴 수 있습니다.
  (게임 화면에 끼어드는 방식은 쓰지 않습니다.)

■ "Windows의 PC 보호" 창이 뜨면
  서명되지 않은 개인 제작 프로그램이라 뜨는 안내입니다. [추가 정보] → [실행] 을 누르세요.

■ 참고
  - VRChat 로그 파일만 읽습니다. 게임 메모리나 입력은 건드리지 않습니다.
  - Steam 시작 옵션(--enable-udon-debug-logging)은 넣지 않아도 모든 기능이 동작합니다.
  - 런 진행 중에는 몇 번째 스테이지인지(13스테이지 기준)와 Jim까지 남은 보스 수가 표시되고, 마지막 스테이지에서는 "Jim 등장!!"이 표시됩니다.
  - 보스는 위키의 이름과 아이콘으로 표시되고, 스테이지 줄에는 현재 난이도 단계(Prime / Penumbra / Antumbra / Umbra / Eclipse)가 나옵니다.
  - DPS는 본인 것만 표시됩니다. 어그로 대상은 보스의 네트워크 소유권으로 추정한 값입니다.
  - 오버레이가 화면에 안 보이면 EclipticaOverlay.exe 를 한 번 더 실행하세요.
    [예] 화면으로 다시 불러오기 / [아니요] 종료하기 중에서 고를 수 있습니다.
    (작업 관리자에서는 EclipticaOverlayApp.exe 라는 이름으로 표시됩니다)
  - 문제가 생기면 app\error.log 를 확인해 주세요.

====================================================================
English
====================================================================
■ How to start
  Install with EclipticaOverlay-Setup.exe to get desktop and Start menu shortcuts. (Portable zip: double-click EclipticaOverlay.exe)
  No Python install needed. New versions install from the Update button at the top of ⚙ Settings.
  EclipticaOverlay-Demo.exe runs a fake fight so you can preview the overlay without the game.

■ Controls
  Drag              Move the window (grab the text or the top bar)
  ⚙ / Right-click   Settings (hover for ⚙ at bottom right: lock, background, sound, theme, language, name, dictionary, update, quit)
  Ctrl + Alt + E    Toggle lock. When locked, clicks pass through to the game and the hint and frame are hidden.
  The language follows your Windows language at first. Change it from "Language / 언어 / 言語" in the menu.
  Settings are saved in the app folder and restored on the next start.

■ Upgrade dictionary (Korean)
  When you enter the shop (intermission), a Korean upgrade dictionary opens, and it closes when the next stage starts.
  The Runes button lists 18 runes and 14 runic curses. Runes and curses are not in the game log, so click them to mark what you have; they are shown on the overlay and curses are cleared when the run ends.
  Toggle it anytime with Ctrl+Alt+D or the ⚙ Settings. Based on the Ecliptica Wiki (by ruralist, WhereFernsGrow, CC BY-SA 4.0).
  The dictionary follows the language setting. English and Japanese text were translated from the Korean wiki for this tool.
  Upgrade images are downloaded from the wiki once, the first time you open it (the only time the internet is used).

■ Themes and effects
  ⚙ Settings → Theme: Eclipse (default) / Neon / Sakura / Ocean / Mono / Rainbow / Snow / Poison / Autumn / zomuregi / kuruma
  ⚙ Settings → Alert volume: 25 / 50 / 75 / 100% (plays a preview)
  ⚙ Settings → Theme → Custom colors: change each color. Saved separately for each theme.
  ⚙ Settings → Effects: neon glow, gradients, number animation, aggro pulse.
  (Turning effects off makes the overlay lighter on your PC.)

■ Using it with VRChat in fullscreen
  In exclusive fullscreen, VRChat covers the overlay.
  When this is detected, the overlay asks once after you leave the game. Click [Yes] to switch
  only VRChat's display mode to borderless fullscreen, which looks the same.
  If VRChat is running, the change is applied automatically when it closes.
  You can also use "Show over fullscreen" or "Restore" in the ⚙ Settings.
  (The overlay never hooks into the game's rendering.)

■ If "Windows protected your PC" appears
  This shows up because the program is not code-signed. Click [More info] → [Run anyway].

■ Notes
  - Only the VRChat log file is read. Game memory and input are never touched.
  - The --enable-udon-debug-logging launch option is not required. Everything works without it.
  - During a run, the stage number (out of 13) and the number of bosses until Jim are shown. "Jim appears!!" is shown on the final stage.
  - Bosses are shown with their wiki name and icon, and the stage line shows the current phase (Prime / Penumbra / Antumbra / Umbra / Eclipse).
  - DPS is yours only. The aggro target is estimated from the boss's network ownership.
  - If the overlay isn't visible, run EclipticaOverlay.exe again and choose [Yes] to bring it back or [No] to quit it.
    (It appears as EclipticaOverlayApp.exe in Task Manager.)
  - If something goes wrong, check app\error.log.

====================================================================
日本語
====================================================================
■ 起動
  EclipticaOverlay-Setup.exe でインストールするとデスクトップとスタートメニューにアイコンができます。(ZIP 版は EclipticaOverlay.exe をダブルクリック)
  Python は不要で、新しいバージョンは ⚙ 設定の上にあるアップデートボタンからすぐ入手できます。
  EclipticaOverlay-Demo.exe はゲームなしで疑似戦闘を流し、表示を確認するためのものです。

■ 操作
  ドラッグ          ウィンドウを移動 (文字か上のバーをつかむ)
  ⚙ / 右クリック    設定画面 (マウスを乗せると右下に ⚙: ロック、背景、通知音、テーマ、言語、名前、辞書、アップデート、終了)
  Ctrl + Alt + E    ロック切り替え。ロック中はクリックがゲームに透過し、案内文と枠が消えます。
  言語は最初に Windows の言語に合わせて選ばれます。メニューの「Language / 언어 / 言語」で変更できます。
  設定は app フォルダに保存され、次回起動時にそのまま反映されます。

■ アップグレード辞典（韓国語）
  ショップ（インターミッション）に入ると韓国語のアップグレード辞典が開き、次のステージ開始時に閉じます。
  ルーンボタンでルーン18種と呪い14種を確認できます。ルーンと呪いはログに記録されないため、名前をクリックして装備中のルーンと呪いの重複を自分で記録します（オーバーレイに表示、呪いはラン終了時に自動で消去）。
  ⚙ 設定画面か Ctrl+Alt+D でいつでも開閉できます。内容は Ecliptica Wiki（英語、作成 ruralist, WhereFernsGrow、CC BY-SA 4.0）に基づきます。
  辞典は言語設定に合わせて内容が切り替わります。韓国語・日本語の説明は英語 Wiki の原文を本ツールで翻訳しました。
  アップグレードの画像は、辞典を初めて開いたときに一度だけ Wiki から取得します（インターネットを使うのはこの時だけです）。

■ テーマとエフェクト
  ⚙ 設定 → テーマ: 日食(標準) / ネオン / さくら / オーシャン / モノクロ / レインボー / スノー / ポイズン / オータム / レギ / くるま
  ⚙ 設定 → 通知音の音量: 25 / 50 / 75 / 100%（選ぶと試し聴きできます）
  ⚙ 設定 → テーマ → 色をカスタマイズ: 項目ごとに色を変更できます。テーマごとに保存されます。
  ⚙ 設定 → エフェクト: ネオングロー、グラデーション、数字アニメーション、アグロ点滅を切り替えられます。
  (PC が重く感じる場合は、エフェクトをオフにすると軽くなります。)

■ VRChat をフルスクリーンで使う場合
  VRChat が「排他フルスクリーン」だと、オーバーレイがゲームに隠れます。
  これを検知すると、ゲームの外に出たときに一度だけ確認し、[はい] を押すと
  VRChat の画面モードだけを見た目が同じ「ボーダーレスフルスクリーン」に変更します。
  VRChat が起動中の場合は、終了時に自動で適用されます。
  ⚙ 設定画面の「フルスクリーンでも表示する」で手動適用、「元に戻す」で復元できます。
  (ゲームの描画に割り込む方式は使いません。)

■ 「Windows によって PC が保護されました」と出た場合
  署名されていない個人制作のプログラムのため表示されます。[詳細情報] → [実行] を押してください。

■ 注意
  - VRChat のログファイルだけを読み取ります。ゲームのメモリや入力には一切触れません。
  - 起動オプション（--enable-udon-debug-logging）は不要です。追加しなくてもすべての機能が動作します。
  - ラン中は、何番目のステージか（全13ステージ）と Jim までの残りボス数を表示し、最終ステージでは「Jim 登場!!」と表示します。
  - ボスは Wiki の名前とアイコンで表示され、ステージ行には現在のフェーズ（Prime / Penumbra / Antumbra / Umbra / Eclipse）が表示されます。
  - DPS は自分の分のみです。アグロ対象はボスのネットワーク所有権から推定した値です。
  - オーバーレイが見えない場合は、EclipticaOverlay.exe をもう一度起動してください。
    [はい] 画面に呼び戻す / [いいえ] 終了する を選べます。（タスクマネージャーでは EclipticaOverlayApp.exe と表示されます）
  - 問題が起きたら app\error.log を確認してください。
