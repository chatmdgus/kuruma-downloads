#!/usr/bin/env python3
"""
Ecliptica 전투 오버레이 (VRChat 월드 ECLIPTICA 전용)

VRChat이 남기는 output_log_*.txt 만 읽어서
  - 내 DPS (최근 10초 / 전투 평균)
  - 보스가 누구를 노리고 있는지 (어그로 대상)
  - 총 딜량, 받은 피해, 전투 시간
을 항상 위에 떠 있는 작은 창으로 보여줍니다.
게임 메모리나 입력에는 전혀 손대지 않습니다.

실행:
    python ecliptica_overlay.py          # 실제 VRChat 로그 감시
    python ecliptica_overlay.py --demo   # 게임 없이 화면 미리보기

조작:
    드래그            창 이동 (잠금 해제 상태에서, 글자나 위쪽 손잡이를 잡고)
    ⚙ / 우클릭       설정 창 (잠금, 배경, 소리, 테마, 언어, 이름, 사전, 업데이트, 종료)
    Ctrl + Alt + E    잠금 전환 - 잠그면 클릭이 게임으로 통과됩니다

언어: 한국어 / English / 日本語 (처음에는 Windows 언어에 맞춰 자동 선택)
"""
import argparse
import glob
import json
import math
import os
import queue
import random
import re
import sys
import tempfile
import threading
import time
import unicodedata
from datetime import datetime

import tkinter as tk
from tkinter import font as tkfont
from tkinter import simpledialog

IS_WINDOWS = sys.platform == "win32"

# --- 자동 업데이트 ---------------------------------------------------------
# 다운로드 사이트의 ecliptica-latest.json 을 보고 새 버전이면 설정 창 맨 위에 "업데이트" 버튼이 생긴다.
# 누르면 app 폴더의 프로그램 파일만 받아서 바꾸고 다시 켠다 (설정 ecliptica_overlay.json, 아이콘은 그대로).
APP_VERSION = "2.2.0"
SITE_URL = "https://chatmdgus.github.io/kuruma-downloads/"
UPDATE_MANIFEST = SITE_URL + "files/ecliptica-latest.json"
DOWNLOAD_PAGE = SITE_URL + "#ecliptica"

APP_DIR = os.path.dirname(os.path.abspath(sys.argv[0]))
CONFIG_PATH = os.path.join(APP_DIR, "ecliptica_overlay.json")
DEFAULT_LOG_DIR = os.path.join(os.path.expanduser("~"), "AppData", "LocalLow", "VRChat", "VRChat")
_last_error_log = {}


def log_error(where):
    """콘솔이 없는 환경이라 예외는 app\\error.log에 남긴다. 같은 오류는 60초에 한 번만."""
    import traceback
    detail = traceback.format_exc()
    key = (where, detail.strip().splitlines()[-1] if detail.strip() else "")
    now = time.time()
    if now - _last_error_log.get(key, 0) < 60:
        return
    _last_error_log[key] = now
    try:
        with open(os.path.join(APP_DIR, "error.log"), "a", encoding="utf-8") as f:
            f.write(f"--- {datetime.now()} [{where}] ---\n{detail}\n")
    except OSError:
        pass

# ---------------------------------------------------------------------------
# 로그 패턴 (Ecliptica가 VRChat 로그에 남기는 문구)
# ---------------------------------------------------------------------------
RE_TS = re.compile(r"^(\d{4}\.\d{2}\.\d{2} \d{2}:\d{2}:\d{2})")
RE_DAMAGE = re.compile(r"Dealing\s+(\d+)\s+(STRIKE|NON-STRIKE)\s+damage")
RE_TAKEN = re.compile(r"damage has been taken:\s*(\d+)")
RE_TAKEN_SOURCE = re.compile(r"from source:\s*\(([^)]+)\)")   # 예: from source: (Irides) Combo3DamageAura
RE_BOSS = re.compile(r"ECLIPTICA - now fighting boss:\s*(.+?)\(Clone\)\s+on phase:")
RE_BOSS_DEAD = re.compile(r"Boss\s+(.+?)\s+dead, personal damage dealt:")
RE_OWNER = re.compile(r"ownership of\s+(.+?)\s+transferred to\s+(.+?)\s*$")
RE_AUTH = re.compile(r"User Authenticated:\s*(.+?)\s+\(usr_[^)]+\)\s*$")
RE_STAGE = re.compile(r"ECLIPTICA - now in stage:\s*(.+?)\s+on phase:\s*([0-9.]+)\s+as class:\s*(.+?)\s*$")
ENTER_ECLIPTICA = "[Behaviour] Entering Room: Ecliptica"
ENTER_ROOM = "[Behaviour] Entering Room:"
LEAVE_ROOM = "[Behaviour] OnLeftRoom"
FIGHT_END = ("ECLIPTICA - now in intermission", "ECLIPTICA - now in lobby")
# 방(인스턴스) 방장 여부. 방장이 소유한 보스는 처음 등장할 때 '소유권 이전' 줄이 찍히지 않는다.
LOCAL_IS_MASTER = "[Behaviour] I am MASTER"
LOCAL_IS_NOT_MASTER = "[Behaviour] I am *NOT* MASTER"
MASTER_SWITCHED = "[Behaviour] OnMasterClientSwitched"
# VRChat은 로그 맨 앞에 실행 옵션을 'Arg: ...' 줄로 남긴다
RE_LAUNCH_ARG = re.compile(r"Debug\s+-\s+Arg:\s*(.+?)\s*$")
UDON_DEBUG_FLAG = "--enable-udon-debug-logging"

# 한 런은 13스테이지(보스 12마리 + 마지막 Jim C. Bringer).
# 스테이지 시작 줄의 진행도(phase) 값은 순번마다 거의 일정하다. 실제 풀런 로그 2개와
# 부분 런 3개에서 잰 평균값이며, 런마다 오차는 ±0.005 이내, 이웃 순번과는 0.058 이상 떨어져 있다.
RUN_STAGES = 13
STAGE_PHASES = [0.0, 0.0609, 0.1231, 0.1880, 0.2545, 0.3427, 0.4319,
                0.5283, 0.6265, 0.7260, 0.8264, 0.9343, 1.0]


def stage_index_from_phase(phase):
    """진행도 값에서 몇 번째 스테이지인지(1~13) 계산. 도중에 켜거나 중간 참가해도 맞다."""
    return min(range(RUN_STAGES), key=lambda i: abs(STAGE_PHASES[i] - phase)) + 1


def pretty_stage(raw):
    """Stage_CalamityPalace -> Calamity Palace, Stage_GMFuncFlat3 -> GM Func Flat 3"""
    name = raw[6:] if raw.startswith("Stage_") else raw
    if " " in name:
        return name
    return re.sub(r"(?<=[a-z])(?=[A-Z])|(?<=[A-Z])(?=[A-Z][a-z])|(?<=[A-Za-z])(?=\d)", " ", name)


DPS_WINDOW = 10      # 실시간 DPS 계산 구간(초)
GRAPH_SECONDS = 60   # 그래프에 보여줄 구간(초)


def norm(name):
    return unicodedata.normalize("NFKC", name).strip().lower()


def parse_ts(line):
    m = RE_TS.match(line)
    if not m:
        return None
    try:
        return datetime.strptime(m.group(1), "%Y.%m.%d %H:%M:%S")
    except ValueError:
        return None


# ---------------------------------------------------------------------------
# 전투 상태
# ---------------------------------------------------------------------------
class CombatState:
    def __init__(self, local_name=""):
        self.lock = threading.Lock()
        self.manual_name = local_name
        self.auth_name = ""
        self.live = False          # False = 과거 로그 재생 중
        self.shop_seq = 0          # 실시간으로 상점(인터미션)에 들어갈 때마다 1 증가
        self.stage_seq = 0         # 실시간으로 새 스테이지가 시작될 때마다 1 증가
        self.run_end_seq = 0       # 실시간으로 런이 끝나 로비로 돌아갈 때마다 1 증가
        self.log_clock = None
        self.alerts = queue.Queue()
        self.reset_session()

    # --- 초기화 -----------------------------------------------------------
    def reset_session(self):
        self.in_ecliptica = False
        self.player_class = ""
        self.session_damage = 0
        self.session_taken = 0
        self.recent_owner = {}
        self.last_boss_result = ""
        # 방장 여부는 방마다 다르다. 이전 방의 값이 남으면 엉뚱한 사람을 타겟으로 표시할 수 있다.
        self.local_is_master = False
        self.master_switch_pending = False
        self.stage_index = 0          # 0이면 런 진행 중이 아님
        self.stage_name = ""
        self.stage_raw = ""
        self.stage_cleared = False    # 이번 스테이지 보스를 잡았는지
        self.boss_sources = {}        # 보스전 중 피해 출처 이름별 횟수
        self.sources_base = None      # boss_sources 가 어느 보스의 것인지 (페이즈 제외 이름)
        self._end_fight(silent=True)
        self.reset_segment()

    def reset_segment(self):
        self.seg_damage = 0
        self.seg_taken = 0
        self.seg_first = None
        self.seg_last = None
        self.per_second = {}

    def _end_fight(self, silent=False):
        self.active = False
        self.boss = None
        self.boss_started = None
        self.target_explicit = False     # 로그의 '소유권 이전' 줄로 확정된 타겟인지
        self.initial_target = None       # 방장일 때 보스의 첫 타겟(=나) 후보
        self._set_target(None, silent=silent)

    # --- 헬퍼 -------------------------------------------------------------
    @property
    def local_name(self):
        return self.manual_name or self.auth_name

    def is_me(self, player):
        return bool(player) and bool(self.local_name) and norm(player) == norm(self.local_name)

    def now(self):
        if self.live or self.log_clock is None:
            return datetime.now().replace(microsecond=0)
        return self.log_clock

    def _set_target(self, player, silent=False):
        before = getattr(self, "target", None)
        self.target = player
        if silent or not self.live:
            return
        was_me, now_me = self.is_me(before), self.is_me(player)
        if now_me and not was_me:
            self.alerts.put("aggro_me")
        elif was_me and not now_me:
            self.alerts.put("aggro_off")

    # --- 로그 한 줄 처리 --------------------------------------------------
    def feed(self, line):
        line = line.rstrip("\r\n")
        ts = parse_ts(line)
        if ts is None:
            return
        self.log_clock = ts

        m = RE_AUTH.search(line)
        if m:
            self.auth_name = m.group(1)
            return

        if ENTER_ECLIPTICA in line:
            self.reset_session()
            self.in_ecliptica = True
            return
        if ENTER_ROOM in line or LEAVE_ROOM in line:
            self.reset_session()
            return
        if not self.in_ecliptica:
            return

        if LOCAL_IS_MASTER in line:
            self.local_is_master = True
            self.master_switch_pending = False
            return
        if LOCAL_IS_NOT_MASTER in line:
            self.local_is_master = False
            self.master_switch_pending = False
            return
        if MASTER_SWITCHED in line:
            # 방 안에서 방장이 바뀌면 'I am MASTER'가 다시 찍히지 않는다.
            # 이후 첫 EnemyController 소유권 이전이 새 방장을 알려준다.
            self.local_is_master = False
            self.master_switch_pending = True
            return

        m = RE_STAGE.search(line)
        if m:
            self.stage_raw = m.group(1).strip()
            self.stage_name = pretty_stage(self.stage_raw)
            try:
                self.stage_index = stage_index_from_phase(float(m.group(2)))
            except ValueError:
                self.stage_index = 0
            self.stage_cleared = False
            self.player_class = m.group(3)
            if self.live:
                self.stage_seq += 1
            self.last_boss_result = ""   # 새 스테이지에서는 '○○ 처치' 표시를 지운다
            return

        m = RE_DAMAGE.search(line)
        if m:
            amount = int(m.group(1))
            if not self.active:
                self.reset_segment()
                self.active = True
            if self.seg_first is None:
                self.seg_first = ts
            self.seg_last = ts
            self.seg_damage += amount
            self.session_damage += amount
            key = int(ts.timestamp())
            self.per_second[key] = self.per_second.get(key, 0) + amount
            cutoff = key - GRAPH_SECONDS - DPS_WINDOW
            if len(self.per_second) > GRAPH_SECONDS * 3:
                self.per_second = {k: v for k, v in self.per_second.items() if k > cutoff}
            return

        m = RE_TAKEN.search(line)
        if m:
            amount = int(m.group(1))
            self.seg_taken += amount
            self.session_taken += amount
            src = RE_TAKEN_SOURCE.search(line)
            if src and self.boss:
                # 보스전 중 피해를 준 쪽의 이름 (처음 보는 보스를 위키 이름과 맞춰 볼 때 쓴다)
                name = src.group(1).strip()
                self.boss_sources[name] = self.boss_sources.get(name, 0) + 1
            return

        m = RE_BOSS.search(line)
        if m:
            name = m.group(1).strip()
            if self.active and self.boss and norm(self.boss) == norm(name):
                return   # 같은 보스 줄이 반복돼도 전투 기록과 타겟을 초기화하지 않는다
            self.reset_segment()
            self.active = True
            base = re.sub(r"Phase\d+$", "", name)
            if base != self.sources_base:
                self.boss_sources = {}     # 같은 보스의 다음 페이즈면 이어서 쓴다
                self.sources_base = base
            self.boss = name
            self.boss_started = ts
            self.last_boss_result = ""
            self.target_explicit = False
            self.initial_target = self.local_name if self.local_is_master else None
            # 소유권 줄과 보스 등장 줄은 같은 초 안에서 순서가 바뀔 수 있다
            owner = self.recent_owner.get(norm(name))
            if owner and abs((ts - owner[0]).total_seconds()) <= 1:
                self.target_explicit = True
                self._set_target(owner[1])
            else:
                self._set_target(None)
            return

        m = RE_OWNER.search(line)
        if m:
            obj, player = m.group(1).strip(), m.group(2).strip()
            if self.master_switch_pending and norm(obj).startswith("enemycontroller"):
                self.local_is_master = self.is_me(player)
                self.master_switch_pending = False
            self.recent_owner[norm(obj)] = (ts, player)
            if len(self.recent_owner) > 256:   # 보스 매칭엔 최근 몇 초만 필요
                self.recent_owner = {k: v for k, v in self.recent_owner.items()
                                     if (ts - v[0]).total_seconds() <= 10}
            if self.boss and norm(obj) == norm(self.boss):
                self.target_explicit = True
                self._set_target(player)
            return

        m = RE_BOSS_DEAD.search(line)
        if m:
            name = m.group(1).strip()
            # 사망 줄은 보스가 죽은 뒤에도 몇 초마다 반복되고, 다음 스테이지가 시작된 뒤에도 찍힌다.
            # 지금 싸우고 있는 그 보스일 때만 전투를 끝낸다.
            if self.boss and norm(name) == norm(self.boss):
                self.last_boss_result = name
                self._end_fight()
            return

        if any(marker in line for marker in FIGHT_END):
            if "now in lobby" in line:
                self.stage_index = 0          # 런 종료 (클리어 또는 전멸)
                if self.live:
                    self.run_end_seq += 1
                self.stage_name = ""
                self.stage_raw = ""
            elif self.stage_index:
                self.stage_cleared = True     # 보스를 잡아야 인터미션으로 넘어간다
                if self.live:
                    self.shop_seq += 1
            self._end_fight()
            return

    # --- 화면용 스냅샷 ----------------------------------------------------
    def _resolve_initial_target(self, now):
        """방장일 때: 보스 등장 후 1초가 지나도 소유권 줄이 없으면 첫 타겟은 나다.
        (같은 초에 소유권 줄이 뒤따라올 수 있어서 바로 확정하지 않는다)"""
        if (self.boss and self.target is None and not self.target_explicit
                and self.initial_target and self.boss_started
                and (now - self.boss_started).total_seconds() > 1):
            self._set_target(self.initial_target)

    def snapshot(self):
        now = self.now()
        self._resolve_initial_target(now)
        now_key = int(now.timestamp())
        end = now if self.active else (self.seg_last or now)
        elapsed = 0
        if self.seg_first:
            elapsed = max(1, int((end - self.seg_first).total_seconds()) + 1)

        if self.active and self.seg_first:
            window = min(DPS_WINDOW, elapsed)
            recent = sum(self.per_second.get(now_key - i, 0) for i in range(window))
            dps_now = recent / window
        else:
            dps_now = 0
        dps_avg = self.seg_damage / elapsed if elapsed else 0

        # 그래프: 초 단위 3초 이동평균
        graph_end = now_key if self.active else int(end.timestamp())
        graph = []
        for s in range(graph_end - GRAPH_SECONDS + 1, graph_end + 1):
            graph.append(sum(self.per_second.get(s - i, 0) for i in range(3)) / 3)

        return {
            "in_ecliptica": self.in_ecliptica,
            "active": self.active,
            "boss": self.boss,
            "boss_sources": tuple(sorted(self.boss_sources, key=self.boss_sources.get, reverse=True)[:3]),
            "last_boss": self.last_boss_result,
            "target": self.target,
            "target_is_me": self.is_me(self.target),
            "local_name": self.local_name,
            "dps_now": dps_now,
            "dps_avg": dps_avg,
            "seg_damage": self.seg_damage,
            "seg_taken": self.seg_taken,
            "session_damage": self.session_damage,
            "elapsed": elapsed,
            "graph": graph,
            "has_data": self.seg_first is not None,
            "stage_index": self.stage_index,
            "stage_name": self.stage_name,
            "stage_raw": self.stage_raw,
            "bosses_left": (RUN_STAGES - self.stage_index + (0 if self.stage_cleared else 1))
                           if self.stage_index else 0,
            # Jim(13번째) 전까지 남은 보스. Jim 자신은 세지 않는다.
            "until_jim": max(0, (RUN_STAGES - 1) - self.stage_index + (0 if self.stage_cleared else 1))
                         if self.stage_index else 0,
        }


# ---------------------------------------------------------------------------
# 로그 감시 스레드
# ---------------------------------------------------------------------------
class LogWatcher(threading.Thread):
    def __init__(self, state, log_dir=None, fixed_file=None):
        super().__init__(daemon=True)
        self.state = state
        self.log_dir = log_dir or DEFAULT_LOG_DIR
        self.fixed_file = fixed_file
        self.current_file = None
        self.status = ("finding", "")
        self.debug_logging = None   # True/False: 옵션 켜짐/꺼짐, None: 알 수 없음(데모 등)

    def newest_log(self):
        if self.fixed_file:
            return self.fixed_file if os.path.exists(self.fixed_file) else None
        files = glob.glob(os.path.join(self.log_dir, "output_log_*.txt"))
        return max(files, key=os.path.getmtime) if files else None

    def run(self):
        while True:
            try:
                path = self.newest_log()
                if not path:
                    self.status = ("no_log", "")
                    time.sleep(2)
                    continue
                self.follow(path)
            except Exception:
                # 파일이 잠기거나 사라지는 등 어떤 오류가 나도 감시는 계속한다
                log_error("log watcher")
                time.sleep(2)

    @staticmethod
    def find_replay_start(f, size):
        """파일 끝에서부터 거꾸로 읽어 마지막 'Entering Room' 줄의 시작 위치를 찾는다."""
        marker = ENTER_ROOM.encode()
        chunk_size = 1 << 20
        pos, carry = size, b""
        while pos > 0:
            n = min(chunk_size, pos)
            pos -= n
            f.seek(pos)
            buf = f.read(n) + carry
            idx = buf.rfind(marker)
            if idx != -1:
                hit = pos + idx
                back = max(0, hit - 4096)
                f.seek(back)
                before = f.read(hit - back)
                nl = before.rfind(b"\n")
                return back + nl + 1 if nl != -1 else back
            carry = buf[:len(marker)]
        return 0

    @staticmethod
    def find_launch_args(f):
        """로그 앞부분(64KB)에서 VRChat 실행 옵션 목록을 읽는다. 없으면 None"""
        f.seek(0)
        head = f.read(64 << 10).decode("utf-8", errors="replace")
        args = []
        for line in head.splitlines():
            m = RE_LAUNCH_ARG.search(line)
            if m:
                args.append(m.group(1))
        return args or None

    @staticmethod
    def find_auth_name(f, limit):
        """로그인 줄은 로그 앞부분에 찍힌다. 앞쪽 최대 16MB만 본다."""
        f.seek(0)
        head = f.read(min(limit, 16 << 20)).decode("utf-8", errors="replace")
        name = ""
        for line in head.splitlines():
            m = RE_AUTH.search(line)
            if m:
                name = m.group(1)
        return name

    def follow(self, path):
        self.current_file = path
        self.status = ("file", os.path.basename(path))
        with self.state.lock:
            self.state.live = False
            self.state.reset_session()
        # 바이너리로 열고 읽은 위치를 직접 관리한다.
        # (Windows에서는 텍스트 모드로 EOF를 한 번 만나면 이후 추가된 줄을 못 읽는 경우가 있음)
        with open(path, "rb") as f:
            size = os.path.getsize(path)
            # 지금 들어가 있는 방부터 다시 계산 (도중에 켜도 기록이 이어짐)
            pos = self.find_replay_start(f, size)
            auth_name = self.find_auth_name(f, pos) if pos else ""
            args = self.find_launch_args(f)
            self.debug_logging = None if args is None else any(
                a.strip().lower() == UDON_DEBUG_FLAG for a in args)
            if auth_name:
                with self.state.lock:
                    self.state.auth_name = auth_name

            pending = b""
            last_check = time.time()
            while True:
                f.seek(pos)
                chunk = f.read(1 << 20)   # 재생 중에도 1MB씩 나눠 읽어 메모리와 화면 응답을 지킨다
                if chunk:
                    pos += len(chunk)
                    pending += chunk
                    cut = pending.rfind(b"\n") + 1
                    if cut:
                        text = pending[:cut].decode("utf-8", errors="replace")
                        pending = pending[cut:]
                        with self.state.lock:
                            for line in text.splitlines():
                                self.state.feed(line)
                    continue
                if not self.state.live:
                    with self.state.lock:
                        self.state.live = True   # 과거 기록 재생 끝, 이제부터 실시간
                time.sleep(0.1)
                if time.time() - last_check > 2:
                    last_check = time.time()
                    try:
                        if os.path.getsize(path) < pos:   # 파일이 새로 써진 경우
                            return
                    except OSError:
                        return
                    newest = self.newest_log()
                    if newest and newest != path:
                        return  # VRChat 재시작 등으로 새 로그가 생기면 전환


# ---------------------------------------------------------------------------
# 데모 로그 생성기 (--demo)
# ---------------------------------------------------------------------------
def start_demo_writer():
    path = os.path.join(tempfile.gettempdir(), "ecliptica_overlay_demo_log.txt")
    open(path, "w", encoding="utf-8").close()

    def write(msg):
        stamp = datetime.now().strftime("%Y.%m.%d %H:%M:%S")
        with open(path, "a", encoding="utf-8") as f:
            f.write(f"{stamp} Debug      -  {msg}\n")

    def loop():
        write("User Authenticated: Me (usr_demo-0000)")
        write("[Behaviour] Entering Room: Ecliptica")
        party = ["Me", "Alice", "Sayoray", "Kanamio"]
        bosses = ["Maxipuss", "ConeHead", "Kakarot", "DarkMouth"]
        stages = ["Stage_Hall of Beginnings", "Stage_GMFuncFlat", "Stage_CalamityPalace", "Stage_ProtoColony"]
        stage_no = 0
        while True:
            boss = random.choice(bosses)
            write(f"ECLIPTICA - now in stage: {stages[stage_no % len(stages)]} "
                  f"on phase: {STAGE_PHASES[stage_no % RUN_STAGES]} as class: Twinmage")
            stage_no += 1
            time.sleep(2)
            write(f"ECLIPTICA - now fighting boss: {boss}(Clone) on phase: 1")
            write(f"ownership of {boss} transferred to {random.choice(party)}")
            fight_end = time.time() + random.randint(40, 70)
            next_swap = time.time() + random.uniform(4, 9)
            burst = 1.0
            while time.time() < fight_end:
                if random.random() < 0.05:
                    burst = random.choice([0.4, 1.0, 1.8])
                kind = random.choice(["STRIKE", "NON-STRIKE"])
                write(f"Dealing {int(random.randint(20, 140) * burst)} {kind} damage")
                if random.random() < 0.06:
                    write(f"damage has been taken: {random.randint(5, 60)}")
                if time.time() > next_swap:
                    write(f"ownership of {boss} transferred to {random.choice(party)}")
                    next_swap = time.time() + random.uniform(4, 9)
                time.sleep(random.uniform(0.15, 0.5))
            write(f"Boss {boss} dead, personal damage dealt:")
            time.sleep(1)
            write("ECLIPTICA - now in intermission")
            time.sleep(4)

    threading.Thread(target=loop, daemon=True).start()
    return path


# ---------------------------------------------------------------------------
# Windows 전용 기능: 클릭 통과, 전역 단축키, 알림음
# ---------------------------------------------------------------------------
GWL_EXSTYLE = -20
WS_EX_LAYERED = 0x00080000
WS_EX_TRANSPARENT = 0x00000020


def _hwnd_of(tkwin):
    import ctypes
    u = ctypes.windll.user32
    return u.GetParent(tkwin.winfo_id()) or tkwin.winfo_id()


def is_topmost(tkwin):
    if not IS_WINDOWS:
        return True
    import ctypes
    return bool(ctypes.windll.user32.GetWindowLongW(_hwnd_of(tkwin), GWL_EXSTYLE) & 0x00000008)


def force_topmost(tkwin):
    """Windows에 직접 '항상 맨 앞'을 건다. 포커스는 가져오지 않는다.
    (제목 표시줄 없는 창은 Tk의 -topmost 설정이 적용되지 않거나 풀리는 경우가 있다)"""
    try:
        tkwin.attributes("-topmost", True)
    except tk.TclError:
        pass
    if not IS_WINDOWS:
        return
    import ctypes
    u = ctypes.windll.user32
    u.SetWindowPos.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_int, ctypes.c_int,
                               ctypes.c_int, ctypes.c_int, ctypes.c_uint]
    SWP_NOSIZE, SWP_NOMOVE, SWP_NOACTIVATE = 0x0001, 0x0002, 0x0010
    u.SetWindowPos(_hwnd_of(tkwin), ctypes.c_void_p(-1), 0, 0, 0, 0,   # HWND_TOPMOST
                   SWP_NOSIZE | SWP_NOMOVE | SWP_NOACTIVATE)


def set_click_through(root, enabled):
    if not IS_WINDOWS:
        return
    import ctypes
    user32 = ctypes.windll.user32
    hwnd = user32.GetParent(root.winfo_id()) or root.winfo_id()
    style = user32.GetWindowLongW(hwnd, GWL_EXSTYLE)
    style |= WS_EX_LAYERED
    style = (style | WS_EX_TRANSPARENT) if enabled else (style & ~WS_EX_TRANSPARENT)
    user32.SetWindowLongW(hwnd, GWL_EXSTYLE, style)


def start_hotkey_listener(event_queue):
    """Ctrl + Alt + E 전역 단축키 (게임 화면에서도 동작)"""
    if not IS_WINDOWS:
        return

    def loop():
        import ctypes
        from ctypes import wintypes
        user32 = ctypes.windll.user32
        MOD_ALT, MOD_CONTROL, MOD_NOREPEAT = 0x0001, 0x0002, 0x4000
        if not user32.RegisterHotKey(None, 1, MOD_ALT | MOD_CONTROL | MOD_NOREPEAT, 0x45):
            event_queue.put("hotkey_failed")
            return
        event_queue.put("hotkey_ok")
        user32.RegisterHotKey(None, 2, MOD_ALT | MOD_CONTROL | MOD_NOREPEAT, 0x44)   # Ctrl+Alt+D (실패해도 무시)
        msg = wintypes.MSG()
        while user32.GetMessageW(ctypes.byref(msg), None, 0, 0) != 0:
            if msg.message == 0x0312:  # WM_HOTKEY
                event_queue.put("toggle_lock" if msg.wParam == 1 else "toggle_dict")

    threading.Thread(target=loop, daemon=True).start()


# ---------------------------------------------------------------------------
# VRChat 전체화면 대응
#   독점 전체화면(exclusive)에서는 어떤 창도 게임 위에 그려질 수 없다.
#   게임에 끼어들지 않고 해결하기 위해, 사용자가 동의하면 VRChat(Unity)의
#   화면 설정 한 가지를 "테두리 없는 전체화면"으로 바꾼다. 겉보기는 똑같은 전체화면이다.
# ---------------------------------------------------------------------------
VRC_REG_PATH = r"Software\VRChat\VRChat"
FS_VALUE_PREFIX = "Screenmanager Fullscreen mode_h"   # Unity가 저장하는 전체화면 방식 값
FS_BORDERLESS = 1                                      # 0=독점, 1=테두리 없는 전체화면, 3=창 모드


def _user32():
    import ctypes
    u = ctypes.WinDLL("user32")
    u.FindWindowW.restype = ctypes.c_void_p
    u.GetForegroundWindow.restype = ctypes.c_void_p
    return u


def vrchat_window():
    if not IS_WINDOWS:
        return None
    u = _user32()
    return u.FindWindowW("UnityWndClass", "VRChat") or u.FindWindowW(None, "VRChat")


def vrchat_in_exclusive_fullscreen():
    """VRChat이 앞에 있고, Windows가 '독점 전체화면 D3D 앱 실행 중'이라고 알려줄 때만 True"""
    if not IS_WINDOWS:
        return False
    import ctypes
    hwnd = vrchat_window()
    if not hwnd or _user32().GetForegroundWindow() != hwnd:
        return False
    state = ctypes.c_int(0)
    if ctypes.windll.shell32.SHQueryUserNotificationState(ctypes.byref(state)) != 0:
        return False
    return state.value == 3   # QUNS_RUNNING_D3D_FULL_SCREEN


def read_fullscreen_values():
    """VRChat 설정 중 전체화면 방식 값만 읽는다. [(이름, 값)]"""
    import winreg
    found = []
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, VRC_REG_PATH) as key:
            i = 0
            while True:
                try:
                    name, value, kind = winreg.EnumValue(key, i)
                except OSError:
                    break
                if name.startswith(FS_VALUE_PREFIX) and kind == winreg.REG_DWORD:
                    found.append((name, value))
                i += 1
    except OSError:
        pass
    return found


def write_fullscreen_values(values):
    """{이름: 값} 을 기록한다. 전체화면 방식 값 외에는 절대 건드리지 않는다."""
    import winreg
    with winreg.OpenKey(winreg.HKEY_CURRENT_USER, VRC_REG_PATH, 0, winreg.KEY_SET_VALUE) as key:
        for name, value in values.items():
            if name.startswith(FS_VALUE_PREFIX):
                winreg.SetValueEx(key, name, 0, winreg.REG_DWORD, int(value))


SOUND_LEVELS = [25, 50, 75, 100]
_sound_cache = {}
_RATE = 32000


def _classic(kind):
    notes = [(988, 0.09), (1319, 0.14)] if kind == "aggro_me" else [(523, 0.12)]
    out = []
    fade = int(_RATE * 0.008)
    for freq, dur in notes:
        m = int(_RATE * dur)
        out += [min(1.0, i / fade, (m - i) / fade) * math.sin(2 * math.pi * freq * i / _RATE) for i in range(m)]
        out += [0.0] * int(_RATE * 0.015)
    return out


def _tone_wav(kind, volume):
    """삐빅 알림음을 WAV로 만든다. (Windows 기본 Beep은 크기를 바꿀 수 없어서 직접 만든다)"""
    import io
    import wave
    from array import array
    wave_data = _classic(kind)
    amp = 32767 * 0.8 * (max(0, min(100, volume)) / 100) ** 1.6   # 귀로 듣기에 고르게 줄어들도록
    samples = array("h", (int(amp * x) for x in wave_data))
    buf = io.BytesIO()
    with wave.open(buf, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(_RATE)
        w.writeframes(samples.tobytes())
    return buf.getvalue()


def prepare_sounds(volume):
    """처음 울릴 때 지연이 없도록 미리 만들어 둔다 (백그라운드)"""
    def run():
        for kind in ("aggro_me", "aggro_off"):
            key = (kind, volume)
            if key not in _sound_cache:
                _sound_cache[key] = _tone_wav(kind, volume)
    threading.Thread(target=run, daemon=True).start()


def play_sound(kind, volume=100):
    if volume <= 0:
        return

    def run():
        try:
            if IS_WINDOWS:
                import winsound
                key = (kind, volume)
                if key not in _sound_cache:
                    _sound_cache[key] = _tone_wav(kind, volume)
                winsound.PlaySound(_sound_cache[key], winsound.SND_MEMORY)
        except Exception:
            pass
    threading.Thread(target=run, daemon=True).start()


# ---------------------------------------------------------------------------
# 다국어 문구
# ---------------------------------------------------------------------------
STRINGS = {
    "ko": {
        "waiting": "Ecliptica 입장 대기",
        "resting": "휴식 중",
        "field": "필드 전투",
        "defeated": "{boss} 처치",
        "boss_phase": "({n}페이즈)",
        "boss_target": "보스 타겟",
        "target_me": "나를 노리는 중",
        "checking": "확인 중",
        "dps_recent": "DPS  최근 {n}초",
        "avg": "전투 평균",
        "damage": "딜량",
        "taken": "받은 피해",
        "session": "세션 딜량",
        "stage_of": "{i}/{n}",
        "until_jim": "Jim까지 {n}",
        "next_jim": "다음은 Jim!",
        "jim_appears": "Jim 등장!!",
        "finding": "로그를 찾는 중",
        "no_log": "VRChat 로그 없음. VRChat을 먼저 실행하세요",
        "hint": "드래그해서 이동 · 마우스를 올리면 오른쪽 아래 ⚙ 설정 · Ctrl+Alt+E로 잠금",
        "hint_name": "내 이름을 아직 모릅니다. ⚙ 설정에서 VRChat 이름을 입력하면 어그로 알림이 켜집니다.",
        "menu_lock": "잠금 (클릭 통과)   Ctrl+Alt+E",
        "menu_bg": "배경 투명",
        "menu_sound": "어그로 알림음",
        "menu_alpha": "전체 투명도",
        "menu_name": "내 VRChat 이름 설정…",
        "menu_fs_fix": "전체화면에서도 보이게 하기 (VRChat 설정)",
        "menu_fs_revert": "VRChat 전체화면 설정 되돌리기",
        "fs_detected": "VRChat이 '독점 전체화면'으로 실행되고 있어서 오버레이가 게임에 가려졌습니다.\n\n전체화면 모양은 그대로 두고, 오버레이가 보이는 '테두리 없는 전체화면'으로 VRChat 설정을 바꿀까요?\n\nVRChat의 화면 방식 설정 한 가지만 바꾸며, ⚙ 설정의 문제 해결에서 언제든 되돌릴 수 있습니다.",
        "fs_confirm": "VRChat의 전체화면 방식을 '테두리 없는 전체화면'으로 바꿀까요?\n겉보기는 똑같은 전체화면이지만 오버레이가 위에 보이게 됩니다.\n\n⚙ 설정의 문제 해결에서 언제든 되돌릴 수 있습니다.",
        "fs_wait": "VRChat이 실행 중이라 지금은 바꿀 수 없습니다. (VRChat이 종료될 때 설정을 덮어쓰기 때문입니다)\n\nVRChat을 종료하면 자동으로 적용됩니다.",
        "fs_done": "적용했습니다. 다음에 VRChat을 실행하면 전체화면에서도 오버레이가 보입니다.",
        "fs_reverted": "VRChat 전체화면 설정을 원래대로 되돌렸습니다.",
        "fs_already": "VRChat은 이미 테두리 없는 전체화면으로 설정되어 있습니다.\n그래도 가려진다면 Steam 시작 옵션에 -window-mode borderless 를 추가해 보세요.",
        "fs_not_found": "VRChat 화면 설정을 찾지 못했습니다.\nVRChat을 한 번 실행하고 종료한 뒤 다시 시도하거나, Steam 시작 옵션에 -screen-fullscreen 1 -window-mode borderless 를 추가해 주세요.",
        "fs_failed": "VRChat 설정을 바꾸지 못했습니다. app 폴더의 error.log를 확인해 주세요.",
        "warn_debug": "VRChat 시작 옵션에 --enable-udon-debug-logging 이 없습니다. 일부 정보가 로그에 기록되지 않을 수 있어요. (⚙ 설정 → 문제 해결)",
        "menu_launch_help": "VRChat 시작 옵션 안내…",
        "menu_dict": "상점 업그레이드 사전 열기/닫기   Ctrl+Alt+D",
        "menu_dict_auto": "상점에서 사전 자동으로 열기",
        "hint_dict": "Ctrl+Alt+D로 상점 업그레이드 사전 열기",
        "notice": "재배포 금지 · 배포처: chatmdgus.github.io/kuruma-downloads",
        "menu_dict_close": "스테이지 시작 시 사전 닫기",
        "dict_title": "업그레이드 사전",
        "dict_all": "전체", "dict_search": "검색",
        "dict_legend": "(+N) 중첩할 때마다 추가되는 값   빨간 줄은 단점   효과 이름을 누르면 설명",
        "dict_effects": "효과", "dict_buff": "버프", "dict_debuff": "디버프", "dict_sources": "얻는 곳",
        "dict_dot": "지속 피해", "dict_other": "기타",
        "dict_runes": "룬",
        "dict_rune_title": "룬",
        "dict_curse_title": "룬 저주",
        "dict_equipped": "장착",
        "dict_rune_hint": "룬 이름을 누르면 장착 표시 (최대 4개) · 저주 이름을 누르면 중첩 +1 (4 다음은 0)",
        "dict_rune_note": "룬은 Penumbra 구간부터 칸마다 차례로 켜지고, 켜질 때마다 무작위 저주가 붙어요. 저주는 런이 끝나면 자동으로 지워져요.",
        "dict_curse_reset": "저주 모두 지우기",
        "ov_curses": "저주",
        "dict_move_hint": "제목을 잡고 이동 · 모서리로 크기 조절 · Esc 또는 Ctrl+Alt+D로 닫기",
        "dict_source": "출처: Ecliptica Wiki (ruralist, WhereFernsGrow) · CC BY-SA 4.0 · 한국어는 이 도구에서 번역",
        "dict_credits": "크레딧",
        "menu_credits": "크레딧 / 보스 타겟 안내",
        "credits_text": "Ecliptica Overlay 크레딧\n\n업그레이드 사전 · 보스 · 맵 정보\n· Ecliptica Wiki (ecliptica.miraheze.org): ruralist, WhereFernsGrow\n· 라이선스: CC BY-SA 4.0 (사전 데이터 app\\data\\upgrades_en.json 도 같은 라이선스)\n· 한국어·일본어 설명: 영어 위키 원문을 이 도구에서 번역\n\n아이콘\n· 업그레이드 아이콘: Ana T\n· 보스 아이콘: TheWIPArtist\n· 효과 아이콘: OccyBee\n· 유물, 직업 아이콘: Blacksheepiess\n\nEcliptica의 모든 게임 콘텐츠는 Ecliptica 제작진에게 있습니다.",
        "target_notice": "보스 타겟 표시에 대한 안내\n\n보스가 누구를 노리는지는 본인 화면에서만 참고해 주세요.\n\nEcliptica 제작진에 따르면, 이 정보를 게임 안에서 다른 플레이어에게 퍼뜨리면 밴될 수 있고, 음성이나 채팅으로 알려주는 것도 권장하지 않는 회색 지대입니다.\n\n이 안내는 ⚙ 설정의 '크레딧'에서 다시 볼 수 있습니다.",
        "dict_empty": "검색 결과가 없습니다.",
        "dict_stack": "중첩",
        "dict_class": "직업", "dict_my_class": "내 직업", "dict_class_title": "{name} 직업 업그레이드",
        "dict_pinned": "고정", "dict_pin": "◆ 이 직업을 내 직업으로 고정", "dict_unpin": "고정 해제 (자동으로 돌아가기)",
        "menu_my_class": "내 직업", "my_class_auto": "자동 (로그 / 마지막으로 본 직업)",
        "dict_no_class": "직업을 아직 인식하지 못했습니다. 스테이지가 시작되면 자동으로 인식해요.",
        "menu_dict_icons": "사전 이미지 받기 (처음 한 번 인터넷 사용)",
        "dict_loading": "이미지 받는 중… {n}/{total}",
        "menu_theme": "테마",
        "menu_colors": "색상 직접 지정…",
        "menu_effects": "효과",
        "theme_eclipse": "일식 (기본)", "theme_neon": "네온", "theme_sakura": "사쿠라",
        "theme_ocean": "오션", "theme_mono": "모노", "theme_rainbow": "무지개 (색이 흐름)",
        "theme_snow": "스노우", "theme_poison": "포이즌", "theme_autumn": "오텀", "theme_zomuregi": "조무래기", "theme_kuruma": "쿠루마",
        "menu_volume": "알림음 크기",
        "fx_glow": "네온 글로우", "fx_gradient": "그라데이션", "fx_anim": "숫자 애니메이션",
        "fx_pulse": "어그로 반짝임",
        "col_corona": "DPS 숫자 · 강조색", "col_corona2": "그라데이션 끝 색", "col_text": "글자",
        "col_dim": "설명 글자", "col_blood": "어그로 띠 (나)", "col_blood2": "어그로 띠 그라데이션",
        "col_outline": "외곽선 (투명 배경)", "col_night": "패널 배경", "col_rim": "패널 테두리",
        "col_band": "패널 안쪽 띠",
        "colors_title": "색상 설정", "colors_change": "변경", "colors_reset": "이 테마 기본값으로",
        "colors_close": "닫기", "colors_note": "바꾼 색은 테마마다 따로 저장됩니다.",
        "menu_warn_debug": "시작 옵션 경고 표시",
        "launch_help": "Steam 라이브러리에서 VRChat을 우클릭 → 속성 → 시작 옵션에 아래 문구를 추가한 뒤 VRChat을 다시 시작하세요.\n이미 다른 옵션이 적혀 있다면 한 칸 띄우고 뒤에 붙이면 됩니다.\n\n--enable-udon-debug-logging\n\n이 문구는 클립보드에 복사해 두었습니다. 붙여넣기만 하면 됩니다.\n\n현재 상태: {state}",
        "launch_on": "켜져 있음",
        "launch_off": "꺼져 있음",
        "launch_unknown": "확인할 수 없음 (VRChat 로그를 아직 찾지 못했거나 데모 모드입니다)",
        "menu_quit": "종료",
        "menu_update": "업데이트 (v{v})",
        "update_busy": "업데이트 받는 중…",
        "update_failed": "업데이트에 실패했습니다. 다운로드 페이지에서 새로 받아 주세요.\n\n{err}",
        "update_full": "이번 업데이트는 전체 파일을 새로 받아야 합니다. 다운로드 페이지를 엽니다.",
        "name_title": "내 이름",
        "name_prompt": "VRChat 표시 이름 (비우면 로그에서 자동 인식)",
        "already": "오버레이가 이미 실행 중입니다.\n\n[예]  화면으로 다시 불러오기\n[아니요]  오버레이 종료하기\n[취소]  그대로 두기",
        "crash": "오류로 종료되었습니다. app 폴더의 error.log를 확인해 주세요.",
        "hotkey_busy": "다른 프로그램이 Ctrl+Alt+E를 쓰고 있어서 잠금을 켤 수 없습니다.\n잠그면 이 단축키로만 풀 수 있기 때문입니다. 해당 프로그램을 끄고 오버레이를 다시 실행해 주세요.",
    },
    "en": {
        "waiting": "Waiting for Ecliptica",
        "resting": "Resting",
        "field": "Field combat",
        "defeated": "{boss} defeated",
        "boss_phase": "(Phase {n})",
        "boss_target": "Boss target",
        "target_me": "Targeting YOU",
        "checking": "Checking",
        "dps_recent": "DPS  last {n}s",
        "avg": "Fight avg",
        "damage": "Damage",
        "taken": "Taken",
        "session": "Session",
        "stage_of": "{i}/{n}",
        "until_jim": "{n} until Jim",
        "next_jim": "Jim is next!",
        "jim_appears": "Jim appears!!",
        "finding": "Looking for the log",
        "no_log": "No VRChat log found. Start VRChat first",
        "hint": "Drag to move · hover for ⚙ settings (bottom right) · Ctrl+Alt+E locks it",
        "hint_name": "Your name is not known yet. Enter your VRChat name from ⚙ Settings → Troubleshooting to turn on aggro alerts.",
        "menu_lock": "Lock (click-through)   Ctrl+Alt+E",
        "menu_bg": "Transparent background",
        "menu_sound": "Aggro alert sound",
        "menu_alpha": "Opacity",
        "menu_name": "Set my VRChat name…",
        "menu_fs_fix": "Show over fullscreen (VRChat setting)",
        "menu_fs_revert": "Restore VRChat fullscreen setting",
        "fs_detected": "VRChat is running in exclusive fullscreen, so the game is covering the overlay.\n\nSwitch VRChat to borderless fullscreen? It still looks like fullscreen, but the overlay can stay on top.\n\nOnly VRChat's display mode setting is changed, and you can restore it anytime from ⚙ Settings → Troubleshooting.",
        "fs_confirm": "Switch VRChat's fullscreen mode to borderless fullscreen?\nIt looks the same, but the overlay can stay on top.\n\nYou can restore it anytime from ⚙ Settings → Troubleshooting.",
        "fs_wait": "VRChat is running, so this can't be changed right now (VRChat overwrites the setting when it closes).\n\nIt will be applied automatically when you close VRChat.",
        "fs_done": "Done. The overlay will show over fullscreen the next time you start VRChat.",
        "fs_reverted": "VRChat's fullscreen setting has been restored.",
        "fs_already": "VRChat is already set to borderless fullscreen.\nIf the overlay is still hidden, add -window-mode borderless to the Steam launch options.",
        "fs_not_found": "Couldn't find VRChat's display settings.\nStart and close VRChat once, then try again, or add -screen-fullscreen 1 -window-mode borderless to the Steam launch options.",
        "fs_failed": "Couldn't change the VRChat setting. See error.log in the app folder.",
        "warn_debug": "--enable-udon-debug-logging is missing from VRChat's launch options. Some information may not be logged. (⚙ Settings → Troubleshooting)",
        "menu_launch_help": "VRChat launch option help…",
        "menu_dict": "Shop upgrade dictionary   Ctrl+Alt+D",
        "menu_dict_auto": "Open dictionary in the shop",
        "hint_dict": "Ctrl+Alt+D opens the shop upgrade dictionary",
        "notice": "Do not redistribute · Official download: chatmdgus.github.io/kuruma-downloads",
        "menu_dict_close": "Close dictionary when a stage starts",
        "dict_title": "Upgrades",
        "dict_all": "All", "dict_search": "Search",
        "dict_legend": "(+N) added per extra stack   Red lines are drawbacks   Click an effect name for details",
        "dict_effects": "Effects", "dict_buff": "Buffs", "dict_debuff": "Debuffs", "dict_sources": "Granted by",
        "dict_dot": "Damage over Time", "dict_other": "Other",
        "dict_runes": "Runes",
        "dict_rune_title": "Runes",
        "dict_curse_title": "Runic Curses",
        "dict_equipped": "equipped",
        "dict_rune_hint": "Click a rune name to mark it equipped (up to 4) · Click a curse name to add a stack (resets after 4)",
        "dict_rune_note": "Rune slots activate one by one from the Penumbra phase, and each one adds a random curse. Curses are cleared automatically when the run ends.",
        "dict_curse_reset": "Clear all curses",
        "ov_curses": "Curses",
        "dict_move_hint": "Drag the title to move · corner to resize · Esc or Ctrl+Alt+D to close",
        "dict_source": "Source: Ecliptica Wiki (ruralist, WhereFernsGrow) · CC BY-SA 4.0",
        "dict_credits": "Credits",
        "menu_credits": "Credits / boss target notice",
        "credits_text": "Ecliptica Overlay credits\n\nUpgrade dictionary, bosses and maps\n· Ecliptica Wiki (ecliptica.miraheze.org): ruralist, WhereFernsGrow\n· License: CC BY-SA 4.0 (the dictionary data app\\data\\upgrades_en.json uses the same license)\n· Korean and Japanese text: translated from the English wiki for this tool\n\nIcons\n· Upgrade icons: Ana T\n· Boss icons: TheWIPArtist\n· Status effect icons: OccyBee\n· Artifact and class icons: Blacksheepiess\n\nAll Ecliptica game content belongs to the Ecliptica team.",
        "target_notice": "About the boss target display\n\nPlease use the boss target information only for yourself, on your own screen.\n\nAccording to the Ecliptica team, broadcasting this information to other players in the game can get you banned, and telling others by voice or chat is a grey area they recommend you don't do.\n\nYou can read this again from 'Credits' in ⚙ Settings.",
        "dict_empty": "No results.",
        "dict_stack": "Stacking",
        "dict_class": "Class", "dict_my_class": "My class", "dict_class_title": "{name} class upgrades",
        "dict_pinned": "pinned", "dict_pin": "◆ Pin this as my class", "dict_unpin": "Unpin (back to automatic)",
        "menu_my_class": "My class", "my_class_auto": "Automatic (log / last viewed)",
        "dict_no_class": "Your class isn't detected yet. It's detected automatically when a stage starts.",
        "menu_dict_icons": "Download dictionary images (internet, first time only)",
        "dict_loading": "Downloading images… {n}/{total}",
        "menu_theme": "Theme",
        "menu_colors": "Custom colors…",
        "menu_effects": "Effects",
        "theme_eclipse": "Eclipse (default)", "theme_neon": "Neon", "theme_sakura": "Sakura",
        "theme_ocean": "Ocean", "theme_mono": "Mono", "theme_rainbow": "Rainbow (cycling)",
        "theme_snow": "Snow", "theme_poison": "Poison", "theme_autumn": "Autumn", "theme_zomuregi": "zomuregi", "theme_kuruma": "kuruma",
        "menu_volume": "Alert volume",
        "fx_glow": "Neon glow", "fx_gradient": "Gradients", "fx_anim": "Number animation",
        "fx_pulse": "Aggro pulse",
        "col_corona": "DPS number / accent", "col_corona2": "Gradient end", "col_text": "Text",
        "col_dim": "Captions", "col_blood": "Aggro band (you)", "col_blood2": "Aggro band gradient",
        "col_outline": "Outline (transparent)", "col_night": "Panel background", "col_rim": "Panel border",
        "col_band": "Panel inner band",
        "colors_title": "Colors", "colors_change": "Change", "colors_reset": "Reset this theme",
        "colors_close": "Close", "colors_note": "Custom colors are saved separately for each theme.",
        "menu_warn_debug": "Show launch option warning",
        "launch_help": "In your Steam library, right-click VRChat → Properties → Launch Options, add the text below, then restart VRChat.\nIf something is already there, add a space and paste it after.\n\n--enable-udon-debug-logging\n\nThe text has been copied to your clipboard, so you only need to paste it.\n\nCurrent status: {state}",
        "launch_on": "enabled",
        "launch_off": "not enabled",
        "launch_unknown": "unknown (no VRChat log found yet, or demo mode)",
        "menu_quit": "Quit",
        "menu_update": "Update (v{v})",
        "update_busy": "Downloading update…",
        "update_failed": "Update failed. Please download the new version from the download page.\n\n{err}",
        "update_full": "This update needs a full download. Opening the download page.",
        "name_title": "My name",
        "name_prompt": "VRChat display name (leave empty to detect it from the log)",
        "already": "The overlay is already running.\n\n[Yes]  Bring it back on screen\n[No]  Quit the overlay\n[Cancel]  Leave it as is",
        "crash": "The overlay stopped because of an error. See error.log in the app folder.",
        "hotkey_busy": "Another program is using Ctrl+Alt+E, so the overlay can't be locked.\nOnce locked, that shortcut is the only way to unlock it. Close that program and restart the overlay.",
    },
    "ja": {
        "waiting": "Ecliptica 入場待ち",
        "resting": "休憩中",
        "field": "フィールド戦闘",
        "defeated": "{boss} 撃破",
        "boss_phase": "(フェーズ{n})",
        "boss_target": "ボスのターゲット",
        "target_me": "自分が狙われています",
        "checking": "確認中",
        "dps_recent": "DPS  直近{n}秒",
        "avg": "戦闘平均",
        "damage": "与ダメージ",
        "taken": "被ダメージ",
        "session": "セッション合計",
        "stage_of": "{i}/{n}",
        "until_jim": "Jim まで あと{n}",
        "next_jim": "次は Jim!",
        "jim_appears": "Jim 登場!!",
        "finding": "ログを探しています",
        "no_log": "VRChat のログがありません。先に VRChat を起動してください",
        "hint": "ドラッグで移動 · マウスを乗せると右下に ⚙ 設定 · Ctrl+Alt+E でロック",
        "hint_name": "自分の名前がまだ分かりません。⚙ 設定で VRChat の表示名を入力するとアグロ通知が有効になります。",
        "menu_lock": "ロック (クリック透過)   Ctrl+Alt+E",
        "menu_bg": "背景を透明にする",
        "menu_sound": "アグロ通知音",
        "menu_alpha": "全体の不透明度",
        "menu_name": "自分の VRChat 名を設定…",
        "menu_fs_fix": "フルスクリーンでも表示する (VRChat 設定)",
        "menu_fs_revert": "VRChat のフルスクリーン設定を元に戻す",
        "fs_detected": "VRChat が「排他フルスクリーン」で動いているため、オーバーレイがゲームに隠れています。\n\n見た目はフルスクリーンのまま、オーバーレイが表示される「ボーダーレスフルスクリーン」に VRChat の設定を変更しますか？\n\n変更するのは VRChat の画面モード設定ひとつだけで、⚙ 設定のトラブル対処からいつでも元に戻せます。",
        "fs_confirm": "VRChat のフルスクリーン方式を「ボーダーレスフルスクリーン」に変更しますか？\n見た目は同じフルスクリーンですが、オーバーレイが上に表示されるようになります。\n\n⚙ 設定のトラブル対処からいつでも元に戻せます。",
        "fs_wait": "VRChat が起動中のため、今は変更できません。(VRChat は終了時に設定を上書きするため)\n\nVRChat を終了すると自動で適用されます。",
        "fs_done": "適用しました。次に VRChat を起動すると、フルスクリーンでもオーバーレイが表示されます。",
        "fs_reverted": "VRChat のフルスクリーン設定を元に戻しました。",
        "fs_already": "VRChat はすでにボーダーレスフルスクリーンに設定されています。\nそれでも隠れる場合は、Steam の起動オプションに -window-mode borderless を追加してください。",
        "fs_not_found": "VRChat の画面設定が見つかりませんでした。\nVRChat を一度起動して終了してから再度お試しいただくか、Steam の起動オプションに -screen-fullscreen 1 -window-mode borderless を追加してください。",
        "fs_failed": "VRChat の設定を変更できませんでした。app フォルダの error.log を確認してください。",
        "warn_debug": "VRChat の起動オプションに --enable-udon-debug-logging がありません。一部の情報がログに記録されない可能性があります。(⚙ 設定 → トラブル対処)",
        "menu_launch_help": "VRChat 起動オプションの案内…",
        "menu_dict": "ショップのアップグレード辞典   Ctrl+Alt+D",
        "menu_dict_auto": "ショップで辞典を自動で開く",
        "hint_dict": "Ctrl+Alt+D でショップのアップグレード辞典を開く",
        "notice": "再配布禁止 · 配布元: chatmdgus.github.io/kuruma-downloads",
        "menu_dict_close": "ステージ開始時に辞典を閉じる",
        "dict_title": "アップグレード辞典",
        "dict_all": "すべて", "dict_search": "検索",
        "dict_legend": "(+N) 重ねるごとに加算される値   赤い行はデメリット   効果名をクリックで説明",
        "dict_effects": "効果", "dict_buff": "バフ", "dict_debuff": "デバフ", "dict_sources": "入手元",
        "dict_dot": "継続ダメージ", "dict_other": "その他",
        "dict_runes": "ルーン",
        "dict_rune_title": "ルーン",
        "dict_curse_title": "ルーンの呪い",
        "dict_equipped": "装備中",
        "dict_rune_hint": "ルーン名をクリックで装備マーク (最大4つ) · 呪い名をクリックで重複 +1 (4の次は0)",
        "dict_rune_note": "ルーンは Penumbra フェーズからスロットごとに順に有効になり、そのたびにランダムな呪いが付きます。呪いはランが終わると自動で消えます。",
        "dict_curse_reset": "呪いをすべて消す",
        "ov_curses": "呪い",
        "dict_move_hint": "タイトルをドラッグで移動 · 角でサイズ変更 · Esc か Ctrl+Alt+D で閉じる",
        "dict_source": "出典: Ecliptica Wiki (ruralist, WhereFernsGrow) · CC BY-SA 4.0 · 日本語訳は本ツールによる翻訳",
        "dict_credits": "クレジット",
        "menu_credits": "クレジット / ボスターゲットの案内",
        "credits_text": "Ecliptica Overlay クレジット\n\nアップグレード辞典・ボス・マップの情報\n· Ecliptica Wiki (ecliptica.miraheze.org): ruralist, WhereFernsGrow\n· ライセンス: CC BY-SA 4.0（辞典データ app\\data\\upgrades_en.json も同じライセンス）\n· 韓国語・日本語の説明: 英語 Wiki の原文を本ツールで翻訳\n\nアイコン\n· アップグレードアイコン: Ana T\n· ボスアイコン: TheWIPArtist\n· 効果アイコン: OccyBee\n· アーティファクト・職業アイコン: Blacksheepiess\n\nEcliptica のすべてのゲームコンテンツは Ecliptica 制作チームに帰属します。",
        "target_notice": "ボスのターゲット表示について\n\nボスが誰を狙っているかは、自分の画面で自分だけが参考にしてください。\n\nEcliptica 制作チームによると、この情報をゲーム内で他のプレイヤーに広めると BAN される可能性があり、ボイスやチャットで伝えることも推奨されないグレーゾーンです。\n\nこの案内は⚙ 設定の「クレジット」からもう一度確認できます。",
        "dict_empty": "該当するものがありません。",
        "dict_stack": "重複",
        "dict_class": "職業", "dict_my_class": "自分の職業", "dict_class_title": "{name} 専用アップグレード",
        "dict_pinned": "固定", "dict_pin": "◆ この職業を自分の職業に固定", "dict_unpin": "固定を解除（自動に戻す）",
        "menu_my_class": "自分の職業", "my_class_auto": "自動（ログ / 最後に見た職業）",
        "dict_no_class": "職業をまだ認識していません。ステージが始まると自動で認識します。",
        "menu_dict_icons": "辞典の画像を取得（初回のみインターネットを使用）",
        "dict_loading": "画像を取得中… {n}/{total}",
        "menu_theme": "テーマ",
        "menu_colors": "色をカスタマイズ…",
        "menu_effects": "エフェクト",
        "theme_eclipse": "日食 (標準)", "theme_neon": "ネオン", "theme_sakura": "さくら",
        "theme_ocean": "オーシャン", "theme_mono": "モノクロ", "theme_rainbow": "レインボー (色が流れる)",
        "theme_snow": "スノー", "theme_poison": "ポイズン", "theme_autumn": "オータム", "theme_zomuregi": "レギ", "theme_kuruma": "くるま",
        "menu_volume": "通知音の音量",
        "fx_glow": "ネオングロー", "fx_gradient": "グラデーション", "fx_anim": "数字アニメーション",
        "fx_pulse": "アグロ点滅",
        "col_corona": "DPS の数字・アクセント", "col_corona2": "グラデーションの終わり", "col_text": "文字",
        "col_dim": "説明文字", "col_blood": "アグロ帯 (自分)", "col_blood2": "アグロ帯のグラデーション",
        "col_outline": "縁取り (背景透明時)", "col_night": "パネル背景", "col_rim": "パネルの枠",
        "col_band": "パネル内の帯",
        "colors_title": "色の設定", "colors_change": "変更", "colors_reset": "このテーマを初期値に戻す",
        "colors_close": "閉じる", "colors_note": "変更した色はテーマごとに保存されます。",
        "menu_warn_debug": "起動オプションの警告を表示",
        "launch_help": "Steam のライブラリで VRChat を右クリック → プロパティ → 起動オプションに下の文字列を追加し、VRChat を再起動してください。\nすでに何か入力されている場合は、スペースを空けて後ろに追加してください。\n\n--enable-udon-debug-logging\n\nこの文字列はクリップボードにコピー済みです。貼り付けるだけで大丈夫です。\n\n現在の状態: {state}",
        "launch_on": "有効",
        "launch_off": "無効",
        "launch_unknown": "確認できません (VRChat のログが見つからないか、デモモードです)",
        "menu_quit": "終了",
        "menu_update": "アップデート (v{v})",
        "update_busy": "アップデートをダウンロード中…",
        "update_failed": "アップデートに失敗しました。ダウンロードページから新しく入手してください。\n\n{err}",
        "update_full": "今回のアップデートは全ファイルの再ダウンロードが必要です。ダウンロードページを開きます。",
        "name_title": "自分の名前",
        "name_prompt": "VRChat の表示名 (空欄ならログから自動で認識)",
        "already": "オーバーレイはすでに起動しています。\n\n[はい]  画面に呼び戻す\n[いいえ]  オーバーレイを終了する\n[キャンセル]  そのままにする",
        "crash": "エラーで終了しました。app フォルダの error.log を確認してください。",
        "hotkey_busy": "他のプログラムが Ctrl+Alt+E を使用しているため、ロックできません。\nロック中はこのショートカットでしか解除できないためです。そのプログラムを終了してからオーバーレイを起動し直してください。",
    },
}
LANG_NAMES = [("ko", "한국어"), ("en", "English"), ("ja", "日本語")]
UI_FONTS = {
    "ko": ["Malgun Gothic", "맑은 고딕", "Apple SD Gothic Neo", "Noto Sans CJK KR"],
    "ja": ["Yu Gothic UI", "Meiryo UI", "Meiryo", "Hiragino Sans", "Noto Sans CJK JP"],
    "en": ["Segoe UI", "Helvetica Neue", "Noto Sans", "DejaVu Sans"],
}


def detect_lang():
    try:
        if IS_WINDOWS:
            import ctypes
            primary = ctypes.windll.kernel32.GetUserDefaultUILanguage() & 0x3FF
            return {0x12: "ko", 0x11: "ja"}.get(primary, "en")
        import locale
        code = (locale.getlocale()[0] or "").lower()
        return "ko" if code.startswith("ko") else "ja" if code.startswith("ja") else "en"
    except Exception:
        return "en"


def tr(lang, key, **kw):
    text = STRINGS.get(lang, STRINGS["en"]).get(key) or STRINGS["en"][key]
    return text.format(**kw) if kw else text


def _version_tuple(v):
    return tuple(int(x) for x in re.findall(r"\d+", str(v))[:3]) or (0,)


def _fetch(url, timeout):
    import urllib.request
    req = urllib.request.Request(url, headers={"User-Agent": "EclipticaOverlay/" + APP_VERSION})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read()


def check_update():
    """새 버전이 있으면 사이트의 정보(dict), 없으면 None"""
    data = json.loads(_fetch(UPDATE_MANIFEST + "?t=" + str(int(time.time())), 8).decode("utf-8"))
    return data if _version_tuple(data.get("version")) > _version_tuple(APP_VERSION) else None


def apply_update(info):
    """app 폴더 안의 파일만 교체. 설정 파일과 아이콘 폴더는 건드리지 않는다"""
    import hashlib
    import io
    import shutil
    import zipfile
    blob = _fetch(info["app_zip"], 90)
    if hashlib.sha256(blob).hexdigest() != info.get("app_sha256"):
        raise ValueError("checksum mismatch")
    keep = {os.path.basename(CONFIG_PATH).lower()}
    z = zipfile.ZipFile(io.BytesIO(blob))
    names = []
    for n in z.namelist():
        if n.endswith("/"):
            continue
        parts = n.replace("\\", "/").split("/")
        if n.startswith(("/", "\\")) or ".." in parts or ":" in n:
            raise ValueError("bad path: " + n)
        if n.lower() in keep or parts[:2] == ["data", "icons"]:
            continue
        names.append(n)
    if "ecliptica_overlay.py" not in names:
        raise ValueError("package has no program file")
    staging = tempfile.mkdtemp(prefix="update-", dir=APP_DIR)
    try:
        for n in names:   # 먼저 전부 풀어 두고 나서 한꺼번에 바꾼다
            dst = os.path.join(staging, *n.split("/"))
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            with open(dst, "wb") as f:
                f.write(z.read(n))
        for n in names:
            target = os.path.join(APP_DIR, *n.split("/"))
            os.makedirs(os.path.dirname(target), exist_ok=True)
            if os.path.exists(target):
                shutil.copy2(target, target + ".bak")
            os.replace(os.path.join(staging, *n.split("/")), target)
    finally:
        shutil.rmtree(staging, ignore_errors=True)


def restart_after_update():
    import subprocess
    script = os.path.abspath(sys.argv[0])
    args = [sys.executable, script] + [a for a in sys.argv[1:] if a != "--after-update"] + ["--after-update"]
    flags = 0x00000008 if IS_WINDOWS else 0   # DETACHED_PROCESS
    subprocess.Popen(args, cwd=os.path.dirname(script), close_fds=True, creationflags=flags)


# ---------------------------------------------------------------------------
# 오버레이 UI
# ---------------------------------------------------------------------------
# 테마: 각 색의 역할
#   corona  DPS 숫자, 강조색          corona2 그라데이션 끝 색 (그래프 낮은 쪽)
#   text    일반 글자                 dim     설명 글자
#   blood   내가 어그로일 때 띠       blood2  어그로 띠 그라데이션 끝 색
#   outline 투명 배경일 때 외곽선     night   패널 배경
#   rim     패널 테두리               band    패널 안쪽 띠
THEME_KEYS = ["corona", "corona2", "text", "dim", "blood", "blood2", "outline", "night", "rim", "band"]
THEMES = {
    "eclipse": {"corona": "#F4C45A", "corona2": "#FF7A45", "text": "#ECE8FF", "dim": "#CFC8F5",
                "blood": "#E0425E", "blood2": "#FF8A3D", "outline": "#07050F",
                "night": "#17132E", "rim": "#332C5E", "band": "#221C43"},
    "neon":    {"corona": "#3DF5FF", "corona2": "#FF3CF2", "text": "#F2FBFF", "dim": "#A9EEFF",
                "blood": "#FF2E88", "blood2": "#FFB800", "outline": "#0B0226",
                "night": "#0B0620", "rim": "#3A1E7A", "band": "#1A0F3D"},
    "sakura":  {"corona": "#FF8FB8", "corona2": "#FFD6A5", "text": "#FFF5FA", "dim": "#FFC9DD",
                "blood": "#FF4F7B", "blood2": "#C86BFF", "outline": "#3A0E24",
                "night": "#2A1320", "rim": "#5C2A44", "band": "#3A1A2C"},
    "ocean":   {"corona": "#5EE6C8", "corona2": "#4FA3FF", "text": "#EAFBFF", "dim": "#B0E6F2",
                "blood": "#FF6B6B", "blood2": "#FFC857", "outline": "#031A22",
                "night": "#0B1F2A", "rim": "#1D4656", "band": "#123140"},
    "mono":    {"corona": "#FFFFFF", "corona2": "#9A9A9A", "text": "#FFFFFF", "dim": "#D0D0D0",
                "blood": "#FF3B3B", "blood2": "#FF9A9A", "outline": "#000000",
                "night": "#111111", "rim": "#3A3A3A", "band": "#1E1E1E"},
    "rainbow": {"corona": "#FF5E7E", "corona2": "#5EC8FF", "text": "#FFFFFF", "dim": "#E2DDFF",
                "blood": "#FF2E88", "blood2": "#FFB800", "outline": "#0A0616",
                "night": "#120C24", "rim": "#3B2A66", "band": "#1E1540"},
}
THEMES.update({
    # 스노우: 흰색 바탕 + 하늘색 (밝은 테마)
    "snow":    {"corona": "#1E8FE0", "corona2": "#8FD3FF", "text": "#1B2A3A", "dim": "#5C7690",
                "blood": "#FF5A7A", "blood2": "#FF9FB4", "outline": "#F4F8FC",
                "night": "#F7FAFD", "rim": "#B7D3EA", "band": "#E6F0F9"},
    # 독: 초록 + 검정
    "poison":  {"corona": "#7CFF4F", "corona2": "#1FAF3A", "text": "#E8FFE0", "dim": "#9FD99A",
                "blood": "#D4FF3A", "blood2": "#39D353", "outline": "#020402",
                "night": "#070A07", "rim": "#1F4D1F", "band": "#0E1A0E"},
    # 낙엽: 주황 위주
    "autumn":  {"corona": "#FF9F2E", "corona2": "#D9481E", "text": "#FFF3E6", "dim": "#F2C9A0",
                "blood": "#E8452C", "blood2": "#FFB347", "outline": "#140A04",
                "night": "#1E120A", "rim": "#6B3A1A", "band": "#2A180D"},
})
THEMES["zomuregi"] = {
    # 조무래기: 짙은 보라 바탕에 라벤더빛이 은은하게 도는 테마
    "corona": "#C792FF", "corona2": "#7B4DFF", "text": "#F3EAFF", "dim": "#C8B3EE",
    "blood": "#FF4FA3", "blood2": "#B26BFF", "outline": "#0A0612",
    "night": "#140C22", "rim": "#5B3A8C", "band": "#21143A"}
THEMES["kuruma"] = {
    # 쿠루마: 빨간색 테마 (어그로 띠는 빨강과 구분되게 금색~주황)
    "corona": "#FF3B3B", "corona2": "#B3122B", "text": "#FFF0F0", "dim": "#F0B3B8",
    "blood": "#FFC83D", "blood2": "#FF7A1A", "outline": "#0D0405",
    "night": "#1A0A0C", "rim": "#6E1F27", "band": "#2A0F13"}
THEME_ORDER = ["eclipse", "neon", "sakura", "ocean", "mono", "rainbow", "snow", "poison", "autumn", "zomuregi", "kuruma"]
FX_DEFAULTS = {"glow": True, "gradient": True, "anim": True, "pulse": True}
KEY_COLOR = "#010203"      # 이 색은 창에서 완전히 투명하게 뚫린다
WARN_COLOR = "#FFB347"


def hex_to_rgb(h):
    h = h.lstrip("#")
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def rgb_to_hex(r, g, b):
    c = lambda v: max(0, min(255, int(round(v))))
    return "#%02X%02X%02X" % (c(r), c(g), c(b))


def mix(a, b, t):
    """두 색을 t(0~1) 비율로 섞는다"""
    ra, ga, ba = hex_to_rgb(a)
    rb, gb, bb = hex_to_rgb(b)
    return rgb_to_hex(ra + (rb - ra) * t, ga + (gb - ga) * t, ba + (bb - ba) * t)


def luminance(h):
    r, g, b = (v / 255 for v in hex_to_rgb(h))
    return 0.2126 * r + 0.7152 * g + 0.0722 * b


def hsv_hex(h, s, v):
    import colorsys
    r, g, b = colorsys.hsv_to_rgb(h % 1.0, s, v)
    return rgb_to_hex(r * 255, g * 255, b * 255)


def safe_color(h):
    """투명 처리용 색과 겹치면 그 부분이 뚫려 버리므로 살짝 비켜간다"""
    return "#020304" if h.upper() == KEY_COLOR.upper() else h.upper()


# 네온 글로우용 바깥 고리 (반지름 3)
GLOW_RING = [(3, 0), (-3, 0), (0, 3), (0, -3), (2, 2), (2, -2), (-2, 2), (-2, -2)]


def pick_font(root, candidates, fallback="TkDefaultFont"):
    families = set(tkfont.families(root))
    for name in candidates:
        if name in families:
            return name
    return fallback


def fmt_num(n):
    return f"{int(round(n)):,}"


def fmt_time(sec):
    return f"{sec // 60}:{sec % 60:02d}"


def draw_gear(c, cx, cy, r, color, hole):
    """톱니바퀴 아이콘: 이 8개 + 가운데 구멍"""
    pts = []
    for i in range(48):
        a = math.pi * 2 * i / 48
        rr = r * (1.0 if (i // 3) % 2 == 0 else 0.72)
        pts += [cx + rr * math.cos(a), cy + rr * math.sin(a)]
    c.create_polygon(pts, fill=color, outline="")
    c.create_oval(cx - r * 0.34, cy - r * 0.34, cx + r * 0.34, cy + r * 0.34, fill=hole, outline="")


def round_rect(c, x1, y1, x2, y2, r, **kw):
    pts = [x1 + r, y1, x2 - r, y1, x2, y1, x2, y1 + r, x2, y2 - r, x2, y2,
           x2 - r, y2, x1 + r, y2, x1, y2, x1, y2 - r, x1, y1 + r, x1, y1]
    return c.create_polygon(pts, smooth=True, **kw)


UI_RADIUS = 18        # 오버레이 패널 모서리
BOSS_ICON = 38        # 오버레이 왼쪽 위 보스 아이콘 칸 크기
BAND_RADIUS = 13      # 오버레이 안쪽 띠
BUTTON_RADIUS = 10    # 사전 창 버튼


def round_window_corners(tkwin):
    """Windows 11의 둥근 창 모서리를 켠다 (Windows 10에서는 아무 일도 일어나지 않음)"""
    if not IS_WINDOWS:
        return
    try:
        import ctypes
        pref = ctypes.c_int(2)                       # DWMWCP_ROUND
        ctypes.windll.dwmapi.DwmSetWindowAttribute(ctypes.c_void_p(_hwnd_of(tkwin)), 33,   # DWMWA_WINDOW_CORNER_PREFERENCE
                                                   ctypes.byref(pref), ctypes.sizeof(pref))
    except Exception:
        pass


class RoundButton(tk.Canvas):
    """모서리가 둥근 버튼. tk.Label 버튼처럼 configure(text=, bg=, fg=)로 바꿀 수 있다."""

    def __init__(self, master, text, font, bg="#333333", fg="#FFFFFF", padx=10, pady=5,
                 radius=BUTTON_RADIUS, command=None):
        self._text, self._font, self._fill, self._fg = text, font, bg, fg
        self._padx, self._pady, self._r, self._hover = padx, pady, radius, False
        f = tkfont.Font(font=font)
        self._fh = f.metrics("linespace")
        super().__init__(master, width=f.measure(text) + padx * 2, height=self._fh + pady * 2,
                         highlightthickness=0, bd=0, bg=master.cget("bg"), cursor="hand2")
        self.bind("<Configure>", lambda e: self._draw())
        self.bind("<Enter>", lambda e: self._set_hover(True))
        self.bind("<Leave>", lambda e: self._set_hover(False))
        if command:
            self.bind("<Button-1>", lambda e: command())
        self._draw()

    def _set_hover(self, on):
        self._hover = on
        self._draw()

    def _draw(self):
        self.delete("all")
        w = self.winfo_width() if self.winfo_width() > 1 else int(self["width"])
        h = self.winfo_height() if self.winfo_height() > 1 else int(self["height"])
        fill = mix(self._fill, "#FFFFFF", 0.12) if self._hover else self._fill
        r = min(self._r, h // 2)
        round_rect(self, 1, 1, w - 1, h - 1, r, fill=fill, outline="")
        self.create_text(w / 2, h / 2, text=self._text, font=self._font, fill=self._fg)

    def configure(self, cnf=None, **kw):
        changed = False
        for key, attr in (("text", "_text"), ("bg", "_fill"), ("fg", "_fg")):
            if key in kw:
                setattr(self, attr, kw.pop(key))
                changed = True
        if "text" in (cnf or {}):
            pass
        if kw or cnf:
            super().configure(cnf, **kw)
        if changed:
            self._draw()

    config = configure


class ColorDialog:
    """테마 색을 항목별로 바꾸는 작은 설정 창. 바꾸는 즉시 오버레이에 반영된다."""

    def __init__(self, overlay):
        from tkinter import colorchooser
        self.ov = overlay
        self.colorchooser = colorchooser
        t = overlay.t
        self.win = tk.Toplevel(overlay.root)
        self.win.title(t("colors_title"))
        self.win.attributes("-topmost", True)
        self.win.resizable(False, False)
        self.win.configure(bg="#1B1A22", padx=14, pady=12)
        self.win.after(50, lambda: round_window_corners(self.win))
        self.win.protocol("WM_DELETE_WINDOW", self.close)
        font = (overlay.f_ui[0], 10)
        self.header = tk.Label(self.win, font=(overlay.f_ui[0], 11, "bold"), fg="#FFFFFF", bg="#1B1A22")
        self.header.grid(row=0, column=0, columnspan=3, sticky="w", pady=(0, 8))
        self.swatches = {}
        for row, key in enumerate(THEME_KEYS, start=1):
            tk.Label(self.win, text=t("col_" + key), font=font, fg="#E6E3F0", bg="#1B1A22",
                     anchor="w").grid(row=row, column=0, sticky="w", padx=(0, 12), pady=3)
            sw = tk.Label(self.win, width=4, relief="flat", bd=0, cursor="hand2")
            sw.grid(row=row, column=1, padx=(0, 8), pady=3, ipady=3)
            sw.bind("<Button-1>", lambda e, k=key: self.pick(k))
            self.swatches[key] = sw
            tk.Button(self.win, text=t("colors_change"), font=font, command=lambda k=key: self.pick(k),
                      relief="flat", bg="#2C2A38", fg="#FFFFFF", activebackground="#3A3848",
                      activeforeground="#FFFFFF", padx=10).grid(row=row, column=2, pady=3, sticky="ew")
        n = len(THEME_KEYS) + 1
        tk.Label(self.win, text=t("colors_note"), font=(overlay.f_ui[0], 9), fg="#9D99B0",
                 bg="#1B1A22").grid(row=n, column=0, columnspan=3, sticky="w", pady=(10, 6))
        bar = tk.Frame(self.win, bg="#1B1A22")
        bar.grid(row=n + 1, column=0, columnspan=3, sticky="ew")
        tk.Button(bar, text=t("colors_reset"), font=font, command=self.reset, relief="flat",
                  bg="#2C2A38", fg="#FFFFFF", padx=10).pack(side="left")
        tk.Button(bar, text=t("colors_close"), font=font, command=self.close, relief="flat",
                  bg="#4B3F8F", fg="#FFFFFF", padx=14).pack(side="right")
        self.refresh()

    def refresh(self):
        ov = self.ov
        self.header.config(text=f"{ov.t('menu_theme')}: {ov.t('theme_' + ov.theme)}")
        pal = ov.compute_palette()
        for key, sw in self.swatches.items():
            sw.config(bg=pal[key])

    def pick(self, key):
        current = self.ov.compute_palette()[key]
        result = self.colorchooser.askcolor(color=current, parent=self.win, title=self.ov.t("col_" + key))
        if result and result[1]:
            self.ov.set_custom_color(key, result[1].upper())
            self.refresh()

    def reset(self):
        self.ov.reset_custom_colors()
        self.refresh()

    def close(self):
        self.win.destroy()
        self.ov.color_dialog = None


UPGRADE_DATA_PATH = os.path.join(APP_DIR, "data", "upgrades_en.json")
RARITY_COLORS = {"Common": "#C3C8D4", "Rare": "#5AA9FF", "Legendary": "#FFB347"}
ELEMENT_COLORS = {"물리": "#E6E1D3", "화염": "#FF8A4C", "냉기": "#7FD4FF", "전격": "#FFE45C",
                  "신성": "#FFF1A8", "암흑": "#B58CFF", "독": "#8BE36B"}
SHOP_COLORS = {"endurance": "#46D17C", "mobility": "#4C9DFF", "chrono": "#FF5A60",   # 인내 초록, 기동성 파랑, 크로노 빨강
               "class": "#B98CFF"}                                                     # 직업 보라


EFFECT_COLORS = {"buff": "#5FDCC3", "debuff": "#FF9F6B",   # 버프 청록, 디버프 주황
                 "dot": "#FF7A7A", "other": "#B9A8E8"}      # 지속 피해 빨강, 기타 연보라
EFFECT_BUTTON = "#5FDCC3"
RUNE_COLOR = "#E8C15A"     # 룬 금색
CURSE_COLOR = "#E0607A"    # 룬 저주 붉은색
# 일반 능력치와 이름이 겹치는 효과는 효과로 쓰인 경우만 인식한다
# (예: "방어를 4중첩 부여"는 효과, "냉기 방어 +15%", "방어력", "방어를 관통"은 효과가 아님)
AMBIGUOUS_EFFECTS = {"힘", "방어", "회복", "가속", "광란", "무적"}


def build_effect_regex(effects):
    parts = []
    for e in sorted(effects, key=lambda e: len(e["ko"]), reverse=True):
        name = re.escape(e["ko"])
        if e["ko"] in AMBIGUOUS_EFFECTS:
            parts.append(rf"(?<![가-힣]){name}(?=을|를(?! 관통)|,|\s?\d|\s부여)")
        else:
            parts.append(rf"(?<![가-힣]){name}(?=[^가-힣]|을|를|이|가|은|는|의|$)")
    return re.compile("|".join(parts)) if parts else None


def class_key(name):
    """로그의 직업 이름(Shieldmage, Shield Mage 등)을 사전의 직업 id로"""
    return re.sub(r"[^a-z]", "", (name or "").lower())
ICON_DIR = os.path.join(APP_DIR, "data", "icons")
ICON_TILE = 46
DICT_MIN_W, DICT_MIN_H = 460, 360     # 상점 탭 4개가 잘리지 않는 최소 크기
try:
    from PIL import Image as PILImage, ImageDraw as PILDraw, ImageTk as PILImageTk
    HAS_PIL = True
except Exception:
    HAS_PIL = False


# 난이도 단계: 로그에는 없어서 스테이지 번호로 정한다
# (위키의 보스 등장 구간과 실제 로그의 스테이지 번호를 대조해서 찾은 경계)
PHASE_BANDS = [(4, "Prime"), (6, "Penumbra"), (8, "Antumbra"), (10, "Umbra"), (13, "Eclipse")]


def phase_of_stage(i):
    for last, name in PHASE_BANDS:
        if i <= last:
            return name
    return PHASE_BANDS[-1][1]


def boss_key(name):
    """보스 이름 비교용: 대소문자, 띄어쓰기, 기호, 앞의 The 를 무시 (Jacked O' Lantern == Jacked-O-Lantern)"""
    return re.sub(r"[^a-z0-9]", "", re.sub(r"^the\s+", "", (name or "").strip().lower()))


def icon_url_candidates(url):
    """위키 이미지 주소 후보: 원본 -> 128px 썸네일 -> 위키의 파일 주소(다른 서버로 안내됨)"""
    out = [url]
    m = re.match(r"https://static\.wikitide\.net/(\w+)/(\w)/(\w\w)/(.+)$", url)
    if m:
        db, a, ab, name = m.groups()
        out.append(f"https://static.wikitide.net/{db}/thumb/{a}/{ab}/{name}/128px-{name}")
        out.append(f"https://ecliptica.miraheze.org/wiki/Special:FilePath/{name}")
    return out


class IconStore:
    """업그레이드 아이콘을 위키에서 한 번만 받아 app/data/icons 에 저장해 두고 쓴다."""

    def __init__(self):
        self.busy = False
        self.progress = 0
        self.total = 0
        self.finished = 0          # 받기가 끝날 때마다 1 증가 (화면 갱신 신호)

    @staticmethod
    def path(icon_id):
        return os.path.join(ICON_DIR, icon_id + ".img")

    def has(self, icon_id):
        return os.path.exists(self.path(icon_id))

    def download_missing(self, upgrades):
        if self.busy or not HAS_PIL:
            return
        todo = {}
        for u in upgrades:
            if u.get("icon") and u.get("icon_id") and not self.has(u["icon_id"]):
                todo[u["icon_id"]] = u["icon"]
        if not todo:
            return
        self.busy, self.progress, self.total = True, 0, len(todo)

        def run():
            import io
            import urllib.error
            import urllib.request
            failures = []
            got = 0
            try:
                os.makedirs(ICON_DIR, exist_ok=True)
                for icon_id, url in todo.items():
                    ok = False
                    for candidate in icon_url_candidates(url):
                        try:
                            req = urllib.request.Request(candidate, headers={
                                "User-Agent": ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                                               "(KHTML, like Gecko) Chrome/124.0 Safari/537.36 EclipticaOverlay/2.0"),
                                "Accept": "image/png,image/webp,image/*;q=0.8,*/*;q=0.5",
                                "Referer": "https://ecliptica.miraheze.org/"})
                            with urllib.request.urlopen(req, timeout=10) as r:
                                data = r.read(3_000_000)
                            PILImage.open(io.BytesIO(data)).verify()   # 이미지가 맞는지 확인
                            tmp = self.path(icon_id) + ".part"
                            with open(tmp, "wb") as f:
                                f.write(data)
                            os.replace(tmp, self.path(icon_id))
                            ok = True
                            got += 1
                            break
                        except urllib.error.HTTPError as e:
                            failures.append(f"HTTP {e.code} {candidate}")
                        except Exception as e:
                            failures.append(f"{type(e).__name__}: {e} ({candidate})")
                    self.progress += 1
                    if not ok and got == 0 and len(failures) >= 9:
                        break      # 처음부터 계속 실패하면 인터넷이 막힌 것으로 보고 멈춘다 (다음 실행 때 다시 시도)
            finally:
                self.busy = False
                self.finished += 1
                if failures:
                    # 무엇이 문제인지 알 수 있게 기록해 둔다
                    try:
                        with open(os.path.join(APP_DIR, "error.log"), "a", encoding="utf-8") as f:
                            f.write(f"--- {datetime.now()} [icon download] 받음 {got}개 / 실패 {len(failures)}건 ---\n")
                            for line in failures[:6]:
                                f.write("  " + line + "\n")
                    except OSError:
                        pass

        threading.Thread(target=run, daemon=True).start()


# 데이터 속 {el:id} 표시용 속성 이름과 색
ELEMENT_NAMES = {
    "physical": {"ko": "물리", "en": "PHYSICAL", "ja": "物理"},
    "fire": {"ko": "화염", "en": "FIRE", "ja": "炎"},
    "frost": {"ko": "냉기", "en": "FROST", "ja": "冷気"},
    "lightning": {"ko": "전기", "en": "ELECTRIC", "ja": "電気"},
    "holy": {"ko": "빛", "en": "LUMINOUS", "ja": "光"},
    "dark": {"ko": "그림자", "en": "SHADOW", "ja": "影"},
    "venom": {"ko": "독", "en": "POISON", "ja": "毒"},
    "elemental": {"ko": "원소", "en": "ELEMENTAL", "ja": "属性"},
}
ELEMENT_ID_COLORS = {"physical": "#E6E1D3", "fire": "#FF8A4C", "frost": "#7FD4FF", "lightning": "#FFE45C",
                     "holy": "#FFF1A8", "dark": "#B58CFF", "venom": "#8BE36B", "elemental": "#C9B8FF"}
# {eff:id} 또는 {eff:id:표시할 글자}  (영어 원문은 위키에 적힌 글자를 그대로 보여준다)
RE_TOKEN = re.compile(r"\{(eff|el):(\w+)(?::([^}]+))?\}")
STACK_I18N = {
    "합연산": ("Additive", "加算"),
    "곱연산": ("Multiplicative", "乗算"),
    "합연산 / 곱연산 (100% 방지)": ("Additive / Multiplicative (never reaches 100%)", "加算 / 乗算 (100%には達しない)"),
    "합연산 / 곱연산 (0% 방지)": ("Additive / Multiplicative (never reaches 0%)", "加算 / 乗算 (0%には達しない)"),
    "곱연산 (0% 방지)": ("Multiplicative (never reaches 0%)", "乗算 (0%には達しない)"),
    "곱연산 (100% 방지) / 합연산": ("Multiplicative (never reaches 100%) / Additive", "乗算 (100%には達しない) / 加算"),
    "합연산 (다른 스킬과는 곱)": ("Additive (multiplicative with other skills)", "加算 (他のスキルとは乗算)"),
}


RE_ELEMENT = re.compile(r"(물리|화염|냉기|전격|신성|암흑|독)(?= (?:데미지|방어|피해))")


def load_upgrade_data():
    try:
        with open(UPGRADE_DATA_PATH, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data if data.get("upgrades") else None
    except (OSError, ValueError):
        return None


class UpgradeDictionary:
    """상점·직업 업그레이드와 효과를 Ecliptica 위키 기준으로 정리해 보여주는 창"""

    def __init__(self, overlay, data):
        self.ov, self.data = overlay, data
        self.shop = "all"
        self.rarity = "all"
        self.tiles = {}              # (아이콘, 상점색, 배경색) -> PhotoImage
        self.seen_icon_round = 0
        self.classes = {c["id"]: c for c in data.get("classes", [])}
        self.view_class = self.my_class           # 직업 탭에서 보고 있는 직업
        self.mode = "upgrades"                     # "upgrades", "effects", "runes"
        self.runes = {r["id"]: r for r in data.get("runes", [])}
        self.curses = {c["id"]: c for c in data.get("curses", [])}
        self.effects = {e["id"]: e for e in data.get("effects", [])}
        self.effect_by_name = {e["ko"]: e for e in self.effects.values()}
        self.effect_re = build_effect_regex(list(self.effects.values()))   # 한국어 원본 설명용
        self.small_icons = {}
        self.win = tk.Toplevel(overlay.root)
        self.win.withdraw()
        self.win.overrideredirect(True)          # 제목 표시줄(최소화/닫기 버튼) 없이
        self.win.attributes("-topmost", True)
        self.win.protocol("WM_DELETE_WINDOW", self.hide)
        self.win.bind("<Escape>", lambda e: self.hide())
        self.win.bind("<MouseWheel>", self._wheel)
        geom = overlay.config.get("dict_geom")
        if not geom:
            sw = self.win.winfo_screenwidth()
            geom = f"470x700+{max(0, sw - 510)}+80"
        self.win.geometry(geom)
        self.win.minsize(DICT_MIN_W, DICT_MIN_H)
        self.build()

    # --- 화면 구성 --------------------------------------------------------
    def build(self):
        ov, P, t = self.ov, self.ov.pal, self.ov.t
        self.dark = luminance(P["night"]) < 0.5      # 밝은 테마(스노우 등)면 강조색을 진하게 쓴다
        for w in self.win.winfo_children():
            w.destroy()
        ui = ov.f_ui[0]
        bg, panel = P["night"], mix(P["night"], P["text"], 0.06)
        self.win.title(f"{t('dict_title')} - Ecliptica Overlay")
        self.win.configure(bg=bg, highlightthickness=1, highlightbackground=P["rim"], highlightcolor=P["rim"])

        top = tk.Frame(self.win, bg=bg, padx=12, pady=10)
        top.pack(fill="x")
        title = tk.Label(top, text=t("dict_title"), font=(ui, 13, "bold"), fg=P["text"], bg=bg, cursor="fleur")
        title.pack(side="left")
        for w in (top, title):                      # 제목 줄을 잡고 창 이동
            w.bind("<ButtonPress-1>", self._move_start)
            w.bind("<B1-Motion>", self._move)
            w.bind("<ButtonRelease-1>", lambda e: self._remember_geometry())
        self.search_var = tk.StringVar()
        sbox = tk.Canvas(top, width=122, height=30, bg=bg, highlightthickness=0, bd=0)   # 둥근 검색창
        round_rect(sbox, 1, 1, 121, 29, 13, fill=panel, outline=mix(panel, P["dim"], 0.25))
        entry = tk.Entry(sbox, textvariable=self.search_var, font=(ui, 10), bg=panel, fg=P["text"],
                         insertbackground=P["text"], relief="flat", bd=0, highlightthickness=0)
        sbox.create_window(12, 15, window=entry, anchor="w", width=98)
        sbox.pack(side="right")
        entry.bind("<Button-1>", lambda e: self.win.focus_force())   # 제목 표시줄 없는 창도 입력 받기
        tk.Label(top, text=t("dict_search"), font=(ui, 9), fg=P["dim"], bg=bg).pack(side="right", padx=(0, 6))
        self.search_var.trace_add("write", lambda *a: self.refresh())
        self.effect_button = None
        if self.effects:
            self.effect_button = RoundButton(top, t("dict_effects"), (ui, 10, "bold"), padx=14, pady=4,
                                             command=self.toggle_effects)
            self.effect_button.pack(side="right", padx=(0, 8))
        self.rune_button = None
        if self.runes:
            self.rune_button = RoundButton(top, t("dict_runes"), (ui, 10, "bold"), padx=12, pady=4,
                                           command=self.toggle_runes)
            self.rune_button.pack(side="right", padx=(0, 6))

        self.shop_buttons, self.rarity_buttons = {}, {}
        row1 = tk.Frame(self.win, bg=bg, padx=10)
        row1.pack(fill="x")
        tabs = [("all", t("dict_all"))] + [(sh["id"], self.shop_text(sh, "short")) for sh in self.data["shops"]]
        if self.classes:
            tabs.append(("class", t("dict_class")))
        for i, (key, label) in enumerate(tabs):     # 탭은 창 폭에 맞춰 같은 크기로 늘어난다
            b = RoundButton(row1, label, (ui, 10, "bold"), padx=4, pady=6)
            b.grid(row=0, column=i, sticky="ew", padx=2, pady=(0, 6))
            row1.columnconfigure(i, weight=1, uniform="tabs")
            b.bind("<Button-1>", lambda e, k=key: self.set_shop(k))
            self.shop_buttons[key] = b
        # 직업 탭에서만 보이는 직업 선택 줄
        self.class_row = tk.Frame(self.win, bg=bg, padx=10)
        self.class_buttons = {}
        for i, (cid, c) in enumerate(self.classes.items()):    # 4개씩 두 줄, 같은 크기로
            b = RoundButton(self.class_row, self.class_name(c), (ui, 9, "bold"), padx=2, pady=4)
            b.grid(row=i // 4, column=i % 4, sticky="ew", padx=2, pady=(0, 4))
            self.class_row.columnconfigure(i % 4, weight=1, uniform="cls")
            b.bind("<Button-1>", lambda e, k=cid: self.set_view_class(k))
            self.class_buttons[cid] = b
        self.pin_button = RoundButton(self.class_row, "", (ui, 9, "bold"), pady=4, command=self.toggle_pin)
        self.pin_button.grid(row=2, column=0, columnspan=4, sticky="ew", padx=2, pady=(0, 6))
        self.row1 = row1
        row2 = tk.Frame(self.win, bg=bg, padx=10)
        row2.pack(fill="x")
        self.row2 = row2
        for key in ("all", "Common", "Rare", "Legendary"):
            label = t("dict_all") if key == "all" else key
            b = RoundButton(row2, label, (ui, 9, "bold"), padx=11, pady=3)
            b.pack(side="left", padx=2, pady=(0, 8))
            b.bind("<Button-1>", lambda e, k=key: self.set_rarity(k))
            self.rarity_buttons[key] = b

        foot = tk.Frame(self.win, bg=bg, padx=12, pady=8)
        foot.pack(side="bottom", fill="x")     # 먼저 자리를 잡아야 창이 작아져도 잘리지 않는다
        body = tk.Frame(self.win, bg=bg)
        body.pack(fill="both", expand=True, padx=(10, 4))
        self.text = tk.Text(body, bg=bg, fg=P["text"], relief="flat", wrap="word", cursor="arrow",
                            font=(ui, 10), padx=8, pady=4, highlightthickness=0, bd=0,
                            selectbackground=P["rim"])
        self.text.pack(side="left", fill="both", expand=True)
        tx = self.text
        tx.tag_configure("shop", font=(ui, 12, "bold"), foreground=self.ink(P["corona"]), spacing1=14, spacing3=6)
        tx.tag_configure("shophint", font=(ui, 9), foreground=P["dim"])
        tx.tag_configure("name", font=(ui, 11, "bold"), foreground=P["text"], spacing1=10)
        tx.tag_configure("en", font=(ui, 9), foreground=P["dim"])
        indent = ICON_TILE + 12 if HAS_PIL else 22     # 아이콘 칸이 없으면 들여쓰기도 줄인다
        tx.tag_configure("line", font=(ui, 10), foreground=mix(P["text"], P["night"], 0.12),
                         lmargin1=indent, lmargin2=indent, spacing1=2)
        tx.tag_configure("bad", foreground=self.ink("#FF7B8A"))
        tx.tag_configure("meta", font=(ui, 8), foreground=mix(P["dim"], P["night"], 0.25),
                         lmargin1=indent, spacing1=3)
        for key, col in SHOP_COLORS.items():
            tx.tag_configure("shop_" + key, foreground=self.ink(col))
            tx.tag_configure("bar_" + key, foreground=self.ink(col), font=(ui, 11, "bold"))
        tx.tag_configure("hit", background=mix(P["corona"], P["night"], 0.55))
        tx.tag_configure("empty", font=(ui, 10), foreground=P["dim"], justify="center", spacing1=40)
        for r, c in RARITY_COLORS.items():
            tx.tag_configure("r_" + r, foreground=self.ink(c), font=(ui, 8, "bold"))
            tx.tag_configure("dot_" + r, foreground=self.ink(c), font=(ui, 11, "bold"))
        for el, c in ELEMENT_COLORS.items():
            tx.tag_configure("el_" + el, foreground=self.ink(c), font=(ui, 10, "bold"))
        for el, c in ELEMENT_ID_COLORS.items():
            tx.tag_configure("elid_" + el, foreground=self.ink(c), font=(ui, 10, "bold"))
        tx.tag_configure("note", font=(ui, 9), foreground=mix(P["dim"], P["night"], 0.1), lmargin1=6, lmargin2=6, spacing1=4)
        tx.tag_configure("runehead_rune", foreground=self.ink(RUNE_COLOR))
        tx.tag_configure("runehead_curse", foreground=self.ink(CURSE_COLOR))
        tx.tag_configure("picked", foreground=self.ink(RUNE_COLOR), font=(ui, 9, "bold"))
        tx.tag_configure("curse_reset", foreground=self.ink(CURSE_COLOR), font=(ui, 9, "underline"))
        for kind, c in EFFECT_COLORS.items():
            tx.tag_configure("st_" + kind, foreground=self.ink(c), font=(ui, 10, "bold"))
            tx.tag_configure("effhead_" + kind, foreground=self.ink(c))
        tx.tag_configure("src", font=(ui, 9), foreground=mix(P["dim"], P["night"], 0.1),
                         lmargin1=indent, lmargin2=indent, spacing1=3)
        for eid in self.effects:     # 설명 속 효과 이름을 누르면 효과 목록의 그 효과로 이동
            tx.tag_bind("eff_" + eid, "<ButtonRelease-1>", lambda e, k=eid: None if self._dragged else self.show_effect(k))
            tx.tag_bind("eff_" + eid, "<Enter>", lambda e: self.text.configure(cursor="hand2"))
            tx.tag_bind("eff_" + eid, "<Leave>", lambda e: self.text.configure(cursor="arrow"))
        self.text.bind("<Key>", lambda e: "break" if e.keysym not in ("Up", "Down", "Prior", "Next") else None)
        # 스크롤바 대신: 목록을 잡고 위아래로 끌어서 스크롤 (놓으면 조금 더 미끄러지다 멈춤)
        self._dragged = False
        self._fling_job = None
        self.text.bind("<ButtonPress-1>", self._drag_scroll_start)
        self.text.bind("<B1-Motion>", self._drag_scroll_move)
        self.text.bind("<ButtonRelease-1>", self._drag_scroll_end, add="+")
        self.text.bind("<Double-Button-1>", lambda e: "break")     # 더블클릭으로 글자가 선택되지 않게

        tk.Label(foot, text=t("dict_legend"), font=(ui, 8), fg=P["dim"], bg=bg, anchor="w", justify="left",
                 wraplength=430).pack(fill="x")
        tk.Label(foot, text=t("dict_move_hint"), font=(ui, 8), fg=mix(P["dim"], bg, 0.3), bg=bg,
                 anchor="w", justify="left", wraplength=430).pack(fill="x")
        src = tk.Label(foot, text=t("dict_source") + "  ↗", font=(ui, 9), fg=self.ink(P["corona"]), bg=bg,
                       anchor="w", justify="left", cursor="hand2", pady=2, wraplength=420)
        src.pack(fill="x")
        cred = tk.Label(foot, text=t("dict_credits") + "  ↗", font=(ui, 9, "bold"), fg=self.ink(P["corona"]), bg=bg,
                        anchor="w", cursor="hand2")
        cred.pack(fill="x")
        cred.bind("<Button-1>", lambda e: self.ov.show_credits(parent=self.win))
        src.bind("<Button-1>", lambda e: __import__("webbrowser").open(self.data.get("source_url", "")))
        self.status = tk.Label(foot, text="", font=(ui, 8), fg=P["dim"], bg=bg, anchor="w")
        self.status.pack(fill="x")
        grip = tk.Label(self.win, text="◢", font=(ui, 10), fg=P["dim"], bg=bg, cursor="size_nw_se" if IS_WINDOWS else "sizing")
        grip.place(relx=1.0, rely=1.0, anchor="se", x=-2, y=-1)   # 오른쪽 아래 모서리: 크기 조절
        grip.bind("<ButtonPress-1>", self._resize_start)
        grip.bind("<B1-Motion>", self._resize)
        grip.bind("<ButtonRelease-1>", lambda e: self._remember_geometry())
        self.win.bind("<Configure>", self._remember_geometry)
        self.refresh()
        self._poll_icons()

    # --- 아이콘 ----------------------------------------------------------
    def small_icon(self, effect, size=18):
        """설명 줄 안에 넣는 작은 효과 아이콘 (없으면 None)"""
        if not HAS_PIL:
            return None
        icon_id = effect.get("icon_id", "")
        if not icon_id or not self.ov.icons.has(icon_id):
            return None
        key = (icon_id, size)
        if key not in self.small_icons:
            try:
                im = PILImage.open(self.ov.icons.path(icon_id)).convert("RGBA")
                im.thumbnail((size, size), PILImage.LANCZOS)
                self.small_icons[key] = PILImageTk.PhotoImage(im, master=self.win)
            except Exception:
                log_error("effect icon")
                return None
        return self.small_icons[key]

    def tile(self, u, color=None):
        """상점 색 테두리를 두른 둥근 칸 안에 아이콘. 아이콘이 아직 없으면 빈 칸."""
        if not HAS_PIL:
            return None
        color = color or SHOP_COLORS.get(u.get("shop"), self.ov.pal["corona"])
        bg = self.ov.pal["night"]
        icon_id = u.get("icon_id", "")
        have = bool(icon_id) and self.ov.icons.has(icon_id)
        key = (icon_id if have else "", color, bg)
        if key in self.tiles:
            return self.tiles[key]
        try:
            n, k = ICON_TILE, 3
            big = PILImage.new("RGBA", (n * k, n * k), (0, 0, 0, 0))
            PILDraw.Draw(big).rounded_rectangle(
                (k, k, n * k - k - 1, n * k - k - 1), radius=14 * k,
                fill=hex_to_rgb(mix(bg, color, 0.16)) + (255,), outline=hex_to_rgb(color) + (255,), width=2 * k)
            tile = big.resize((n, n), PILImage.LANCZOS)
            if have:
                im = PILImage.open(self.ov.icons.path(icon_id)).convert("RGBA")
                im.thumbnail((n - 12, n - 12), PILImage.LANCZOS)
                tile.alpha_composite(im, ((n - im.width) // 2, (n - im.height) // 2))
            photo = PILImageTk.PhotoImage(tile, master=self.win)
        except Exception:
            log_error("icon")
            return None
        self.tiles[key] = photo
        return photo

    def _poll_icons(self):
        store = self.ov.icons
        if not self.win.winfo_exists():
            return
        if store.busy:
            self.status.config(text=self.ov.t("dict_loading", n=store.progress, total=store.total))
        elif self.status.cget("text"):
            self.status.config(text="")
        if store.finished != self.seen_icon_round:
            self.seen_icon_round = store.finished
            self.small_icons.clear()
            self.refresh(keep_scroll=True)
        self.win.after(600, self._poll_icons)

    # --- 언어별 내용 -------------------------------------------------------
    @property
    def lang(self):
        return self.ov.lang if self.ov.lang in ("ko", "en", "ja") else "en"

    def loc(self, obj, field):
        """번역이 있으면 번역을, 없으면 한국어 원본을 쓴다"""
        if self.lang != "ko":
            v = (obj.get("i18n") or {}).get(self.lang, {}).get(field)
            if v:
                return v
        return obj.get(field)

    def up_name(self, u):
        return u["ko"] if self.lang == "ko" else self.loc(u, "name") or u["en"]

    def names_of(self, x):
        """항목의 세 언어 이름 {"ko":…, "en":…, "ja":…}"""
        i18n = x.get("i18n") or {}
        return {"ko": x.get("ko") or "",
                "en": (i18n.get("en") or {}).get("name") or x.get("en") or "",
                "ja": (i18n.get("ja") or {}).get("name") or ""}

    def up_sub(self, u):
        """이름 옆 작은 글씨: 지금 언어가 아닌 나머지 두 언어 이름 (영어 원문이 먼저)"""
        names = self.names_of(u)
        order = [lang for lang in ("en", "ja", "ko") if lang != self.lang]
        shown = []
        for lang in order:
            n = names.get(lang)
            if n and n not in shown and n != names.get(self.lang):
                shown.append(n)
        return " · ".join(shown)

    def up_desc(self, u):
        return u["desc"] if self.lang == "ko" else self.loc(u, "desc") or u["desc"]

    def up_variant(self, u):
        return u.get("variant") if self.lang == "ko" else self.loc(u, "variant") or u.get("variant")

    def stack_text(self, u):
        st = u.get("stack", "")
        table = self.data.get("stack_i18n") or {}
        if self.lang == "en" or st not in table:
            return st
        return table[st][0 if self.lang == "ko" else 1]

    def shop_text(self, sh, field):
        if self.lang == "ko":
            return sh.get(field) or sh.get("name")
        return ((sh.get("i18n") or {}).get(self.lang, {}).get(field)) or sh.get(field) or sh.get("name")

    def class_name(self, c):
        return c["name"] if self.lang == "ko" else self.loc(c, "name") or c["en"]

    def eff_name(self, e):
        return e["ko"] if self.lang == "ko" else self.loc(e, "name") or e["ko"]

    def plain(self, line):
        """검색용: 표시({eff:..}, {el:..})를 그 언어의 이름으로 바꾼 글자"""
        def sub(m):
            kind, key, shown = m.group(1), m.group(2), m.group(3)
            if shown:
                return shown
            if kind == "eff" and key in self.effects:
                return self.eff_name(self.effects[key])
            return ELEMENT_NAMES.get(key, {}).get(self.lang, key)
        return RE_TOKEN.sub(sub, line.lstrip("!"))

    def ink(self, color):
        """밝은 바탕에서도 읽히도록, 밝은 테마일 때는 글자용 강조색을 진하게 만든다"""
        return color if getattr(self, "dark", True) else mix(color, "#000000", 0.42)

    # --- 이동 / 크기 조절 / 스크롤 ----------------------------------------
    def _move_start(self, e):
        self._mx, self._my = e.x_root - self.win.winfo_x(), e.y_root - self.win.winfo_y()

    def _move(self, e):
        self.win.geometry(f"+{e.x_root - self._mx}+{e.y_root - self._my}")

    def _resize_start(self, e):
        self._rx, self._ry = e.x_root, e.y_root
        self._rw, self._rh = self.win.winfo_width(), self.win.winfo_height()

    def _resize(self, e):
        w = max(DICT_MIN_W, self._rw + e.x_root - self._rx)
        h = max(DICT_MIN_H, self._rh + e.y_root - self._ry)
        self.win.geometry(f"{w}x{h}+{self.win.winfo_x()}+{self.win.winfo_y()}")

    def _drag_scroll_start(self, e):
        if self._fling_job:
            self.win.after_cancel(self._fling_job)
            self._fling_job = None
        self._dragged = False
        self._drag_y = self._drag_origin = e.y
        self._drag_t = time.time()
        self._velocity = 0.0
        return "break"      # 글자 선택 대신 스크롤

    def _drag_scroll_move(self, e):
        dy = e.y - self._drag_y
        if not self._dragged and abs(e.y - self._drag_origin) < 5:
            return "break"  # 살짝 흔들린 건 클릭으로 본다
        if not self._dragged:
            self._dragged = True
            self.text.configure(cursor="fleur")
        now = time.time()
        dt = max(1e-3, now - self._drag_t)
        self._velocity = 0.7 * self._velocity + 0.3 * (dy / dt)      # 끄는 속도 (픽셀/초)
        self.text.yview_scroll(int(-dy), "pixels")
        self._drag_y, self._drag_t = e.y, now
        return "break"

    def _drag_scroll_end(self, e):
        if self._dragged:
            self.text.configure(cursor="arrow")
            if time.time() - self._drag_t < 0.08 and abs(self._velocity) > 200:
                self._fling(self._velocity)
        return None

    def _fling(self, velocity):
        """놓은 뒤 관성으로 조금 더 미끄러지다가 멈춘다"""
        step = velocity * 0.016
        if abs(step) < 1:
            self._fling_job = None
            return
        self.text.yview_scroll(int(-step), "pixels")
        self._fling_job = self.win.after(16, lambda: self._fling(velocity * 0.9))

    def _wheel(self, e):
        if e.widget is self.text:      # 본문 위에서는 기본 스크롤이 이미 동작한다
            return
        self.text.yview_scroll(int(-e.delta / 120) or (-1 if e.delta > 0 else 1), "units")

    def _style_buttons(self):
        P = self.ov.pal
        effects_mode = self.mode == "effects"
        runes_mode = self.mode == "runes"
        other_mode = self.mode != "upgrades"          # 효과·룬 목록에서는 상점 탭 선택과 아래 줄을 숨긴다
        if self.rune_button is not None:
            self.rune_button.configure(bg=RUNE_COLOR if runes_mode else mix(P["night"], RUNE_COLOR, 0.16),
                                       fg="#0E0B18" if runes_mode else self.ink(RUNE_COLOR))
        if self.effect_button is not None:
            self.effect_button.configure(bg=EFFECT_BUTTON if effects_mode else mix(P["night"], EFFECT_BUTTON, 0.16),
                                         fg="#0E0B18" if effects_mode else self.ink(EFFECT_BUTTON))
        for key, b in self.shop_buttons.items():
            on = key == self.shop and not other_mode
            col = SHOP_COLORS.get(key, P["corona"])
            b.configure(bg=col if on else mix(P["night"], col, 0.14),
                        fg="#0E0B18" if on else self.ink(col))
        if self.classes:
            if self.shop == "class" and not other_mode:
                self.class_row.pack(fill="x", after=self.row1)
            else:
                self.class_row.pack_forget()
            vio = SHOP_COLORS["class"]
            pinned = self.ov.my_class_pin
            if pinned and pinned == self.view_class:
                self.pin_button.configure(text=self.ov.t("dict_unpin"), bg=mix(P["night"], vio, 0.12), fg=self.ink(vio))
            else:
                self.pin_button.configure(text=self.ov.t("dict_pin"), bg=mix(P["night"], vio, 0.22), fg=P["text"])
            for cid, b in self.class_buttons.items():
                on = cid == self.view_class
                mine = cid == self.my_class
                b.configure(text=("◆ " if mine and pinned else "★ " if mine else "") + self.class_name(self.classes[cid]),
                            bg=vio if on else mix(P["night"], vio, 0.12), fg="#0E0B18" if on else self.ink(vio))
        # 희귀도 줄은 직업 선택 줄을 정리한 다음에 배치 (효과 목록에서는 숨김)
        if other_mode:
            self.row2.pack_forget()
        else:
            self.row2.pack(fill="x", after=self.class_row if self.shop == "class" and self.classes else self.row1)
        for key, b in self.rarity_buttons.items():
            on = key == self.rarity
            col = RARITY_COLORS.get(key, P["text"])
            if not self.dark and key != "all":
                col = self.ink(col)
            b.configure(bg=mix(P["night"], col, 0.85 if on else 0.12),
                        fg=(P["night"] if self.dark else "#FFFFFF") if on else col)

    @property
    def my_class(self):
        cid = self.ov.my_class()
        return cid if cid in self.classes else None

    def toggle_effects(self):
        self.mode = "upgrades" if self.mode == "effects" else "effects"
        self.refresh()

    def toggle_runes(self):
        self.mode = "upgrades" if self.mode == "runes" else "runes"
        self.refresh()

    def show_effect(self, eid):
        """효과 목록으로 이동해서 그 효과를 보여준다"""
        self.mode = "effects"
        if self.search_var.get():
            self.search_var.set("")     # (이때 refresh 가 한 번 불린다)
        self.refresh()
        mark = f"eff_{eid}_start"
        if mark in self.text.mark_names():
            self.text.see(mark)
            self.text.yview(mark)

    def set_shop(self, key):
        self.mode = "upgrades"
        self.shop = key
        if key == "class" and self.view_class is None:
            self.view_class = self.my_class or next(iter(self.classes), None)
        self.refresh()

    def set_view_class(self, cid):
        """직업 탭에서 직업을 누르면 그 직업을 보여주고, (고정이 아니면) 내 직업으로 인식한다"""
        self.view_class = cid
        self.ov.on_class_viewed(cid)
        self.refresh()

    def toggle_pin(self):
        if self.ov.my_class_pin and self.ov.my_class_pin == self.view_class:
            self.ov.set_my_class_pin(None)
        else:
            self.ov.set_my_class_pin(self.view_class)

    def my_class_changed(self):
        """내 직업이 바뀌면(로그 인식, 직업 탭, 고정) 오버레이가 호출한다"""
        if self.shop != "class" or self.view_class is None:
            self.view_class = self.my_class
        elif self.my_class:
            self.view_class = self.my_class
        self.refresh(keep_scroll=True)

    def set_rarity(self, key):
        self.rarity = key
        self.refresh()

    def _insert_line(self, line, query):
        tx = self.text
        bad = line.startswith("!")
        body = line[1:] if bad else line
        start = tx.index("end-1c")
        base = ("line", "bad") if bad else ("line",)
        if RE_TOKEN.search(body):
            # 번역문: {eff:id} / {el:id} 표시를 그 언어의 이름으로 바꿔 그린다
            spans = []
            for m in RE_TOKEN.finditer(body):
                kind, key, shown = m.group(1), m.group(2), m.group(3)
                if kind == "eff" and key in self.effects:
                    spans.append((m.start(), m.end(), "effid", (key, shown)))
                elif kind == "el" and key in ELEMENT_NAMES:
                    spans.append((m.start(), m.end(), "elid", (key, shown)))
        else:
            spans = [(m.start(1), m.end(1), "el", m.group(1)) for m in RE_ELEMENT.finditer(body)]
            if self.effect_re is not None:
                spans += [(m.start(), m.end(), "eff", m.group(0)) for m in self.effect_re.finditer(body)]
        spans.sort()
        pos = 0
        for a, b, kind, word in spans:
            if a < pos:
                continue           # 겹치는 부분은 건너뛴다
            tx.insert("end", body[pos:a], base)
            shown = None
            if kind in ("elid", "effid"):
                word, shown = word
            if kind == "elid":
                tx.insert("end", shown or ELEMENT_NAMES[word].get(self.lang, word), ("line", "elid_" + word))
            elif kind == "el":
                tx.insert("end", word, ("line", "el_" + word))
            else:
                eff = self.effects[word] if kind == "effid" else self.effect_by_name[word]
                word = shown or self.eff_name(eff)
                icon = self.small_icon(eff)
                if icon is not None:
                    at = tx.index("end-1c")
                    tx.image_create("end", image=icon, align="center", padx=1)
                    # 줄 맨 앞에 아이콘이 오면 들여쓰기가 아이콘의 태그를 따르므로 같은 태그를 붙인다
                    for tag in base + ("eff_" + eff["id"],):
                        tx.tag_add(tag, at)
                tx.insert("end", word, ("line", "st_" + eff["type"], "eff_" + eff["id"]))
            pos = b
        tx.insert("end", body[pos:] + "\n", base)
        if query:
            self._mark_hits(start, query)

    def _mark_hits(self, start, query):
        tx = self.text
        idx = start
        while True:
            idx = tx.search(query, idx, stopindex="end", nocase=True)
            if not idx:
                break
            end = f"{idx}+{len(query)}c"
            tx.tag_add("hit", idx, end)
            idx = end

    def refresh(self, keep_scroll=False):
        if self.mode == "effects":
            return self.refresh_effects(keep_scroll)
        if self.mode == "runes":
            return self.refresh_runes(keep_scroll)
        self._style_buttons()
        tx, t = self.text, self.ov.t
        scroll = tx.yview()[0] if keep_scroll else 0
        query = self.search_var.get().strip()
        q = query.lower()
        tx.configure(state="normal")
        tx.delete("1.0", "end")
        shown = 0
        sections = []     # (색 키, 제목, 보조 설명, 항목 목록)
        mine = self.my_class
        cls = self.view_class if self.shop == "class" else mine
        if self.shop in ("all", "class") and cls in self.classes:
            c = self.classes[cls]
            tag = ""
            if cls == mine:
                tag = "   ★ " + t("dict_my_class") + (f" ({t('dict_pinned')})" if self.ov.my_class_pin else "")
            sections.append(("class", t("dict_class_title", name=self.class_name(c)),
                             ("" if self.lang == "en" else c["en"]) + tag,
                             [u for u in self.data["upgrades"] if u["shop"] == "class" and u.get("class") == cls]))
        for sh in self.data["shops"]:
            if self.shop in ("all", sh["id"]):
                sections.append((sh["id"], self.shop_text(sh, "name"), self.shop_text(sh, "hint"),
                                 [u for u in self.data["upgrades"] if u["shop"] == sh["id"]]))
        if self.shop == "class" and cls not in self.classes:
            tx.insert("end", t("dict_no_class") + "\n", "empty")
            shown = -1
        for key, title, hint, items in sections:
            items = [u for u in items if self.rarity in ("all", u["rarity"])]
            if q:
                items = [u for u in items if q in " ".join(list(self.names_of(u).values()) + [self.up_name(u)] +
                                                           [self.plain(x) for x in self.up_desc(u)]).lower()]
            if not items:
                continue
            tx.insert("end", "▍", ("shop", "shop_" + key))
            tx.insert("end", title, ("shop", "shop_" + key))
            tx.insert("end", "   " + hint + "\n", ("shop", "shophint"))
            for u in items:
                start = tx.index("end-1c")
                tile = self.tile(u)
                if tile is not None:
                    at = tx.index("end-1c")
                    tx.image_create("end", image=tile, align="center", padx=2)
                    tx.tag_add("name", at)          # 줄 간격이 이름 줄 설정을 따르도록
                    tx.insert("end", "  ", "name")
                else:
                    tx.insert("end", "▍ ", ("name", "bar_" + u["shop"]))
                variant = self.up_variant(u)
                name = self.up_name(u) + (f" ({variant})" if variant else "")
                tx.insert("end", name, "name")
                tx.insert("end", "  " + self.up_sub(u) + "   ", ("name", "en"))
                tx.insert("end", u["rarity"] + "\n", ("name", "r_" + u["rarity"]))
                if q:
                    self._mark_hits(start, query)
                for line in self.up_desc(u):
                    self._insert_line(line, query)
                tx.insert("end", f"{t('dict_stack')}: {self.stack_text(u)}\n", "meta")
                shown += 1
        if shown == 0:
            tx.insert("end", t("dict_empty") + "\n", "empty")
        tx.configure(state="disabled")
        tx.yview_moveto(scroll)

    def refresh_runes(self, keep_scroll=False):
        self._style_buttons()
        tx, t, ov = self.text, self.ov.t, self.ov
        scroll = tx.yview()[0] if keep_scroll else 0
        q = self.search_var.get().strip().lower()
        tx.configure(state="normal")
        tx.delete("1.0", "end")
        tx.insert("end", t("dict_rune_hint") + "\n", "note")
        tx.insert("end", t("dict_rune_note") + "\n", "note")
        sections = (("rune", t("dict_rune_title"), list(self.runes.values()), RUNE_COLOR),
                    ("curse", t("dict_curse_title"), list(self.curses.values()), CURSE_COLOR))
        for kind, title, items, color in sections:
            if q:
                items = [x for x in items if q in " ".join(list(self.names_of(x).values()) + [self.plain(l) for l in
                                                            (self.loc(x, "desc") or []) + (self.loc(x, "stats") or [])]).lower()]
            if not items:
                continue
            tx.insert("end", "▍" + title, ("shop", "runehead_" + kind))
            if kind == "curse" and any(ov.curse_stacks.values()):
                tx.insert("end", "   ", ("shop",))
                tx.insert("end", t("dict_curse_reset"), ("shop", "shophint", "curse_reset"))
            tx.insert("end", "\n", ("shop",))
            for x in items:
                tile = self.tile(x, color=color)
                if tile is not None:
                    at = tx.index("end-1c")
                    tx.image_create("end", image=tile, align="center", padx=2)
                    tx.tag_add("name", at)
                    tx.insert("end", "  ", "name")
                tag = ("pick_" + kind + "_" + x["id"])
                tx.insert("end", self.eff_name(x), ("name", tag))
                tx.insert("end", "  " + self.up_sub(x), ("name", "en"))
                if kind == "rune" and x["id"] in ov.runes_equipped:
                    tx.insert("end", f"   ◆ {t('dict_equipped')} {ov.runes_equipped.index(x['id']) + 1}\n", ("name", "picked"))
                elif kind == "curse" and ov.curse_stacks.get(x["id"], 0):
                    tx.insert("end", f"   ×{ov.curse_stacks[x['id']]}\n", ("name", "picked"))
                else:
                    tx.insert("end", "\n", "name")
                for line in (self.loc(x, "desc") or []) + (self.loc(x, "stats") or []):
                    self._insert_line(line, "")
                tx.tag_bind(tag, "<ButtonRelease-1>", lambda e, k=kind, i=x["id"]: None if self._dragged else self.pick(k, i))
                tx.tag_bind(tag, "<Enter>", lambda e: self.text.configure(cursor="hand2"))
                tx.tag_bind(tag, "<Leave>", lambda e: self.text.configure(cursor="arrow"))
        tx.tag_bind("curse_reset", "<ButtonRelease-1>", lambda e: None if self._dragged else self.pick("reset", None))
        tx.configure(state="disabled")
        tx.yview_moveto(scroll)

    def pick(self, kind, key):
        """룬 장착 표시 / 저주 중첩을 바꾼다 (게임 로그에 기록이 없어서 직접 고른다)"""
        ov = self.ov
        if kind == "rune":
            if key in ov.runes_equipped:
                ov.runes_equipped.remove(key)
            elif len(ov.runes_equipped) < 4:
                ov.runes_equipped.append(key)
        elif kind == "curse":
            ov.curse_stacks[key] = (ov.curse_stacks.get(key, 0) + 1) % 5
            if not ov.curse_stacks[key]:
                del ov.curse_stacks[key]
        elif kind == "reset":
            ov.curse_stacks.clear()
        ov.save_config()
        ov.last_frame = None
        self.refresh(keep_scroll=True)

    def refresh_effects(self, keep_scroll=False):
        self._style_buttons()
        tx, t = self.text, self.ov.t
        scroll = tx.yview()[0] if keep_scroll else 0
        query = self.search_var.get().strip()
        q = query.lower()
        tx.configure(state="normal")
        tx.delete("1.0", "end")
        shown = 0
        for kind, title in (("buff", t("dict_buff")), ("debuff", t("dict_debuff")),
                            ("dot", t("dict_dot")), ("other", t("dict_other"))):
            items = [e for e in self.effects.values() if e["type"] == kind]
            if q:
                items = [e for e in items if q in " ".join(list(self.names_of(e).values()) + [self.plain(x) for x in
                                                           (self.loc(e, "desc") or []) + (self.loc(e, "sources") or [])]).lower()]
            if not items:
                continue
            tx.insert("end", "▍" + title + "\n", ("shop", "effhead_" + kind))
            for e in items:
                start = tx.index("end-1c")
                tx.mark_set(f"eff_{e['id']}_start", start)
                tx.mark_gravity(f"eff_{e['id']}_start", "left")
                tile = self.tile(e, color=EFFECT_COLORS[kind])
                if tile is not None:
                    at = tx.index("end-1c")
                    tx.image_create("end", image=tile, align="center", padx=2)
                    tx.tag_add("name", at)
                    tx.insert("end", "  ", "name")
                tx.insert("end", self.eff_name(e), "name")
                tx.insert("end", "  " + self.up_sub(e), ("name", "en"))
                label = {"buff": "Buff", "debuff": "Debuff", "dot": "DoT", "other": "Other"}[kind] if self.lang == "en" else title
                tx.insert("end", "   " + label + "\n", ("name", "st_" + kind))
                for line in self.loc(e, "desc") or []:
                    self._insert_line(line, query)
                sources = self.loc(e, "sources") or []
                if sources:
                    tx.insert("end", t("dict_sources") + ": " + " · ".join(sources) + "\n", "src")
                if q:
                    self._mark_hits(start, query)
                shown += 1
        if not shown:
            tx.insert("end", t("dict_empty") + "\n", "empty")
        tx.configure(state="disabled")
        tx.yview_moveto(scroll)

    def _remember_geometry(self, event=None):
        if self.win.state() == "normal":
            self.ov.config["dict_geom"] = self.win.geometry()

    # --- 열기 / 닫기 ------------------------------------------------------
    @property
    def visible(self):
        return self.win.state() == "normal"

    def show(self, activate=True):
        """activate=False면 게임의 키보드 입력을 빼앗지 않도록 원래 창으로 포커스를 돌려준다"""
        prev = None
        if IS_WINDOWS and not activate:
            prev = _user32().GetForegroundWindow()
        self.win.deiconify()
        self.win.lift()
        self.win.update_idletasks()
        round_window_corners(self.win)
        self.ov.ensure_on_screen(self.win)
        force_topmost(self.win)
        if prev:
            self.win.after(80, lambda: _user32().SetForegroundWindow(prev))

    def keep_on_top(self):
        """맨 앞에서 밀려났을 때만 다시 올린다 (이미 맨 앞이면 건드리지 않음)"""
        if self.visible and not is_topmost(self.win):
            force_topmost(self.win)

    def hide(self):
        self._remember_geometry()
        self.win.withdraw()
        self.ov.save_config()

    def toggle(self, activate=True):
        if self.visible:
            self.hide()
        else:
            self.show(activate)


# ---------------------------------------------------------------------------
# 설정 창 (Kuruma Overlay 설정 창과 같은 모양: 어두운 배경, 섹션, 버튼으로 고르기)
# ---------------------------------------------------------------------------
SETTINGS_STRINGS = {
    "ko": {
        "s_title": "설정", "s_lock": "잠그기 (클릭 통과)", "s_lock_note": "잠근 뒤에는 Ctrl+Alt+E로 풀 수 있어요",
        "s_dict_open": "사전 열기", "s_update_check": "최신 버전", "s_on": "켜기", "s_off": "끄기",
        "s_sec_display": "화면", "s_bg": "배경", "s_bg_panel": "패널", "s_bg_clear": "투명",
        "s_alpha": "전체 투명도", "s_theme": "테마", "s_colors": "색 직접 바꾸기", "s_effects": "효과",
        "s_sec_sound": "소리", "s_sound": "어그로 알림음", "s_volume": "크기",
        "s_sec_me": "내 정보", "s_name": "VRChat 이름", "s_name_note": "비워두면 로그에서 자동으로 찾음",
        "s_save": "저장", "s_saved": "저장함", "s_class": "내 직업", "s_auto": "자동",
        "s_sec_dict": "업그레이드 사전", "s_dict_auto": "상점에서 자동으로 열기", "s_dict_close": "스테이지 시작하면 닫기",
        "s_dict_icons": "이미지 표시", "s_dict_icons_note": "처음 한 번 위키에서 받음",
        "s_sec_lang": "언어", "s_sec_help": "문제 해결", "s_launch": "VRChat 시작 옵션", "s_launch_btn": "안내 보기",
        "s_warn": "시작 옵션 경고 표시", "s_fs": "전체화면에서 가려질 때", "s_fs_fix": "고치기", "s_fs_revert": "되돌리기",
        "s_sec_info": "정보", "s_credits": "크레딧 · 보스 타겟 안내", "s_credits_btn": "보기",
        "s_quit": "오버레이 종료", "s_close": "닫기", "s_gear_hint": "⚙ 설정",
    },
    "en": {
        "s_title": "Settings", "s_lock": "Lock (click-through)", "s_lock_note": "Unlock with Ctrl+Alt+E",
        "s_dict_open": "Open dictionary", "s_update_check": "Up to date", "s_on": "On", "s_off": "Off",
        "s_sec_display": "Display", "s_bg": "Background", "s_bg_panel": "Panel", "s_bg_clear": "Clear",
        "s_alpha": "Opacity", "s_theme": "Theme", "s_colors": "Custom colors", "s_effects": "Effects",
        "s_sec_sound": "Sound", "s_sound": "Aggro alert sound", "s_volume": "Volume",
        "s_sec_me": "Me", "s_name": "VRChat name", "s_name_note": "Leave empty to detect from the log",
        "s_save": "Save", "s_saved": "Saved", "s_class": "My class", "s_auto": "Auto",
        "s_sec_dict": "Upgrade dictionary", "s_dict_auto": "Open automatically in shops", "s_dict_close": "Close when a stage starts",
        "s_dict_icons": "Show images", "s_dict_icons_note": "Downloaded once from the wiki",
        "s_sec_lang": "Language", "s_sec_help": "Troubleshooting", "s_launch": "VRChat launch option", "s_launch_btn": "Show help",
        "s_warn": "Launch option warning", "s_fs": "Hidden in fullscreen", "s_fs_fix": "Fix", "s_fs_revert": "Revert",
        "s_sec_info": "About", "s_credits": "Credits · boss target notice", "s_credits_btn": "Show",
        "s_quit": "Quit overlay", "s_close": "Close", "s_gear_hint": "⚙ Settings",
    },
    "ja": {
        "s_title": "設定", "s_lock": "ロック (クリック透過)", "s_lock_note": "ロック後は Ctrl+Alt+E で解除",
        "s_dict_open": "辞書を開く", "s_update_check": "最新版", "s_on": "オン", "s_off": "オフ",
        "s_sec_display": "表示", "s_bg": "背景", "s_bg_panel": "パネル", "s_bg_clear": "透明",
        "s_alpha": "全体の透明度", "s_theme": "テーマ", "s_colors": "色をカスタム", "s_effects": "エフェクト",
        "s_sec_sound": "サウンド", "s_sound": "アグロ通知音", "s_volume": "音量",
        "s_sec_me": "自分", "s_name": "VRChat の表示名", "s_name_note": "空欄ならログから自動で探します",
        "s_save": "保存", "s_saved": "保存しました", "s_class": "自分の職業", "s_auto": "自動",
        "s_sec_dict": "アップグレード辞書", "s_dict_auto": "ショップで自動的に開く", "s_dict_close": "ステージ開始で閉じる",
        "s_dict_icons": "画像を表示", "s_dict_icons_note": "最初に一度だけ Wiki から取得",
        "s_sec_lang": "言語", "s_sec_help": "トラブル対処", "s_launch": "VRChat の起動オプション", "s_launch_btn": "案内を見る",
        "s_warn": "起動オプションの警告", "s_fs": "フルスクリーンで隠れるとき", "s_fs_fix": "直す", "s_fs_revert": "元に戻す",
        "s_sec_info": "情報", "s_credits": "クレジット · ボスターゲットの案内", "s_credits_btn": "見る",
        "s_quit": "オーバーレイを終了", "s_close": "閉じる", "s_gear_hint": "⚙ 設定",
    },
}
for _lang, _d in SETTINGS_STRINGS.items():
    STRINGS[_lang].update(_d)

UI = {   # 설정 창 색 (Kuruma Overlay 설정 창과 같은 계열)
    "bg": "#15171C", "panel": "#1E2128", "panel2": "#262A33", "line": "#2A2E37",
    "text": "#EEF0FA", "muted": "#9AA0B4", "danger": "#FF7A7A",
}


def _dark_titlebar(win):
    """Windows 10/11: 창 제목 표시줄을 어둡게"""
    if not IS_WINDOWS:
        return
    try:
        import ctypes
        win.update_idletasks()
        hwnd = ctypes.windll.user32.GetParent(win.winfo_id())
        val = ctypes.c_int(1)
        for attr in (20, 19):   # DWMWA_USE_IMMERSIVE_DARK_MODE (신/구 버전)
            if ctypes.windll.dwmapi.DwmSetWindowAttribute(hwnd, attr, ctypes.byref(val), ctypes.sizeof(val)) == 0:
                break
    except Exception:
        pass


class Seg(tk.Canvas):
    """버튼 여러 개 중 하나를 고르는 막대 (Kuruma Overlay 설정 창의 seg). multi=True 면 각각 켜고 끄는 칩"""

    def __init__(self, master, options, get, set, font, accent, multi=False, wrap=None):
        super().__init__(master, highlightthickness=0, bd=0, bg=master.cget("bg"), cursor="hand2")
        self.options, self.get, self.set, self.font, self.accent = options, get, set, font, accent
        self.multi, self.wrap = multi, wrap
        self.hover = None
        self.f = tkfont.Font(font=font)
        self.bind("<Button-1>", self._click)
        self.bind("<Motion>", self._motion)
        self.bind("<Leave>", lambda e: self._motion(None))
        self.draw()

    def _layout(self):
        pad, gap, h = 12, 4, self.f.metrics("linespace") + 12
        boxes, x, y, maxw = [], 4, 4, self.wrap or 10 ** 6
        for opt in self.options:
            w = self.f.measure(opt[0]) + pad * 2 + (14 if len(opt) > 2 else 0)
            if x + w > maxw - 4 and x > 4:
                x, y = 4, y + h + gap
            boxes.append((x, y, x + w, y + h))
            x += w + gap
        width = max(b[2] for b in boxes) + 4
        height = max(b[3] for b in boxes) + 4
        return boxes, width, height

    def draw(self):
        self.delete("all")
        boxes, w, h = self._layout()
        self.configure(width=w, height=h)
        self.boxes = boxes
        if not self.multi:
            round_rect(self, 0, 0, w, h, 12, fill=UI["panel"], outline="")
        for i, (opt, (x1, y1, x2, y2)) in enumerate(zip(self.options, boxes)):
            on = self.get(opt[1]) if self.multi else self.get() == opt[1]
            if on:
                fill, fg = self.accent, UI["bg"]
            elif self.hover == i:
                fill, fg = UI["panel2"], UI["text"]
            else:
                fill, fg = (UI["panel"] if self.multi else ""), UI["muted"]
            round_rect(self, x1, y1, x2, y2, 9, fill=fill, outline="" if (on or not self.multi) else UI["line"])
            tx = (x1 + x2) / 2
            if len(opt) > 2:   # 색 점 (테마)
                tx += 7
                cx = x1 + 13
                self.create_oval(cx - 5, (y1 + y2) / 2 - 5, cx + 5, (y1 + y2) / 2 + 5, fill=opt[2], outline=fg if on else "")
            self.create_text(tx, (y1 + y2) / 2, text=opt[0], font=self.font, fill=fg)

    def _hit(self, e):
        if e is None:
            return None
        for i, (x1, y1, x2, y2) in enumerate(self.boxes):
            if x1 <= e.x <= x2 and y1 <= e.y <= y2:
                return i
        return None

    def _motion(self, e):
        i = self._hit(e)
        if i != self.hover:
            self.hover = i
            self.draw()

    def _click(self, e):
        i = self._hit(e)
        if i is None:
            return
        val = self.options[i][1]
        if self.multi:
            self.set(val, not self.get(val))
        else:
            self.set(val)
        self.draw()


class SettingsWindow:
    """⚙ 버튼으로 여는 설정 창. 바꾸면 바로 오버레이에 반영된다"""

    W = 560

    def __init__(self, ov):
        self.ov = ov
        self.win = tk.Toplevel(ov.root)
        self.win.title("Ecliptica Overlay · " + ov.t("s_title"))
        self.win.configure(bg=UI["bg"])
        self.win.attributes("-topmost", True)
        self.win.geometry(f"{self.W}x720")
        self.win.minsize(self.W, 420)
        self.win.protocol("WM_DELETE_WINDOW", self.close)
        self.win.bind("<Escape>", lambda e: self.close())
        _dark_titlebar(self.win)
        self.build()

    # --- 공용 ---------------------------------------------------------------
    @property
    def accent(self):
        P = self.ov.pal
        # 밝은 테마는 강조색이 진해서 어두운 바탕에서도 잘 보이게 corona 를 그대로 씀
        return P["corona"]

    def fonts(self):
        ui = pick_font(self.win, UI_FONTS.get(self.ov.lang, UI_FONTS["en"]) + UI_FONTS["ko"] + UI_FONTS["ja"])
        self.f = (ui, 10)
        self.f_b = (ui, 10, "bold")
        self.f_s = (ui, 9)
        self.f_h = (ui, 12, "bold")
        self.f_t = (ui, 17, "bold")

    def button(self, parent, text, command, primary=False, danger=False):
        bg = self.accent if primary else UI["panel2"]
        fg = UI["bg"] if primary else (UI["danger"] if danger else UI["text"])
        return RoundButton(parent, text, self.f_b, bg=bg, fg=fg, padx=14, pady=7, radius=10, command=command)

    def section(self, title):
        box = tk.Frame(self.body, bg=UI["bg"])
        box.pack(fill="x", padx=24, pady=(18, 0))
        tk.Label(box, text=title, font=self.f_h, bg=UI["bg"], fg=UI["text"], anchor="w").pack(fill="x", pady=(0, 6))
        return box

    def row(self, box, label, note=None):
        r = tk.Frame(box, bg=UI["bg"])
        r.pack(fill="x", pady=5)
        left = tk.Frame(r, bg=UI["bg"])
        left.pack(side="left", anchor="n", pady=(7, 0))   # 오른쪽 버튼 첫 줄 글자와 높이를 맞춤
        tk.Label(left, text=label, font=self.f, bg=UI["bg"], fg=UI["text"], anchor="w").pack(anchor="w")
        if note:
            tk.Label(left, text=note, font=self.f_s, bg=UI["bg"], fg=UI["muted"], anchor="w").pack(anchor="w")
        right = tk.Frame(r, bg=UI["bg"])
        right.pack(side="right")
        return right

    def seg(self, parent, options, get, set, **kw):
        s = Seg(parent, options, get, set, self.f_b, self.accent, **kw)
        s.pack(side="right")
        self.segs.append(s)
        return s

    def onoff(self, parent, var, command):
        def set_(v):
            var.set(v)
            command()
        return self.seg(parent, [(self.ov.t("s_on"), True), (self.ov.t("s_off"), False)], var.get, set_)

    def divider(self):
        tk.Frame(self.body, bg=UI["line"], height=1).pack(fill="x", padx=24, pady=(18, 0))

    # --- 화면 구성 ----------------------------------------------------------
    def build(self):
        ov, t = self.ov, self.ov.t
        for w in self.win.winfo_children():
            w.destroy()
        self.fonts()
        self.segs = []

        # 맨 위: 제목 · 버전 · 업데이트 / 잠금 / 사전
        top = tk.Frame(self.win, bg=UI["bg"])
        top.pack(fill="x", padx=24, pady=(20, 4))
        tk.Label(top, text=t("s_title"), font=self.f_t, bg=UI["bg"], fg=UI["text"]).pack(side="left")
        tk.Label(top, text="v" + APP_VERSION, font=self.f_s, bg=UI["bg"], fg=UI["muted"]).pack(side="left", padx=(10, 0), pady=(6, 0))
        self.update_slot = tk.Frame(top, bg=UI["bg"])
        self.update_slot.pack(side="right")
        self.paint_update()

        acts = tk.Frame(self.win, bg=UI["bg"])
        acts.pack(fill="x", padx=24, pady=(8, 0))
        self.button(acts, t("s_lock"), self.lock).pack(side="left")
        if ov.upgrade_data:
            self.button(acts, t("s_dict_open"), lambda: ov.toggle_dictionary(True)).pack(side="left", padx=(8, 0))
        tk.Label(acts, text=t("s_lock_note"), font=self.f_s, bg=UI["bg"], fg=UI["muted"]).pack(side="left", padx=(12, 0))

        # 아래: 종료 / 닫기 (본문보다 먼저 자리를 잡아야 창이 작아도 보임)
        foot = tk.Frame(self.win, bg=UI["bg"])
        foot.pack(fill="x", side="bottom", padx=24, pady=12)
        tk.Frame(self.win, bg=UI["line"], height=1).pack(fill="x", side="bottom")
        self.button(foot, t("s_close"), self.close, primary=True).pack(side="right")
        self.button(foot, t("s_quit"), ov.quit, danger=True).pack(side="left")

        # 스크롤되는 본문
        wrap = tk.Frame(self.win, bg=UI["bg"])
        wrap.pack(fill="both", expand=True, pady=(12, 0))
        tk.Frame(wrap, bg=UI["line"], height=1).pack(fill="x")
        self.canvas = tk.Canvas(wrap, bg=UI["bg"], highlightthickness=0, bd=0)
        self.canvas.pack(side="left", fill="both", expand=True)
        self.body = tk.Frame(self.canvas, bg=UI["bg"])
        self.body_id = self.canvas.create_window(0, 0, window=self.body, anchor="nw")
        self.body.bind("<Configure>", lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all")))
        self.canvas.bind("<Configure>", lambda e: self.canvas.itemconfigure(self.body_id, width=e.width))
        self.win.bind("<MouseWheel>", self._wheel)
        self.win.bind("<Button-4>", lambda e: self.canvas.yview_scroll(-3, "units"))
        self.win.bind("<Button-5>", lambda e: self.canvas.yview_scroll(3, "units"))

        wide = self.W - 48 - 150   # 칩이 줄바꿈될 폭

        # 화면
        box = self.section(t("s_sec_display"))
        self.seg(self.row(box, t("s_bg")), [(t("s_bg_panel"), False), (t("s_bg_clear"), True)],
                 ov.var_transparent.get, lambda v: (ov.var_transparent.set(v), ov.on_bg_toggle()))
        self.seg(self.row(box, t("s_alpha")), [(f"{int(a * 100)}%", a) for a in (0.6, 0.75, 0.9, 1.0)],
                 lambda: round(float(ov.root.attributes("-alpha")), 2), ov.set_alpha)
        r = self.row(box, t("s_theme"))
        themes = [(t("theme_" + k).split(" (")[0].split("（")[0], k, THEMES[k]["corona"]) for k in THEME_ORDER]
        self.seg(r, themes, lambda: ov.theme, self.set_theme, multi=False, wrap=wide)
        r = self.row(box, "")
        self.button(r, t("s_colors"), ov.open_color_dialog).pack(side="right")
        fx = [(t("fx_" + k), k) for k in ("glow", "gradient", "anim", "pulse")]
        self.seg(self.row(box, t("s_effects")), fx, lambda k: ov.fx_vars[k].get(),
                 lambda k, v: (ov.fx_vars[k].set(v), ov.on_fx_toggle()), multi=True, wrap=wide)

        # 소리
        self.divider()
        box = self.section(t("s_sec_sound"))
        self.onoff(self.row(box, t("s_sound")), ov.var_sound, ov.save_config)
        self.seg(self.row(box, t("s_volume")), [(f"{v}%", v) for v in SOUND_LEVELS],
                 ov.var_volume.get, lambda v: (ov.var_volume.set(v), ov.set_volume(v)))

        # 내 정보
        self.divider()
        box = self.section(t("s_sec_me"))
        r = self.row(box, t("s_name"), t("s_name_note"))
        self.name_msg = tk.Label(r, text="", font=self.f_s, bg=UI["bg"], fg=UI["muted"])
        self.button(r, t("s_save"), self.save_name, primary=True).pack(side="right")
        self.name_var = tk.StringVar(value=ov.config.get("name", ov.state.local_name) or "")
        entry = tk.Entry(r, textvariable=self.name_var, font=self.f, width=18, bg=UI["panel"], fg=UI["text"],
                         insertbackground=UI["text"], relief="flat", highlightthickness=1,
                         highlightbackground=UI["line"], highlightcolor=self.accent)
        entry.pack(side="right", padx=(0, 8), ipady=6)
        entry.bind("<Return>", lambda e: self.save_name())
        self.name_msg.pack(side="right", padx=(0, 8))
        classes = (ov.upgrade_data or {}).get("classes") or []
        if classes:
            opts = [(t("s_auto"), None)] + [(c["name"] if ov.lang == "ko" else c["en"], c["id"]) for c in classes]
            self.seg(self.row(box, t("s_class")), opts, lambda: ov.my_class_pin, ov.set_my_class_pin, wrap=wide)

        # 업그레이드 사전
        if ov.upgrade_data:
            self.divider()
            box = self.section(t("s_sec_dict"))
            self.onoff(self.row(box, t("s_dict_auto")), ov.var_dict_auto, ov.save_config)
            self.onoff(self.row(box, t("s_dict_close")), ov.var_dict_close, ov.save_config)
            if HAS_PIL:
                self.onoff(self.row(box, t("s_dict_icons"), t("s_dict_icons_note")), ov.var_dict_icons, ov.on_dict_icons_toggle)

        # 언어
        self.divider()
        box = self.section(t("s_sec_lang") + " · Language · 言語")
        self.seg(self.row(box, ""), [(n, c) for c, n in LANG_NAMES], lambda: ov.lang, self.set_lang)

        # 문제 해결
        self.divider()
        box = self.section(t("s_sec_help"))
        self.button(self.row(box, t("s_launch")), t("s_launch_btn"), ov.show_launch_help).pack(side="right")
        self.onoff(self.row(box, t("s_warn")), ov.var_warn_debug, ov.on_warn_toggle)
        if IS_WINDOWS:
            r = self.row(box, t("s_fs"))
            if ov.config.get("fs_backup"):
                self.button(r, t("s_fs_revert"), lambda: ov.request_fullscreen_change("revert")).pack(side="right", padx=(8, 0))
            self.button(r, t("s_fs_fix"), lambda: ov.request_fullscreen_change("fix")).pack(side="right")

        # 정보
        self.divider()
        box = self.section(t("s_sec_info"))
        self.button(self.row(box, t("s_credits")), t("s_credits_btn"), lambda: ov.show_credits(self.win)).pack(side="right")
        tk.Label(box, text=t("notice"), font=self.f_s, bg=UI["bg"], fg=UI["muted"], anchor="w").pack(fill="x", pady=(6, 20))


    def _wheel(self, e):
        self.canvas.yview_scroll(int(-e.delta / 120) * 3, "units")

    def paint_update(self):
        if not self.win.winfo_exists():
            return
        for w in self.update_slot.winfo_children():
            w.destroy()
        ov, t = self.ov, self.ov.t
        info = getattr(ov, "update_info", None)
        if info and getattr(ov, "update_busy", False):
            tk.Label(self.update_slot, text=t("update_busy"), font=self.f_b, bg=UI["bg"], fg=UI["muted"]).pack()
        elif info:
            self.button(self.update_slot, t("menu_update", v=info.get("version", "?")), ov.do_update, primary=True).pack()
        else:
            tk.Label(self.update_slot, text=t("s_update_check"), font=self.f_s, bg=UI["bg"], fg=UI["muted"]).pack(pady=(6, 0))

    # --- 동작 ---------------------------------------------------------------
    def set_theme(self, key):
        self.ov.set_theme(key)
        self.refresh()

    def set_lang(self, code):
        self.ov.set_lang(code)
        self.win.title("Ecliptica Overlay · " + self.ov.t("s_title"))
        y = self.canvas.yview()[0]
        self.build()
        self.win.after(10, lambda: self.canvas.yview_moveto(y))

    def refresh(self):
        """테마가 바뀌면 강조색을 다시 칠함 (스크롤 위치 유지)"""
        y = self.canvas.yview()[0]
        self.build()
        self.win.after(10, lambda: self.canvas.yview_moveto(y))

    def save_name(self):
        name = self.name_var.get().strip()
        with self.ov.state.lock:
            self.ov.state.manual_name = name
        self.ov.config["name"] = name
        self.ov.save_config()
        self.name_msg.configure(text=self.ov.t("s_saved"))
        self.win.after(1500, lambda: self.name_msg.winfo_exists() and self.name_msg.configure(text=""))

    def lock(self):
        self.close()
        if not self.ov.locked:
            self.ov.toggle_lock()

    def lift(self):
        self.win.deiconify()
        self.win.lift()
        self.win.focus_force()

    def close(self):
        self.win.destroy()


class Overlay:
    W = 300

    def __init__(self, state, watcher, config):
        self.state = state
        self.watcher = watcher
        self.config = config
        self.locked = False
        self.events = queue.Queue()
        self.flash_left = 0
        self.height = 240
        self.lang = config.get("lang") or detect_lang()
        self.hotkey_ok = False                        # 단축키가 등록돼야만 잠글 수 있다
        self.pending_autolock = bool(config.get("locked"))
        self.last_frame = None
        self.saw_exclusive = False                     # 이번 실행 중 독점 전체화면을 감지했는지
        self.fs_pending = config.get("fs_pending")     # "fix" / "revert": VRChat 종료 후 적용 대기
        self.next_fs_check = 0.0
        self.theme = config.get("theme", "eclipse") if config.get("theme") in THEMES else "eclipse"
        self.custom_colors = {k: dict(v) for k, v in (config.get("colors") or {}).items()}
        self.fx = dict(FX_DEFAULTS, **(config.get("fx") or {}))
        self.anim_dps = 0.0
        self.anim_avg = 0.0
        self.color_dialog = None
        self.pal = self.compute_palette()
        self.upgrade_data = load_upgrade_data()
        self.boss_by_log, self.map_by_log, self.boss_icons = {}, {}, {}
        self.rune_by_id = {r["id"]: r for r in (self.upgrade_data or {}).get("runes", [])}
        self.curse_by_id = {c["id"]: c for c in (self.upgrade_data or {}).get("curses", [])}
        self.runes_equipped = [r for r in config.get("runes", []) if r in self.rune_by_id][:4]
        self.curse_stacks = {k: int(v) for k, v in (config.get("curses") or {}).items() if k in self.curse_by_id and int(v) > 0}
        self.seen_run_end = 0
        self.boss_by_wiki = {}
        self.learned_bosses = dict(config.get("learned_bosses") or {})   # 자동 인식으로 알아낸 내부 이름 -> 위키 이름
        for b in (self.upgrade_data or {}).get("bosses", []):
            for name in b.get("log", []):
                self.boss_by_log[name.lower()] = b
            self.boss_by_wiki[boss_key(b["name"])] = b
        for mp in (self.upgrade_data or {}).get("maps", []):
            for name in mp.get("log", []):
                self.map_by_log[name.lower()] = mp
        self.dictionary = None
        self.icons = IconStore()
        self.detected_class = None                         # 로그에서 마지막으로 읽은 직업
        self.my_class_pin = config.get("my_class_pin")     # 직접 고정한 직업 (없으면 자동)
        self.my_class_last = config.get("my_class_last")   # 자동: 로그와 직업 탭 중 더 최근 것
        self.seen_shop_seq = 0
        self.seen_stage_seq = 0

        self.root = tk.Tk()
        self.root.title("Ecliptica Overlay")
        self.root.overrideredirect(True)
        self.root.attributes("-topmost", True)
        self.root.attributes("-alpha", config.get("alpha", 1.0))
        self.root.geometry(f"+{config.get('x', 40)}+{config.get('y', 40)}")
        self.root.after(500, self.ensure_on_screen)
        self.root.after(1500, self.show_first_notice)
        self.root.after(2500, self.fetch_icons)          # 보스 아이콘도 쓰도록 켜질 때 받아 둔다

        self.canvas = tk.Canvas(self.root, width=self.W, height=self.height,
                                highlightthickness=0, bd=0, bg=KEY_COLOR)
        self.canvas.pack()

        self.var_transparent = tk.BooleanVar(value=config.get("transparent", False))
        self.var_sound = tk.BooleanVar(value=config.get("sound", True))
        vol = config.get("sound_volume", 50)
        self.var_volume = tk.IntVar(value=vol if vol in SOUND_LEVELS else 50)
        prepare_sounds(self.var_volume.get())
        self.var_lang = tk.StringVar(value=self.lang)
        self.var_warn_debug = tk.BooleanVar(value=config.get("warn_debug", False))
        self.var_theme = tk.StringVar(value=self.theme)
        self.var_dict_auto = tk.BooleanVar(value=config.get("dict_auto", True))
        self.var_dict_close = tk.BooleanVar(value=config.get("dict_close", True))
        self.var_dict_icons = tk.BooleanVar(value=config.get("dict_icons", True))
        self.fx_vars = {k: tk.BooleanVar(value=v) for k, v in self.fx.items()}
        self.apply_background()
        self.load_fonts()
        self.update_info = None
        self.update_busy = False
        self.update_result = None      # 백그라운드 스레드 → tick 에서 처리
        self.update_menu_shown = False
        self.settings_win = None
        self.hover = False             # 마우스가 오버레이 위에 있으면 ⚙ 버튼 표시
        self.gear_box = None
        self._gear_click = False
        self.build_menu()
        threading.Thread(target=self._check_update_bg, daemon=True).start()

        c = self.canvas
        c.bind("<ButtonPress-1>", self._drag_start)
        c.bind("<B1-Motion>", self._drag_move)
        c.bind("<ButtonRelease-1>", lambda e: self.save_config())
        c.bind("<Button-3>", self._popup)
        c.bind("<Button-2>", self._popup)  # macOS
        c.bind("<Enter>", lambda e: self._set_hover(True))
        c.bind("<Leave>", lambda e: self._set_hover(False))
        start_hotkey_listener(self.events)
        self.root.after(100, self.tick)

    def t(self, key, **kw):
        return tr(self.lang, key, **kw)

    # --- 설정 반영 --------------------------------------------------------
    @property
    def transparent(self):
        return self.var_transparent.get()

    def apply_background(self):
        if self.transparent:
            self.root.configure(bg=KEY_COLOR)
            self.canvas.configure(bg=KEY_COLOR)
            try:
                self.root.attributes("-transparentcolor", KEY_COLOR)
            except tk.TclError:
                pass  # Windows 외 환경에서는 지원 안 됨 (검은 배경으로 표시)
        else:
            # 패널 모드도 바깥은 투명하게 뚫어서, 둥근 패널 모서리가 그대로 보이게 한다
            self.root.configure(bg=KEY_COLOR)
            self.canvas.configure(bg=KEY_COLOR)
            try:
                self.root.attributes("-transparentcolor", KEY_COLOR)
            except tk.TclError:
                self.root.configure(bg=self.pal["night"])
                self.canvas.configure(bg=self.pal["night"])

    def load_fonts(self):
        num = pick_font(self.root, ["Bahnschrift", "Segoe UI", "Helvetica"])
        ui = pick_font(self.root, UI_FONTS.get(self.lang, UI_FONTS["en"]) + UI_FONTS["ko"] + UI_FONTS["ja"])
        self.f_big = (num, 34, "bold")
        self.f_mid = (num, 15, "bold")
        self.f_num = (num, 11, "bold")
        self.f_ui = (ui, 9)
        self.f_cap = (ui, 10, "bold")   # 투명 모드용 설명 글자
        self.f_ui_b = (ui, 10, "bold")
        self.f_target = (ui, 13, "bold")

    def build_menu(self):
        m = tk.Menu(self.root, tearoff=0)
        info = getattr(self, "update_info", None)
        if info:
            if getattr(self, "update_busy", False):
                m.add_command(label=self.t("update_busy"), state="disabled")
            else:
                m.add_command(label=self.t("menu_update", v=info.get("version", "?")), command=self.do_update)
            m.add_separator()
        m.add_command(label=self.t("menu_lock"), command=self.toggle_lock)
        m.add_checkbutton(label=self.t("menu_bg"), variable=self.var_transparent, command=self.on_bg_toggle)
        m.add_checkbutton(label=self.t("menu_sound"), variable=self.var_sound, command=self.save_config)
        vol_menu = tk.Menu(m, tearoff=0)
        for v in SOUND_LEVELS:
            vol_menu.add_radiobutton(label=f"{v}%", value=v, variable=self.var_volume,
                                     command=lambda v=v: self.set_volume(v))
        m.add_cascade(label=self.t("menu_volume"), menu=vol_menu)
        theme_menu = tk.Menu(m, tearoff=0)
        for key in THEME_ORDER:
            theme_menu.add_radiobutton(label=self.t("theme_" + key), value=key, variable=self.var_theme,
                                       command=lambda k=key: self.set_theme(k))
        theme_menu.add_separator()
        theme_menu.add_command(label=self.t("menu_colors"), command=self.open_color_dialog)
        m.add_cascade(label=self.t("menu_theme"), menu=theme_menu)
        fx_menu = tk.Menu(m, tearoff=0)
        for key in ("glow", "gradient", "anim", "pulse"):
            fx_menu.add_checkbutton(label=self.t("fx_" + key), variable=self.fx_vars[key],
                                    command=self.on_fx_toggle)
        m.add_cascade(label=self.t("menu_effects"), menu=fx_menu)
        alpha_menu = tk.Menu(m, tearoff=0)
        for a in (0.6, 0.75, 0.9, 1.0):
            alpha_menu.add_command(label=f"{int(a * 100)}%", command=lambda a=a: self.set_alpha(a))
        m.add_cascade(label=self.t("menu_alpha"), menu=alpha_menu)
        lang_menu = tk.Menu(m, tearoff=0)
        for code, name in LANG_NAMES:
            lang_menu.add_radiobutton(label=name, value=code, variable=self.var_lang,
                                      command=lambda c=code: self.set_lang(c))
        m.add_cascade(label="Language / 언어 / 言語", menu=lang_menu)
        m.add_command(label=self.t("menu_name"), command=self.ask_name)
        m.add_command(label=self.t("menu_launch_help"), command=self.show_launch_help)
        m.add_checkbutton(label=self.t("menu_warn_debug"), variable=self.var_warn_debug,
                          command=self.on_warn_toggle)
        if self.upgrade_data:
            m.add_separator()
            m.add_command(label=self.t("menu_dict"), command=lambda: self.toggle_dictionary(True))
            if self.upgrade_data.get("classes"):
                cm = tk.Menu(m, tearoff=0)
                self.var_my_pin = tk.StringVar(value=self.my_class_pin or "")
                cm.add_radiobutton(label=self.t("my_class_auto"), value="", variable=self.var_my_pin,
                                   command=lambda: self.set_my_class_pin(None))
                cm.add_separator()
                for c in self.upgrade_data["classes"]:
                    label = c["name"] if self.lang == "ko" else c["en"]
                    if c["id"] == self.my_class() and not self.my_class_pin:
                        label += "  ★"
                    cm.add_radiobutton(label=label, value=c["id"], variable=self.var_my_pin,
                                       command=lambda k=c["id"]: self.set_my_class_pin(k))
                m.add_cascade(label=self.t("menu_my_class"), menu=cm)
            m.add_checkbutton(label=self.t("menu_dict_auto"), variable=self.var_dict_auto, command=self.save_config)
            m.add_checkbutton(label=self.t("menu_dict_close"), variable=self.var_dict_close, command=self.save_config)
            if HAS_PIL:
                m.add_checkbutton(label=self.t("menu_dict_icons"), variable=self.var_dict_icons,
                                  command=self.on_dict_icons_toggle)
        if IS_WINDOWS:
            m.add_separator()
            m.add_command(label=self.t("menu_fs_fix"), command=lambda: self.request_fullscreen_change("fix"))
            if self.config.get("fs_backup"):
                m.add_command(label=self.t("menu_fs_revert"),
                              command=lambda: self.request_fullscreen_change("revert"))
        m.add_separator()
        m.add_command(label=self.t("menu_credits"), command=self.show_credits)
        m.add_command(label=self.t("notice"), state="disabled")
        m.add_command(label="v" + APP_VERSION, state="disabled")
        m.add_command(label=self.t("menu_quit"), command=self.quit)
        self.menu = m

    def on_bg_toggle(self):
        self.last_frame = None
        self.apply_background()
        self.save_config()

    def set_lang(self, code):
        self.lang = code
        self.var_lang.set(code)
        self.load_fonts()
        self.build_menu()
        if self.dictionary is not None and self.dictionary.win.winfo_exists():
            self.dictionary.build()
        self.save_config()

    # --- 보스 / 맵 이름 (위키 기준) -------------------------------------------
    def boss_info(self, internal, sources=()):
        """로그의 내부 이름(JimBringerPhase2 등) -> (보여줄 이름, 위키 보스 정보)
        1) 알려진 내부 이름  2) 위키 이름과 같은 이름  3) 보스전 중 피해 출처에 찍힌 이름 순으로 찾는다"""
        if not internal:
            return "", None
        m = re.match(r"(.+?)Phase(\d+)$", internal)
        base, phase = (m.group(1), m.group(2)) if m else (internal, None)
        b = self.boss_by_log.get(base.lower()) or self.boss_by_wiki.get(boss_key(base))
        if b is None and base.lower() in self.learned_bosses:
            b = self.boss_by_wiki.get(boss_key(self.learned_bosses[base.lower()]))
        if b is None:
            for src in sources:
                b = self.boss_by_wiki.get(boss_key(src))
                if b:
                    # 한 번 알아낸 보스는 기억해 두고, 다음부터는 1페이즈 시작부터 바로 보여준다
                    self.learned_bosses[base.lower()] = b["name"]
                    self.save_config()
                    break
        name = b["name"] if b else internal
        if phase:
            name += " " + self.t("boss_phase", n=phase)
        return name, b

    def boss_icon(self, b, size=30):
        if not b or not HAS_PIL or not b.get("icon_id") or not self.icons.has(b["icon_id"]):
            return None
        key = (b["icon_id"], size)
        if key not in self.boss_icons:
            try:
                im = PILImage.open(self.icons.path(b["icon_id"])).convert("RGBA")
                im.thumbnail((size, size), PILImage.LANCZOS)
                self.boss_icons[key] = PILImageTk.PhotoImage(im, master=self.root)
            except Exception:
                log_error("boss icon")
                return None
        return self.boss_icons[key]

    def fit(self, text, font, max_w):
        """글자가 max_w 픽셀보다 길면 끝을 … 으로 줄인다"""
        if not hasattr(self, "_fonts"):
            self._fonts = {}
        key = str(font)
        if key not in self._fonts:
            self._fonts[key] = tkfont.Font(root=self.root, font=font)
        f = self._fonts[key]
        if f.measure(text) <= max_w:
            return text
        while text and f.measure(text + "…") > max_w:
            text = text[:-1]
        return text.rstrip() + "…"

    def measure(self, text, font):
        self.fit("", font, 1)
        return self._fonts[str(font)].measure(text)

    def entry_name(self, e):
        """룬·저주 등 데이터 항목의 언어별 이름"""
        if self.lang == "ko":
            return e.get("ko") or e.get("id")
        return ((e.get("i18n") or {}).get(self.lang, {}).get("name")) or e.get("ko") or e.get("id")

    def map_name(self, s):
        mp = self.map_by_log.get((s.get("stage_raw") or "").lower())
        return mp["name"] if mp else s.get("stage_name", "")

    def show_credits(self, parent=None):
        from tkinter import messagebox
        messagebox.showinfo("Ecliptica Overlay",
                            self.t("credits_text") + "\n\n" + "─" * 20 + "\n\n" + self.t("target_notice"),
                            parent=parent or self.root)

    def show_first_notice(self):
        """처음 실행할 때 한 번만 보스 타겟 안내를 보여준다"""
        if self.config.get("target_notice_ack"):
            return
        from tkinter import messagebox
        messagebox.showinfo("Ecliptica Overlay", self.t("target_notice"), parent=self.root)
        self.config["target_notice_ack"] = True
        self.save_config()

    def set_volume(self, v):
        self.var_volume.set(v)
        self.save_config()
        play_sound("aggro_me", v)      # 고른 크기로 미리 들려준다
        prepare_sounds(v)

    def set_alpha(self, a):
        self.root.attributes("-alpha", a)
        self.config["alpha"] = a
        self.save_config()

    # --- 이동 / 메뉴 ------------------------------------------------------
    def _drag_start(self, e):
        self._dx = e.x_root - self.root.winfo_x()
        self._dy = e.y_root - self.root.winfo_y()
        g = self.gear_box
        self._gear_click = bool(g and g[0] <= e.x <= g[2] and g[1] <= e.y <= g[3])
        if self._gear_click:
            self.open_settings()

    def _drag_move(self, e):
        if not self.locked and not self._gear_click:
            self.root.geometry(f"+{e.x_root - self._dx}+{e.y_root - self._dy}")

    def _set_hover(self, on):
        if on != self.hover:
            self.hover = on
            self.last_frame = None   # 다음 갱신 때 ⚙ 버튼을 그리거나 지움

    def _popup(self, e):
        """우클릭도 설정 창을 연다 (예전 우클릭 메뉴 대신)"""
        self.open_settings()

    def open_settings(self):
        if self.settings_win is not None and self.settings_win.win.winfo_exists():
            self.settings_win.lift()
            return
        self.settings_win = SettingsWindow(self)

    def settings_refresh_update(self):
        sw = self.settings_win
        if sw is not None and sw.win.winfo_exists():
            sw.paint_update()

    def ensure_on_screen(self, win=None, force=False):
        """창이 어느 모니터에도 충분히 걸쳐 있지 않으면 주 모니터 왼쪽 위로 옮긴다"""
        win = win or self.root
        try:
            win.update_idletasks()
            x, y, w = win.winfo_x(), win.winfo_y(), win.winfo_width()
            b = screen_bounds()
            if b is None:
                sx, sy, sw, sh = 0, 0, win.winfo_screenwidth(), win.winfo_screenheight()
            else:
                sx, sy, sw, sh = b
            visible = (x + w - 40 > sx and x + 40 < sx + sw and y + 20 > sy and y + 20 < sy + sh)
            if force or not visible:
                win.geometry("+40+40")
                win.update_idletasks()      # 옮긴 위치가 반영된 뒤에 저장한다
                if win is self.root:
                    self.save_config()
        except tk.TclError:
            pass

    def handle_command(self):
        """다시 실행한 exe가 남긴 명령을 처리한다"""
        try:
            with open(COMMAND_PATH, "r", encoding="utf-8") as f:
                cmd = f.read().strip()
            os.remove(COMMAND_PATH)
        except OSError:
            return
        if cmd == "quit":
            self.quit()
        elif cmd == "show":
            if self.locked:
                self.locked = False
                set_click_through(self.root, False)
            self.root.deiconify()
            self.ensure_on_screen()
            force_topmost(self.root)
            self.flash_left = 6          # 어디 있는지 알 수 있게 한 번 반짝
            self.last_frame = None
            if self.dictionary is not None and self.dictionary.win.winfo_exists() and self.dictionary.visible:
                self.ensure_on_screen(self.dictionary.win)
            self.save_config()

    def ensure_topmost(self):
        """최상단 속성이 사라졌을 때만 다시 건다.
        이미 최상단인데 또 올리면 우클릭 메뉴, 안내창, 색상 설정 창 위로 오버레이가 올라와 가려 버린다."""
        if getattr(self, "menu_open", False):
            return
        if is_topmost(self.root):
            return
        force_topmost(self.root)

    def toggle_lock(self):
        if not self.locked and not self.hotkey_ok:
            # 잠그면 클릭이 통과되어 단축키 말고는 풀 방법이 없다. 단축키가 없으면 잠그지 않는다.
            from tkinter import messagebox
            messagebox.showwarning("Ecliptica Overlay", self.t("hotkey_busy"), parent=self.root)
            return
        self.locked = not self.locked
        set_click_through(self.root, self.locked)
        self.save_config()

    # --- VRChat 전체화면 대응 ---------------------------------------------
    def _info(self, key):
        from tkinter import messagebox
        messagebox.showinfo("Ecliptica Overlay", self.t(key), parent=self.root)

    def request_fullscreen_change(self, action, ask=True):
        from tkinter import messagebox
        if action == "fix":
            values = read_fullscreen_values()
            if not values:
                self._info("fs_not_found")
                return
            if all(v == FS_BORDERLESS for _, v in values) and self.fs_pending != "revert":
                self._info("fs_already")
                return
            if ask and not messagebox.askyesno("Ecliptica Overlay", self.t("fs_confirm"), parent=self.root):
                return
        if vrchat_window():
            self.fs_pending = action           # VRChat이 꺼지면 적용
            self.save_config()
            self._info("fs_wait")
            return
        self.apply_fullscreen_change(action)

    def apply_fullscreen_change(self, action):
        try:
            if action == "fix":
                values = read_fullscreen_values()
                if not values:
                    self._info("fs_not_found")
                    return
                if not self.config.get("fs_backup"):
                    self.config["fs_backup"] = dict(values)   # 원래 값 보관 (되돌리기용)
                write_fullscreen_values({name: FS_BORDERLESS for name, _ in values})
                done = "fs_done"
            else:
                backup = self.config.get("fs_backup") or {}
                if backup:
                    write_fullscreen_values(backup)
                self.config.pop("fs_backup", None)
                done = "fs_reverted"
        except Exception:
            log_error("fullscreen setting")
            self._info("fs_failed")
            return
        finally:
            self.fs_pending = None
            self.save_config()
            self.build_menu()
        self._info(done)

    def check_fullscreen(self):
        """2초마다: 최상단 유지, 독점 전체화면 감지, 대기 중인 설정 변경 적용"""
        self.ensure_topmost()   # 다른 창에 밀려났을 때만 다시 위로
        if (self.dictionary is not None and self.dictionary.win.winfo_exists()
                and not getattr(self, "menu_open", False)):
            self.dictionary.keep_on_top()
        if not IS_WINDOWS:
            return
        if self.fs_pending and not vrchat_window():
            self.apply_fullscreen_change(self.fs_pending)
            return
        if vrchat_in_exclusive_fullscreen():
            self.saw_exclusive = True
            return
        # 전체화면 게임 위에 대화상자를 띄우면 게임이 최소화되므로,
        # 사용자가 VRChat 밖으로 나왔을 때 한 번만 묻는다.
        if (self.saw_exclusive and not self.config.get("fs_prompted") and not self.fs_pending
                and _user32().GetForegroundWindow() != vrchat_window()):
            from tkinter import messagebox
            self.config["fs_prompted"] = True
            self.save_config()
            values = read_fullscreen_values()
            if values and messagebox.askyesno("Ecliptica Overlay", self.t("fs_detected"), parent=self.root):
                self.request_fullscreen_change("fix", ask=False)

    # --- 테마 / 색상 / 효과 ------------------------------------------------
    def compute_palette(self):
        pal = dict(THEMES[self.theme])
        if self.theme == "rainbow":
            h = time.time() * 0.07
            pal["corona"] = hsv_hex(h, 0.62, 1.0)
            pal["corona2"] = hsv_hex(h + 0.33, 0.68, 1.0)
            pal["blood2"] = hsv_hex(h + 0.5, 0.75, 1.0)
            pal["rim"] = mix(pal["night"], pal["corona"], 0.45)
        pal.update(self.custom_colors.get(self.theme, {}))
        return {k: safe_color(v) for k, v in pal.items()}

    def settings_changed(self):
        self.pal = self.compute_palette()
        self.last_frame = None
        if not self.transparent:
            self.apply_background()
        self.save_config()

    def set_theme(self, key):
        self.theme = key
        self.var_theme.set(key)
        self.settings_changed()
        if self.color_dialog is not None:
            self.color_dialog.refresh()
        if self.dictionary is not None and self.dictionary.win.winfo_exists():
            self.dictionary.build()

    def on_fx_toggle(self):
        self.fx = {k: v.get() for k, v in self.fx_vars.items()}
        self.settings_changed()

    def set_custom_color(self, key, value):
        self.custom_colors.setdefault(self.theme, {})[key] = value
        self.settings_changed()

    def reset_custom_colors(self):
        self.custom_colors.pop(self.theme, None)
        self.settings_changed()

    # --- 내 직업 ------------------------------------------------------------
    def my_class(self):
        return self.my_class_pin or self.my_class_last

    def _my_class_updated(self):
        self.save_config()
        self.build_menu()
        if self.dictionary is not None and self.dictionary.win.winfo_exists():
            self.dictionary.my_class_changed()

    def on_class_viewed(self, cid):
        if not self.my_class_pin and cid and cid != self.my_class_last:
            self.my_class_last = cid
            self._my_class_updated()

    def on_class_logged(self, cid):
        if cid and cid != self.my_class_last:
            self.my_class_last = cid
            if not self.my_class_pin:
                self._my_class_updated()
            else:
                self.save_config()

    def set_my_class_pin(self, cid):
        self.my_class_pin = cid or None
        if cid:
            self.my_class_last = cid
        elif self.detected_class:
            self.my_class_last = self.detected_class   # 고정 해제: 로그에서 읽은 직업으로 돌아간다
        self._my_class_updated()

    def get_dictionary(self):
        if not self.upgrade_data:
            return None
        if self.dictionary is None or not self.dictionary.win.winfo_exists():
            self.dictionary = UpgradeDictionary(self, self.upgrade_data)
            self.fetch_icons()        # 처음 열 때 없는 아이콘만 받는다 (이미 받았으면 통신 없음)
        return self.dictionary

    def fetch_icons(self):
        if self.upgrade_data and self.var_dict_icons.get():
            self.icons.download_missing(self.upgrade_data["upgrades"] + self.upgrade_data.get("effects", [])
                                        + self.upgrade_data.get("bosses", []) + self.upgrade_data.get("runes", [])
                                        + self.upgrade_data.get("curses", [])[:1])

    def on_dict_icons_toggle(self):
        self.save_config()
        self.fetch_icons()

    def toggle_dictionary(self, activate=True):
        d = self.get_dictionary()
        if d:
            d.toggle(activate)

    def open_color_dialog(self):
        if self.color_dialog is not None and self.color_dialog.win.winfo_exists():
            self.color_dialog.win.lift()
            return
        self.color_dialog = ColorDialog(self)

    def show_launch_help(self):
        from tkinter import messagebox
        state_key = {True: "launch_on", False: "launch_off"}.get(self.watcher.debug_logging, "launch_unknown")
        try:
            self.root.clipboard_clear()
            self.root.clipboard_append(UDON_DEBUG_FLAG)
        except tk.TclError:
            pass
        messagebox.showinfo("Ecliptica Overlay", self.t("launch_help", state=self.t(state_key)), parent=self.root)

    def on_warn_toggle(self):
        self.last_frame = None
        self.save_config()

    def ask_name(self):
        name = simpledialog.askstring(self.t("name_title"), self.t("name_prompt"),
                                      initialvalue=self.config.get("name", self.state.local_name),
                                      parent=self.root)
        if name is None:
            return
        with self.state.lock:
            self.state.manual_name = name.strip()
        self.config["name"] = name.strip()
        self.save_config()

    def save_config(self):
        self.config.update({
            "x": self.root.winfo_x(), "y": self.root.winfo_y(),
            "sound": self.var_sound.get(), "sound_volume": self.var_volume.get(), "locked": self.locked,
            "transparent": self.transparent, "lang": self.lang,
            "fs_pending": self.fs_pending,
            "warn_debug": self.var_warn_debug.get(),
            "theme": self.theme, "colors": self.custom_colors, "fx": self.fx,
            "dict_auto": self.var_dict_auto.get(), "dict_close": self.var_dict_close.get(),
            "dict_icons": self.var_dict_icons.get(),
            "my_class_pin": self.my_class_pin, "my_class_last": self.my_class_last,
            "runes": self.runes_equipped, "curses": self.curse_stacks,
            "learned_bosses": self.learned_bosses,
        })
        try:
            with open(CONFIG_PATH, "w", encoding="utf-8") as f:
                json.dump(self.config, f, ensure_ascii=False, indent=2)
        except OSError:
            pass

    def quit(self):
        self.save_config()
        self.root.destroy()

    # --- 업데이트 ---------------------------------------------------------
    def _check_update_bg(self):
        time.sleep(3)
        try:
            self.update_info = check_update()
        except Exception:
            self.update_info = None   # 오프라인 등은 조용히 넘어감

    def do_update(self):
        info = self.update_info
        if not info or self.update_busy:
            return
        if info.get("full"):
            import webbrowser
            from tkinter import messagebox
            messagebox.showinfo("Ecliptica Overlay", self.t("update_full"), parent=self.root)
            webbrowser.open(DOWNLOAD_PAGE)
            return
        self.update_busy = True
        self.build_menu()
        self.settings_refresh_update()

        def work():
            try:
                apply_update(info)
                self.update_result = ("ok", None)
            except Exception as e:
                log_error("update")
                self.update_result = ("fail", str(e))
        threading.Thread(target=work, daemon=True).start()

    def _poll_update(self):
        if self.update_info and not self.update_menu_shown:
            self.update_menu_shown = True
            self.build_menu()
            self.settings_refresh_update()
        if self.update_result is None:
            return
        status, err = self.update_result
        self.update_result = None
        self.update_busy = False
        if status == "ok":
            self.save_config()
            restart_after_update()
            self.root.destroy()
            return
        self.build_menu()
        self.settings_refresh_update()
        import webbrowser
        from tkinter import messagebox
        messagebox.showerror("Ecliptica Overlay", self.t("update_failed", err=err), parent=self.root)
        webbrowser.open(DOWNLOAD_PAGE)

    # --- 갱신 -------------------------------------------------------------
    def tick(self):
        delay = 200
        try:
            delay = 100 if self._tick() else 200   # 움직이는 효과가 있을 때만 자주 갱신
        except Exception:
            log_error("ui")
        finally:
            self.root.after(delay, self.tick)   # 한 번 오류가 나도 화면 갱신은 계속

    def _tick(self):
        self._poll_update()
        if os.path.exists(COMMAND_PATH):
            self.handle_command()
        if time.time() >= self.next_fs_check:     # 2초마다
            self.next_fs_check = time.time() + 2
            try:
                self.check_fullscreen()
            except Exception:
                log_error("fullscreen check")
        while not self.events.empty():
            ev = self.events.get()
            if ev == "toggle_lock":
                self.toggle_lock()
            elif ev == "toggle_dict":
                self.toggle_dictionary(activate=False)   # 게임 중 단축키: 입력을 빼앗지 않음
            elif ev == "hotkey_ok":
                self.hotkey_ok = True
                if self.pending_autolock and not self.locked:
                    self.toggle_lock()
                self.pending_autolock = False
            elif ev == "hotkey_failed":
                self.hotkey_ok = False
                self.pending_autolock = False
                if self.locked:   # 안전장치: 풀 수 없는 잠금 상태로 두지 않는다
                    self.locked = False
                    set_click_through(self.root, False)
        while not self.state.alerts.empty():
            ev = self.state.alerts.get()
            if ev == "aggro_me":
                self.flash_left = 6
            if self.var_sound.get():
                play_sound(ev, self.var_volume.get())

        with self.state.lock:
            snap = self.state.snapshot()
            shop_seq, stage_seq = self.state.shop_seq, self.state.stage_seq
            run_end_seq = self.state.run_end_seq
            klass = class_key(self.state.player_class) or None

        # 로그에서 새 직업을 읽으면 내 직업으로 (고정 중이면 고정이 우선)
        if klass != self.detected_class:
            self.detected_class = klass
            if klass and self.upgrade_data and klass in {c["id"] for c in self.upgrade_data.get("classes", [])}:
                self.on_class_logged(klass)

        # 런이 끝나 로비로 돌아가면 저주는 지운다 (저주는 런마다 무작위)
        if run_end_seq != self.seen_run_end:
            self.seen_run_end = run_end_seq
            if self.curse_stacks:
                self.curse_stacks.clear()
                self.save_config()
                if self.dictionary is not None and self.dictionary.win.winfo_exists() and self.dictionary.mode == "runes":
                    self.dictionary.refresh(keep_scroll=True)

        # 상점에 들어가면 사전을 열고, 다음 스테이지가 시작되면 닫는다
        if shop_seq != self.seen_shop_seq:
            self.seen_shop_seq = shop_seq
            if self.var_dict_auto.get() and self.upgrade_data:
                self.get_dictionary().show(activate=False)
        if stage_seq != self.seen_stage_seq:
            self.seen_stage_seq = stage_seq
            if self.var_dict_close.get() and self.dictionary is not None and self.dictionary.visible:
                self.dictionary.hide()

        # 숫자 애니메이션: 표시값이 실제 값을 부드럽게 따라간다
        animating = False
        for attr, key in (("anim_dps", "dps_now"), ("anim_avg", "dps_avg")):
            cur, target = getattr(self, attr), snap[key]
            if self.fx["anim"] and abs(target - cur) > 0.5:
                cur += (target - cur) * 0.3
                animating = True
            else:
                cur = target
            setattr(self, attr, cur)
        pulsing = self.fx["pulse"] and snap["target_is_me"]
        moving = animating or self.theme == "rainbow" or self.flash_left > 0 or pulsing
        palette_changed = False
        if self.theme == "rainbow" and time.time() >= getattr(self, "next_rainbow", 0):
            self.next_rainbow = time.time() + 0.3     # 색 변화가 느려서 0.3초마다면 충분하다
            self.pal = self.compute_palette()
            palette_changed = True

        frame = (tuple((k, tuple(v) if isinstance(v, list) else v) for k, v in snap.items()),
                 self.flash_left, self.locked, self.transparent, self.lang,
                 self.watcher.status, self.watcher.debug_logging, self.var_warn_debug.get(), self.height,
                 self.icons.finished, tuple(self.runes_equipped), tuple(sorted(self.curse_stacks.items())))
        if animating or palette_changed or self.flash_left > 0 or frame != self.last_frame:
            self.last_frame = frame
            self.render(snap)
        elif pulsing:
            self.update_pulse()   # 반짝임만 필요할 때는 띠의 색만 바꾼다 (다시 그리지 않음)
        return moving

    def txt(self, x, y, s, font, fill, anchor, outline=None, r=1, width=None, glow=False):
        """투명 배경일 때는 외곽선을 둘러서 밝은 게임 화면 위에서도 읽히게 한다.
        glow=True 이고 네온 글로우가 켜져 있으면 글자색이 번지는 듯한 바깥 고리를 더한다."""
        c, P = self.canvas, self.pal
        if outline is None:
            outline = self.transparent
        if glow and self.fx["glow"]:
            base = P["outline"] if self.transparent else P["night"]
            halo = mix(fill, base, 0.55 if self.transparent else 0.72)
            for dx, dy in GLOW_RING:
                c.create_text(x + dx, y + dy, text=s, font=font, fill=halo, anchor=anchor, width=width)
        if outline:
            for dx in range(-r, r + 1):
                for dy in range(-r, r + 1):
                    if dx or dy:
                        c.create_text(x + dx, y + dy, text=s, font=font, fill=P["outline"],
                                      anchor=anchor, width=width)
        return c.create_text(x, y, text=s, font=font, fill=fill, anchor=anchor, width=width)

    def gradient_bar(self, x1, y1, x2, y2, left, right, radius=BAND_RADIUS, track=False):
        """왼쪽→오른쪽 그라데이션 둥근 띠. track=True면 반짝임 때 색만 바꿀 수 있게 기록한다."""
        c = self.canvas
        rec = self.pulse_items.append if track else (lambda item: None)
        if not self.fx["gradient"]:
            rec((round_rect(c, x1, y1, x2, y2, radius, fill=left, outline=""), 0.0))
            return
        rec((round_rect(c, x1, y1, x2, y2, radius, fill=left, outline=""), 0.0))
        rec((round_rect(c, (x1 + x2) / 2, y1, x2, y2, radius, fill=right, outline=""), 1.0))
        a, b = x1 + radius, x2 - radius
        steps = max(1, int((b - a) / 7))
        seg = (b - a) / steps
        for i in range(steps):
            t = (i + 0.5) / steps
            x = a + seg * (i + 0.5)
            rec((c.create_line(x, y1, x, y2 + 1, fill=mix(left, right, t), width=seg + 1), t))

    def pulse_colors(self, me):
        P = self.pal
        pulse = (math.sin(time.time() * 5.0) + 1) / 2 if (me and self.fx["pulse"]) else 0.0
        left = mix(P["blood"], P["blood2"], 0.45 * pulse)
        right = mix(P["blood2"], P["blood"], 0.45 * pulse) if self.fx["gradient"] else left
        return left, right

    def update_pulse(self):
        c = self.canvas
        left, right = self.pulse_colors(True)
        for item, t in self.pulse_items:
            try:
                c.itemconfigure(item, fill=mix(left, right, t))
            except tk.TclError:
                pass
        for item in c.find_withtag("aggro_edge"):
            c.itemconfigure(item, outline=left)

    def render(self, s):
        P, W, c = self.pal, self.W, self.canvas
        self.pulse_items = []
        tp = self.transparent
        c.delete("all")
        cf = self.f_cap if tp else self.f_ui
        cc = P["dim"]

        me = s["target_is_me"]
        if self.flash_left > 0:
            self.flash_left -= 1
        flash_on = self.flash_left % 2 == 1
        aggro_l, aggro_r = self.pulse_colors(me)

        # 배경 / 테두리
        if not tp:
            edge = aggro_l if me else P["rim"]
            round_rect(c, 1, 1, W - 1, self.height - 1, UI_RADIUS, fill=P["night"], outline=edge, width=2,
                       tags=("aggro_edge",) if me else ())
            if self.fx["gradient"]:   # 위쪽 강조선
                for i in range(16):
                    t = i / 15
                    x = 14 + (W - 28) * i / 16
                    c.create_line(x, 3, x + (W - 28) / 16 + 1, 3, fill=mix(P["corona"], P["corona2"], t), width=2)
        elif not self.locked:
            round_rect(c, 1, 1, W - 2, self.height - 2, UI_RADIUS, fill="", outline=P["dim"], dash=(3, 4))
            round_rect(c, W / 2 - 30, 0, W / 2 + 30, 7, 3, fill=P["dim"], outline="")
        if me and tp and self.fx["pulse"]:
            # 투명 모드에서도 어그로가 눈에 띄게 테두리를 두른다
            round_rect(c, 1, 1, W - 2, self.height - 2, UI_RADIUS, fill="", outline=aggro_l, width=2,
                       tags=("aggro_edge",))

        # 헤더
        boss_entry = None
        if not s["in_ecliptica"]:
            head = self.t("waiting")
        elif s["boss"]:
            head, boss_entry = self.boss_info(s["boss"], s.get("boss_sources", ()))
        elif s["last_boss"]:
            name, boss_entry = self.boss_info(s["last_boss"], s.get("boss_sources", ()))
            head = self.t("defeated", boss=name)
        elif s["active"]:
            head = self.t("field")
        else:
            head = self.t("resting")
        # 보스 아이콘 칸: 항상 자리를 두고, 보스가 없거나 아이콘이 없으면 "?" 를 띄운다
        ix, iy, isz = 12, 9, BOSS_ICON
        icon = self.boss_icon(boss_entry, isz - 6)
        tile_line = mix(P["rim"], P["text"], 0.15)
        # 보스 아이콘은 대부분 밝은 색이라, 밝은 테마(스노우 등)에서는 칸만 어둡게 칠한다
        tile_fill = P["band"] if luminance(P["night"]) < 0.5 else "#27303F"
        round_rect(c, ix, iy, ix + isz, iy + isz, 9, fill="" if tp else tile_fill, outline=tile_line, width=1)
        if icon is not None:
            c.create_image(ix + isz / 2, iy + isz / 2, image=icon, anchor="center")
        else:
            q_color = P["dim"] if luminance(P["night"]) < 0.5 or tp else "#C9D6E6"
            self.txt(ix + isz / 2, iy + isz / 2, "?", self.f_ui_b, q_color, "center")
        hx = ix + isz + 10
        room = W - 14 - hx - (self.measure("00:00", self.f_num) + 12 if s["has_data"] else 0)
        if s["stage_index"]:
            # 아래에 스테이지 줄이 있으면 두 줄이 아이콘 칸 높이를 나눠 쓴다
            self.txt(hx, 14, self.fit(head, self.f_ui_b, room), self.f_ui_b, P["text"], "nw")
            if s["has_data"]:
                self.txt(W - 14, 14, fmt_time(s["elapsed"]), self.f_num, P["dim"], "ne")
        else:
            # 한 줄뿐이면 아이콘 칸의 세로 가운데에 맞춘다
            cy = iy + isz / 2
            self.txt(hx, cy, self.fit(head, self.f_ui_b, room), self.f_ui_b, P["text"], "w")
            if s["has_data"]:
                self.txt(W - 14, cy, fmt_time(s["elapsed"]), self.f_num, P["dim"], "e")

        # 스테이지 순번과 남은 보스 (런 진행 중일 때만)
        dy = 14          # 스테이지 줄이 없어도 보스 아이콘 칸과 아래 내용이 겹치지 않게
        if s["stage_index"]:
            dy = 27
            if s["stage_index"] == RUN_STAGES:
                right, rfont = self.t("jim_appears"), self.f_target
            elif s["until_jim"] == 0:
                right, rfont = self.t("next_jim"), cf
            else:
                right, rfont = self.t("until_jim", n=s["until_jim"]), cf
            label = self.t("stage_of", i=s["stage_index"], n=RUN_STAGES) + "  " + phase_of_stage(s["stage_index"])
            label = self.fit(label, cf, W - 14 - hx - self.measure(right, rfont) - 12)   # 오른쪽 글자와 겹치지 않게
            self.txt(hx, 36, label, cf, cc, "nw")
            if s["stage_index"] == RUN_STAGES:
                # 마지막 스테이지: 크게 강조
                self.txt(W - 14, 31, self.t("jim_appears"), self.f_target, P["blood"], "ne", r=2, glow=True)
            elif s["until_jim"] == 0:
                self.txt(W - 14, 36, self.t("next_jim"), cf, P["corona"], "ne", glow=True)
            else:
                n = s["until_jim"]
                self.txt(W - 14, 36, self.t("until_jim", n=n), cf, P["corona"] if n <= 2 else cc, "ne",
                         glow=n <= 2)
            # 런 진행도 막대
            px1, px2, py = 14, W - 14, 59
            done = (RUN_STAGES - s["bosses_left"]) / RUN_STAGES   # 잡은 보스 비율
            if tp:
                c.create_line(px1, py, px2, py, fill=P["outline"], width=5, capstyle="round")
            c.create_line(px1, py, px2, py, fill=mix(P["night"] if not tp else P["outline"], P["dim"], 0.35),
                          width=3, capstyle="round")
            if done > 0:
                xe = px1 + (px2 - px1) * done
                if self.fx["gradient"]:
                    n = max(1, int((xe - px1) / 9))
                    for i in range(n):
                        xa = px1 + (xe - px1) * i / n
                        xb = px1 + (xe - px1) * (i + 1) / n
                        c.create_line(xa, py, xb + 1, py, width=3,
                                      fill=mix(P["corona2"], P["corona"], (i + 1) / n))
                else:
                    c.create_line(px1, py, xe, py, fill=P["corona"], width=3, capstyle="round")

        # 어그로
        if s["target"]:
            target_text = self.t("target_me") if me else s["target"]
        elif s["boss"]:
            target_text = self.t("checking")
        else:
            target_text = "—"
        by1, by2 = 38 + dy, 70 + dy
        mid = (by1 + by2) / 2
        if me or flash_on:
            if flash_on:
                left_c = right_c = P["corona"]
            else:
                left_c, right_c = aggro_l, aggro_r
            self.gradient_bar(12, by1, W - 12, by2, left_c, right_c, track=not flash_on)
            fg = "#140C1C" if luminance(mix(left_c, right_c, 0.5)) > 0.62 else "#FFFFFF"
            # 문구 자체가 '나를 노린다'는 뜻이라 설명 글자 없이 가운데에 크게 (긴 번역도 겹치지 않게)
            self.txt(W / 2, mid, target_text, self.f_target, fg, "center", outline=False)
        else:
            if not tp:
                round_rect(c, 12, by1, W - 12, by2, BAND_RADIUS, fill=P["band"], outline="")
            x_pad = 24 if not tp else 14
            self.txt(x_pad, mid, self.t("boss_target"), cf, cc, "w")
            self.txt(W - x_pad, mid, target_text, self.f_target, P["text"], "e", glow=bool(s["target"]))

        # DPS
        dps_color = P["corona"] if s["active"] else P["dim"]
        self.txt(14, 76 + dy, fmt_num(self.anim_dps), self.f_big, dps_color, "nw", r=2, glow=s["active"])
        self.txt(14, 128 + dy, self.t("dps_recent", n=DPS_WINDOW), cf, cc, "nw")
        self.txt(W - 14, 92 + dy, fmt_num(self.anim_avg), self.f_mid, P["text"], "ne")
        self.txt(W - 14, 118 + dy, self.t("avg"), cf, cc, "ne")

        # 그래프
        self.draw_graph(s["graph"], s["active"], 12, 150 + dy, W - 12, 186 + dy)

        # 하단 수치
        self.txt(14, 196 + dy, fmt_num(s["seg_damage"]), self.f_num, P["text"], "nw")
        self.txt(14, 214 + dy, self.t("damage"), cf, cc, "nw")
        self.txt(104, 196 + dy, fmt_num(s["seg_taken"]), self.f_num, P["text"], "nw")
        self.txt(104, 214 + dy, self.t("taken"), cf, cc, "nw")
        self.txt(W - 14, 196 + dy, fmt_num(s["session_damage"]), self.f_num, P["text"], "ne")
        self.txt(W - 14, 214 + dy, self.t("session"), cf, cc, "ne")

        # 룬 / 저주 (사전 창에서 직접 고른 것)
        extra = 0
        runes = [r for r in self.runes_equipped if r in self.rune_by_id]
        curses = [(k, n) for k, n in self.curse_stacks.items() if n > 0 and k in self.curse_by_id]
        if runes or curses:
            ry = 245 + dy
            x = 14
            for rid in runes:
                icon = self.boss_icon(self.rune_by_id[rid], 18)
                if icon is not None:
                    c.create_image(x, ry, image=icon, anchor="w")
                    x += 22
                else:
                    self.txt(x, ry, "◆", cf, RUNE_COLOR, "w")
                    x += 16
            if curses:
                names = ", ".join(f"{self.entry_name(self.curse_by_id[k])}×{n}" for k, n in curses)
                label = self.t("ov_curses") + " " + names
                sx = x + (6 if runes else 0)
                self.txt(sx, ry, self.fit(label, cf, W - 14 - sx), cf, mix(CURSE_COLOR, P["text"], 0.15), "w")
            extra = 22

        # 안내 문구 (잠금 상태에서는 숨김)
        bottom = 236 + dy + extra
        if not self.locked:
            y = 240 + dy + extra
            if self.watcher.debug_logging is False and self.var_warn_debug.get():
                item = self.txt(14, y, self.t("warn_debug"), cf, WARN_COLOR, "nw", width=W - 28)
                y = c.bbox(item)[3] + 6
            if not s["local_name"]:
                hint = self.t("hint_name")
            else:
                kind, arg = self.watcher.status
                status = arg if kind == "file" else self.t(kind)
                hint = f"{status}\n{self.t('hint')}"
                if self.upgrade_data:
                    hint += "\n" + self.t("hint_dict")
            item = self.txt(14, y, hint, cf, cc, "nw", width=W - 50)   # 오른쪽 아래 ⚙ 자리 비움
            bottom = c.bbox(item)[3] + 10

        if bottom != self.height:
            self.height = bottom
            c.configure(height=bottom)

        # ⚙ 설정 버튼: 마우스를 올렸을 때만 오른쪽 아래에
        self.gear_box = None
        if self.hover and not self.locked:
            gx, gy, r = W - 22, self.height - 22, 14
            c.create_oval(gx - r, gy - r, gx + r, gy + r, fill=P["band"], outline=P["corona"], width=1.5)
            draw_gear(c, gx, gy, 7.5, P["corona"], P["band"])
            self.gear_box = (gx - r - 4, gy - r - 4, gx + r + 4, gy + r + 4)

    def draw_graph(self, values, active, x1, y1, x2, y2):
        c, P, tp = self.canvas, self.pal, self.transparent
        w, h = x2 - x1, y2 - y1
        if not tp:
            c.create_line(x1, y2, x2, y2, fill=P["rim"])
        peak = max(values) if values else 0
        if peak <= 0:
            return
        step = w / max(1, len(values) - 1)
        pts = []
        for i, v in enumerate(values):
            pts.append((x1 + i * step, y2 - 1 - (v / peak) * (h - 4), v / peak))
        flat = [coord for x, y, _ in pts for coord in (x, y)]
        hi = P["corona"] if active else P["dim"]
        lo = P["corona2"] if active else mix(P["dim"], P["outline"] if tp else P["night"], 0.4)

        if not tp:
            # 곡선 아래를 세로 줄로 채워 은은한 그라데이션 면을 만든다
            if self.fx["gradient"]:
                for x, y, r in pts:
                    c.create_line(x, y + 1, x, y2, fill=mix(P["night"], mix(lo, hi, r), 0.28), width=step + 1)
            else:
                c.create_polygon([x1, y2] + flat + [x2, y2], fill=P["band"], outline="")
        else:
            c.create_line(flat, fill=P["outline"], width=5, smooth=True, capstyle="round")

        if self.fx["gradient"]:
            for (xa, ya, ra), (xb, yb, rb) in zip(pts, pts[1:]):
                c.create_line(xa, ya, xb, yb, fill=mix(lo, hi, (ra + rb) / 2), width=2, capstyle="round")
        else:
            c.create_line(flat, fill=hi, width=2, smooth=True, capstyle="round")

        if active:   # 현재 값 위치에 빛나는 점
            x, y, _ = pts[-1]
            if self.fx["glow"]:
                glow_c = mix(hi, P["outline"] if tp else P["night"], 0.5)
                c.create_oval(x - 6, y - 6, x + 6, y + 6, fill=glow_c, outline="")
            c.create_oval(x - 3, y - 3, x + 3, y + 3, fill=hi, outline=P["outline"] if tp else "")

    def run(self):
        self.root.mainloop()


# ---------------------------------------------------------------------------
def load_config():
    try:
        with open(CONFIG_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


COMMAND_PATH = os.path.join(APP_DIR, "overlay_command.txt")


def send_command(cmd):
    """이미 실행 중인 오버레이에 명령을 전달한다 (1초 안에 처리됨)"""
    try:
        with open(COMMAND_PATH, "w", encoding="utf-8") as f:
            f.write(cmd)
    except OSError:
        pass


def ask_already_running(lang):
    """예=다시 불러오기, 아니요=종료, 취소=그대로"""
    try:
        root = tk.Tk()
        root.withdraw()
        root.attributes("-topmost", True)
        from tkinter import messagebox
        answer = messagebox.askyesnocancel("Ecliptica Overlay", tr(lang, "already"), parent=root)
        root.destroy()
    except Exception:
        return
    if answer is True:
        send_command("show")
    elif answer is False:
        send_command("quit")


def screen_bounds():
    """모든 모니터를 합친 영역 (x, y, 너비, 높이)"""
    if IS_WINDOWS:
        try:
            import ctypes
            gm = ctypes.windll.user32.GetSystemMetrics
            return gm(76), gm(77), gm(78), gm(79)   # SM_XVIRTUALSCREEN ~ SM_CYVIRTUALSCREEN
        except Exception:
            pass
    return None


def ensure_single_instance():
    """이미 실행 중이면 False (Windows 뮤텍스 사용)"""
    if not IS_WINDOWS:
        return True
    import ctypes
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel32.CreateMutexW.restype = ctypes.c_void_p
    ensure_single_instance.handle = kernel32.CreateMutexW(None, False, "Local\\EclipticaOverlaySingleton")
    return ctypes.get_last_error() != 183  # ERROR_ALREADY_EXISTS


def close_single_instance():
    handle = getattr(ensure_single_instance, "handle", None)
    if IS_WINDOWS and handle:
        import ctypes
        ctypes.WinDLL("kernel32").CloseHandle(ctypes.c_void_p(handle))
        ensure_single_instance.handle = None


def show_error(message):
    try:
        root = tk.Tk()
        root.withdraw()
        from tkinter import messagebox
        messagebox.showerror("Ecliptica Overlay", message)
        root.destroy()
    except Exception:
        pass


def main():
    parser = argparse.ArgumentParser(description="Ecliptica DPS / 어그로 오버레이")
    parser.add_argument("--demo", action="store_true", help="게임 없이 가짜 전투로 미리보기")
    parser.add_argument("--log-dir", help="VRChat 로그 폴더 (기본: AppData\\LocalLow\\VRChat\\VRChat)")
    parser.add_argument("--name", help="내 VRChat 표시 이름 (보통 자동 인식)")
    parser.add_argument("--after-update", action="store_true", help=argparse.SUPPRESS)
    args = parser.parse_args()

    config = load_config()
    if args.after_update:   # 업데이트 직후: 이전 창이 닫힐 때까지 최대 10초 기다림
        for _ in range(20):
            if ensure_single_instance():
                break
            close_single_instance()
            time.sleep(0.5)
        else:
            return
    elif not ensure_single_instance():
        ask_already_running(config.get("lang") or detect_lang())
        return
    try:
        os.remove(COMMAND_PATH)     # 이전에 남은 명령은 버린다
    except OSError:
        pass

    if args.name:
        config["name"] = args.name
    state = CombatState(local_name=config.get("name", ""))

    fixed = start_demo_writer() if args.demo else None
    watcher = LogWatcher(state, log_dir=args.log_dir, fixed_file=fixed)
    watcher.start()

    Overlay(state, watcher, config).run()


if __name__ == "__main__":
    try:
        main()
    except Exception:
        import traceback
        detail = traceback.format_exc()
        log_error("main")
        lang = load_config().get("lang") or detect_lang()
        show_error(tr(lang, "crash") + "\n\n" + detail[-600:])
